#ifndef SRC_DEMO_H_
#define SRC_DEMO_H_

#include "common.h"
#include "peripheral/oled.h"
#include "peripheral/adv7393.h"
#include "lib/iic.h"
#include "peripheral/lynred_k613d.h"
#include "button.h"
#include "graphic/ui_lib.h"

#define MAX_BAR_LEVEL 		5

typedef enum {MODE_AGC, MODE_DDE, MODE_HL, MODE_OL} processing_mode_t;
typedef enum {MODE_THERMAL, MODE_LOWLIGHT, MODE_FUSION} video_mode_t;
typedef enum {MODE_WHITEHOT, MODE_BLACKHOT, MODE_IRONBOW} polarity_mode_t;

void task_button_handler();
void task_button_init();
void initMenu();
void TaskDemoMenu();
void TaskDemoMenu_init();
void TaskDemoMenu_ver1();
#endif /* SRC_DEMO_H_ */
