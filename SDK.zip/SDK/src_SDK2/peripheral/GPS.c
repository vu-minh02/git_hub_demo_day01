#include "GPS.h"
#include <unistd.h>
#include <math.h>

XIic IicInstance;
uint8_t WriteBufferm[28] = {0};
int reset = 0;
//int position_valid = 0; // check qua lau khong nhan dc ve tinh du dinh su dung luc hoan thanh menu
int light_sensor_iic_Initialize()
{
	if(XIic_DynInit(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR) == -1)
		{
			printf("fail IIC GPS_SENSOR \r\n");
			return 0;
		}
	printf("Success IIC GPS SENSOR \r\n");
    return XST_SUCCESS;
}


int light_sensor_write_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr, uint8_t u8RegVal)
{
	int i;
		uint8_t SentByteCount = 0;
		uint8_t StatusReg;

		uint8_t pI2cDataSend[2];
		pI2cDataSend[0] = u8RegAddr;
		pI2cDataSend[1] = u8RegVal;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif


		SentByteCount = (uint8_t)XIic_DynSend((uint32_t) BaseAddr, SlaveAddr, &pI2cDataSend[0], (uint8_t) 2, (uint8_t) XIIC_STOP);
		if(SentByteCount < 1)
		{
			return SentByteCount;
		}
		for(i = 0; i < 100; i++);

//		printf("Success write light sensor\r\n");

		return XST_SUCCESS;
}



uint8_t light_sensor_read_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr)
{
	uint8_t u8DataRecv = 0xFF;
		int cnt = 0;
		uint8_t StatusReg;
		uint8_t SentByteCount = 0;

	//	SlaveAddr = SlaveAddr>>1;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif

		// Position the Read pointer to specific location.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
			{
				SentByteCount = (uint8_t)XIic_DynSend(BaseAddr, SlaveAddr,
									(uint8_t *)&u8RegAddr, 1,
									(uint8_t)XIIC_REPEATED_START);
			}
			cnt++;
		}while(SentByteCount != 1 && (cnt < 100));

		// Error writing chip address so return SentByteCount
		if (SentByteCount < 1)
		{
			printf("[DEBUG] FAIL READ LIGHT SENSOR");
			return SentByteCount;
		}
		// Receive data
		XIic_DynRecv((uint32_t) BaseAddr, SlaveAddr, &u8DataRecv, (unsigned) 1);

		return u8DataRecv;
}

int32_t light_sensor(void)
{
	unsigned char reg[6];
	signed short mag[2];
	float data[2];

		reg[0] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_CONTR_ADDR);
		printf("Light sensor default value = 0x%02X\n", reg[0]);

		light_sensor_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR,LTR_329_REG_CONTR_ADDR,0x01);
		usleep(1000);

		light_sensor_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR,LTR_329_REG_MEAS_RATE_ADDR,0x12);

		reg[1] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_DATA_CH1_0_ADDR);
		reg[2] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_DATA_CH1_1_ADDR);

		reg[3] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_DATA_CH0_0_ADDR);
		reg[4] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_DATA_CH0_1_ADDR);

		mag[0] = ((signed short)reg[2] << 8) | (reg[1]);
		mag[1] = ((signed short)reg[4] << 8) | (reg[3]);

		data[0] = mag[0];
		data[1] = mag[1];


	    printf("Light sensor value CH1 = %.2f\n", data[0]);
	    printf("Light sensor value CH2 = %.2f\n", data[1]);



	    reg[5] = light_sensor_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,LTR_329_I2C_ADDR ,LTR_329_REG_STATUS_ADDR);
	    printf("Light sensor default value = 0x%02X\n", reg[5]);
        sleep(1);
		return (1);
}



int GPS_random_write_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t *DataSend, unsigned numBytes) {

//	int i;
		uint8_t SentByteCount = 0;
		uint8_t StatusReg;



	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif


//		SentByteCount = (uint8_t)XIic_DynSend((uint32_t) BaseAddr, SlaveAddr, DataSend, (uint8_t) numBytes,  (uint8_t) XIIC_STOP);

		SentByteCount = (uint8_t)XIic_Send((uint32_t) BaseAddr, SlaveAddr, DataSend, (uint8_t) numBytes, (uint8_t) XIIC_STOP);
		return SentByteCount;
//		if(SentByteCount < 1)
//		{
//			return SentByteCount;
//		}
//		for(i = 0; i < 100; i++);

		printf("Success write light sensor\r\n");

		return XST_SUCCESS;
}
uint8_t GPS_read_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr, uint8_t *buffer)
{
	uint8_t u8DataRecv = 0xFF;
		int cnt = 0;
		uint8_t StatusReg;
		uint8_t SentByteCount = 0;

	//	SlaveAddr = SlaveAddr>>1;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif

		// Position the Read pointer to specific location.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
			{
				SentByteCount = (uint8_t)XIic_DynSend(BaseAddr, SlaveAddr,
									(uint8_t *)&u8RegAddr, 1,
									(uint8_t)XIIC_REPEATED_START);
			}
			cnt++;
		}while(SentByteCount != 1 && (cnt < 10));
//
		// Error writing chip address so return SentByteCount
		if (SentByteCount < 1)
		{
			return SentByteCount;
		}
		// Receive data

		XIic_DynRecv((uint32_t) BaseAddr, SlaveAddr, buffer, (unsigned) 1);

		return u8DataRecv;
}

int WaitForAck(uint32_t BaseAddr, uint8_t SlaveAddr)
{
    unsigned char ff_register[1];   // Dữ liệu của thanh ghi
    unsigned char buffer[10]; // Dữ liệu GPS
  	unsigned char check;
    int count = 0;
    // check xem co nhan duoc header B5 khong
    while (count < 80) {
   	        GPS_read_reg(BaseAddr, SlaveAddr, 0xFF, &ff_register[0]);
   	        check = ff_register[0];
   	        if (check == 0xB5) {
   	        	break;
   	        }
   	        else{
   	        	count++;
   	        }
   	    }

   	    if (check == 0xB5) {
   	    // Đọc tiếp 10 byte dữ liệu GPS
   	    for (int i = 0; i < 9; i++) {
   	        GPS_read_reg(BaseAddr, SlaveAddr, 0xFF, &ff_register[0]);
   	        buffer[i] = ff_register[0];
   	        printf("%2X ",buffer[i]);
   	    }
   	    }
   	    else{
   	    	printf("[DEBUG] NACK GPS FAIL\n");
   	    	return 0;
   	    }

        // check xem GPS nhan cau hinh hay khong
   	    if((buffer[0] == 0x62) && (buffer[1] == 0x05) && (buffer[2] == 0x01)) {
   	       printf("[DEBUG] ACK GPS SUCCESS\n");
   	       return 1;
   	    }
   	    else{
   	       printf("[DEBUG] NACK GPS FAIL");
   	       return 0;
   	    }

   	    printf("\n");
}


int GPS_test_init_v1(int *check_out){
	    int count = 0;   // bien dem lap gui cau hinh
        int check = 0;   // bien kiem tra GPS da nhan cau hinh chua
	    uint8_t write_reg[30] = {0}; // Khởi tạo tất cả các phần tử thành 0
						write_reg[0]  = SYNC_CHAR_1;// 0xB5
						write_reg[1]  = SYNC_CHAR_2;// 0x62
						write_reg[2]  = 0x06;
						write_reg[3]  = 0x00;
						write_reg[4] =  0x14;
						write_reg[5] = 0x00;
						write_reg[6]  = 0x00;
						write_reg[7]  = 0x00;
						write_reg[8]  = 0x00;
						write_reg[9]  = 0x00;
						write_reg[10]  = 0x84;
						write_reg[11]  = 0x00;
						write_reg[12]  = 0x00;
						write_reg[13]  = 0x00;
						write_reg[14]  = 0x00;
						write_reg[15]  = 0x00;
						write_reg[16]  = 0x00;
						write_reg[17]  = 0x00;
						write_reg[18]  = 0x01;
						write_reg[19]  = 0x00;
						write_reg[20]  = 0x01;
						write_reg[21]  = 0x00;
						write_reg[22]  = 0x00;
						write_reg[23]  = 0x00;
						write_reg[24]  = 0x00;
						write_reg[25]  = 0x00;
						write_reg[26] = 0xA0;
						write_reg[27] = 0x96;

	     uint8_t write_rate[15] = {0}; // Khởi tạo tất cả các phần tử thành 0
					  write_rate[0]  = SYNC_CHAR_1;
					  write_rate[1]  = SYNC_CHAR_2;
					  write_rate[2]  = 0x06;
					  write_rate[3]  = 0x08;
					  write_rate[4]  = 0x06;
					  write_rate[5]  = 0x00;
					  write_rate[6]  = 0x32;
					  write_rate[7]  = 0x00;
					  write_rate[8]  = 0x02;
					  write_rate[9]  = 0x00;
					  write_rate[10] = 0x00;
					  write_rate[11]  = 0x00;
					  write_rate[12]  = 0x48;
					  write_rate[13]  = 0xE8;

	     uint8_t write_NAV[20] = {0}; // Khởi tạo tất cả các phần tử thành 0
						write_NAV[0]  = SYNC_CHAR_1;
						write_NAV[1]  = SYNC_CHAR_2;
						write_NAV[2]  = 0x06;
						write_NAV[3]  = 0x01;
						write_NAV[4]  = 0x08;
						write_NAV[5]  = 0x00;
						write_NAV[6]  = 0x01;
						write_NAV[7]  = 0x07;
						write_NAV[8]  = 0x01;
						write_NAV[9]  = 0x00;
						write_NAV[10] = 0x00;
						write_NAV[11] = 0x00;
						write_NAV[12] = 0x00;
						write_NAV[13] = 0x00;
						write_NAV[14] = 0x18;
						write_NAV[15] = 0xE2;

      //==============================================================================================================
	  //gui cau hinh su dung UBX only
	  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_reg[0], 28);
	  usleep(1000);
	  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);

	  while((check == 0) && (count < 3)){
		  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_reg[0], 28);
		  usleep(1000);
		  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);
		  count++;
	  }
	  *check_out = check;
	  count = 0;
	  //==============================================================================================================
	  // gui cau hinh tan so tra ve
	  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_rate[0], 14);
	  usleep(1000);
	  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);

	  while((check == 0) && (count < 3)){
		  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_rate[0], 14);
		  usleep(1000);
		  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);
	      count++;
	  }
	  count = 0;
	  //==============================================================================================================
      // gui cau hinh su dung NAV PVT
	  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_NAV[0], 16);
	  usleep(1000);
	  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);

	  while((check == 0) && (count < 3)){
	  	  GPS_random_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, &write_rate[0], 14);
	  	  usleep(1000);
	  	  check = WaitForAck(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS);
	  	  count++;
	  }

	  	  //==============================================================================================================
return 1;
}




void GPS_test_get_value_v1(int *kinh_do, int *vi_do, int *check_out){
//	 unsigned char reg0, reg1;
	    unsigned char ff_register[1];   // Dữ liệu của thanh ghi
	    unsigned char buffer[40]; // Dữ liệu GPS
	    unsigned char check;
        int count = 0;
        u32 addr_param_ctrl = XPAR_IR_PREPROCESSING_PARAM_CTRL_IP_PARAM_CTRL_0_S_AXI_CONTROL_BUS_BASEADDR;
	    // Đọc 2 thanh ghi từ GPS

	    // Đọc dữ liệu GPS cho đến khi tìm thấy giá trị 0xB5
	    while (count <50) {
	        GPS_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, 0xFF, &ff_register[0]);
	        check = ff_register[0];
	        if (check == 0xB5) {
	        	reset = 0 ;
	        	break;
	        }
	        	count++;
	    }

	    if (check == 0xB5) {
	    // Đọc tiếp 40 byte dữ liệu GPS
	    for (int i = 0; i < 37; i++) {
	        GPS_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR, SAM_M8Q_DEFAULT_I2C_ADDRESS, 0xFF, &ff_register[0]);
	        buffer[i] = ff_register[0];
	        printf("%2X ",buffer[i]);
	    }
//        printf("\n");
        if((buffer[0] == 0x62)&&(buffer[1] == 0x01)&&(buffer[2] == 0x07)){
          if(buffer[25]  >= 2){
          *kinh_do = (int)((buffer[32] << 24) | (buffer[31] << 16) | (buffer[30] << 8) | (buffer[29]));
          *vi_do = (int)((buffer[36] << 24) | (buffer[35] << 16) | (buffer[34] << 8) | (buffer[33]));
          }
        }
	    }

	    else{
        reset +=1;
        if(reset == 25){
    	Xil_Out32(addr_param_ctrl + 0x68, 0);  // reset GPS
    	usleep(600000);
    	Xil_Out32(addr_param_ctrl + 0x68, 1); // khoi dong lai va gui lai cau hinh
    	usleep(600000);
        GPS_test_init_v1(check_out);
        reset = 0;
        }
	    }


}
