/*
 * oled.h
 *
 *  Created on: May 5, 2023
 *      Author: datnt81
 */

#ifndef SRC_INIT_OLED_H_
#define SRC_INIT_OLED_H_

#include "../common.h"

#define IIC_SLAVE_ADDRESS		0x4c
#define EEPROM_SLAVE_ADDRESS	0xa6

int init_oled_pw_ctrl();

int oled_write_reg(u8 SlaveAddr, u8 u8RegAddr, u8 u8RegVal);
u8 oled_read_reg(u8 SlaveAddr, u8 u8RegAddr);
void oled_write_eeprom(u8 u8RegAddr, u8 u8RegVal);
u8 oled_read_eeprom(u8 u8RegAddr);

void writeLUT_Oled(u8 tbl);

int oled_iic_Initialize();

int oled_iic_Initialize_2();

int init_oled_ctrl();

void oled_turn_OnOff_display (int isOn);

void init_oled();

void oled_setBRT(u8 value);
u8 oled_getBRT();
void oled_switch();
void oled_pattern();
char oled_get_lr();
void oled_set_lr(int8_t value);
char oled_get_tb();
void oled_set_tb(int8_t value);

#endif /* SRC_INIT_OLED_H_ */
