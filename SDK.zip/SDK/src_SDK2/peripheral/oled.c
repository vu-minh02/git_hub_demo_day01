/*
 * oled.c
 *
 *  Created on: May 5, 2023
 *      Author: datnt81
 */

#include "oled.h"

XGpio	Gpio_oled_pw_ctrl_1v8_5v;

int init_oled_pw_ctrl()
{
	int Status;
	/* khoi tao GPIO */
	Status = XGpio_Initialize(&Gpio_oled_pw_ctrl_1v8_5v, XPAR_OLED_OUT_OLED_INTERFACE_OLED_PW_CTRL_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XGpio_SetDataDirection(&Gpio_oled_pw_ctrl_1v8_5v, 1, 0); //kenh 1 dieu khien nguon
	XGpio_SetDataDirection(&Gpio_oled_pw_ctrl_1v8_5v, 2, 0); //kenh 2 dieu khien reset

	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 1, 0); // OFF Power vao OLED
	usleep(100000);
	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 1, 1); // ON 1v8 vao OLED
	usleep(100000);

	// CAUSE DEVICE RESET WHEN USE WITH BAD OLED
	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 1, 3); // ON 5v vao OLED
	usleep(100000);

	return XST_SUCCESS;
}

//#define FLIP_OLED

u8 oledregsDSVGA[] =
{
		0x00, // #define REG_STAT		0x00
		0x22, //0x20//#define REG_VINMODE     0x01 (Mode1:0x21 YCbCr 444, Mode2:0x23 YCbCr422)
#ifdef FLIP_OLED
		0x72, //0x70 + bit 1: flip vertical/bit 0: flip horizontal	//#define REG_DISPMODE    0x02
#else
		0x70, //0x70 + bit 1: flip vertical/bit 0: flip horizontal	//#define REG_DISPMODE    0x02
#endif
		0x0C, //#define REG_LFTPOS      0x03
		0x0C, //#define REG_RGTPOS      0x04
		0x0C, //#define REG_TOPPOS      0x05
		0x0C, //#define REG_BOTPOS      0x06

		0xC0,//0x80, //#define REG_BRT			0x07
		0x60,//0x80, //#define REG_CNTRST		0x08

		0x00, //#define REG_RWRST1    	0x09
		0x00, //#define REG_RWRST2		0x0A

		0x01, //#define REG_RAMPCTL		0x0B
		0x14, //#define REG_RAMPCM		0x0C
		0x80, //#define REG_VDACMX      0x0D
		0x05, //#define REG_BIASN       0x0E
		0x0D, //#define REG_GAMMAST	    0x0F
		0x04, //#define REG_VCOMMDE	    0x10  //0x04
		0x3D, //#define REG_VCOMCTL     0x11
		0x0D, //#define REG_VGMAX       0x12
		0x51, //#define REG_MVCOM       0x13
		0x47, //#define REG_IDRF        0x14
		0x64, //#define REG_DIMCTL      0x15
		0x17, //#define REG_TREFDIV     0x16
		0x5A, //#define REG_TEMPOFF     0x17
		0x10, //#define REG_TUPDATE     0x18
		0x9B, //#define REG_TEMPOUT     0x19
		0x00, //#define REG_ANGPWRDN    0x1A
		0x00, //#define REG_SYSPWRDN    0x1B
		0x00, //#define REG_TPMODE      0x1C	0x00
		0x00, //#define REG_TPLINWTH    0x1D	0x00
		0x00, //#define REG_TPCOLSP     0x1E	0x00
		0x00, //#define REG_TPROWSP     0x1F	0x00
		0x07, //#define REG_TPCOLOR	    0x20
		0x00, //#define REG_LUT_ADDR    0x21
		0x00, //#define REG_LUT_DATAL   0x22
		0x00, //#define REG_LUT_DATAH   0x23
		0x07, //#define REG_LUT_UPDATE  0x24
		0x00, //#define REG_PUPCTL      0x25
		0x00, //#define REG_V_BLANK     0x26
		0x00, //#define REG_H_BLANK     0x27
		0x00, //#define REG_V_OFFSET    0x28
		0x01, //#define REG_H_DLY       0x29
		0x00, //#define REG_MISCTL      0x2A

		// Chi de lai 1 he so de tinh mau kenh Y, bo qua kenh Cb Cr
		0x10, //0x10, #define REG_CSCC0       0x2B
		0x2A,//0x2A, //#define REG_CSC11A      0x2C
		0x01,//0x01, //#define REG_CSCC1B      0x2D
		0x98,//0x98, //#define REG_CSCC2A      0x2E
		0x01,//0x01, //#define REG_CSCC2B      0x2F
		0xD0,//0xD0, //#define REG_CSCC3A    	0x30
		0x00,//0x00, //#define REG_CSCC3B     	0x31
		0x64,//0x64, //#define REG_CSCC4A	   	0x32
		0x00,//0x00, //#define REG_CSCC4B   	0x33
		0x04,//0x04, //#define REG_CSCC5A      0x34
		0x02,//0x02, //#define REG_CSCC5B      0x35

		0x00, //#define REG_HIDDEN      0x36
		0x00, //#define REG_DIGTEST  	0x37
		0x58, //#define REG_NOFLINEL    0x38
		0x02, //#define REG_NOFLINEH    0x39
		0x20, //#define REG_NOFPXLL  	0x3A
		0x03, //#define REG_NOFPXLH  	0x3B
		0x99, //#define REG_RESERVED  	0x3C
		0x99, //#define  REG_RESERVED  	0x3D
		0x00, //#define  REG_RESERVED  	0x3E
		0xFF, //#define  REG_RESERVED 	0x3F
		0x00, //#define  REG_RESERVED 	0x40
		0x30, //#define REG_RESERVED  	0x41
		0x64 //#define  REG_RESERVED  	0x42
};

int oledLUT_2_2DSVGA[256]  =
{
		1, 200, 399, 407, 416, 431, 446, 461, 476, 482, 488, 494, 500, 507, 513, 519, 525, 530, 536, 541, 546,
		552, 557, 562, 567, 573, 578, 583, 589, 594, 599, 604, 610, 613, 615, 618, 621, 624, 627, 630, 633, 635,
		638, 641, 644, 647, 650, 653, 655, 658, 661, 664, 667, 670, 673, 675, 678, 681, 684, 687, 690, 693, 695,
		698, 701, 703, 705, 707, 709, 711, 713, 715, 717, 718, 720, 722, 724, 726, 728, 730, 732, 734, 736, 738,
		740, 742, 743, 745, 747, 749, 751, 753, 755, 757, 759, 761, 763, 765, 766, 768, 770, 772, 774, 776, 778,
		780, 782, 784, 786, 788, 789, 791, 793, 795, 797, 799, 801, 803, 805, 807, 809, 811, 812, 814, 816, 818,
		820, 822, 824, 826, 827, 829, 830, 832, 833, 835, 837, 838, 840, 841, 843, 844, 846, 848, 849, 851, 852,
		854, 855, 857, 858, 860, 862, 863, 865, 866, 868, 869, 871, 873, 874, 876, 877, 879, 880, 882, 884, 885,
		887, 888, 890, 891, 893, 895, 896, 898, 899, 901, 902, 904, 905, 907, 909, 910, 912, 913, 915, 916, 918,
		920, 921, 923, 924, 926, 927, 929, 931, 932, 934, 935, 937, 938, 940, 942, 943, 945, 946, 948, 949, 951,
		952, 954, 956, 957, 959, 960, 962, 963, 965, 967, 968, 970, 971, 973, 974, 976, 978, 979, 981, 982, 984,
		985, 987, 989, 990, 992, 993, 995, 996, 998, 999, 1001, 1003, 1004, 1006, 1007, 1009, 1010, 1012, 1014,
		1015, 1017, 1018, 1020, 1021, 1023
};

int oled_write_reg(u8 SlaveAddr, u8 u8RegAddr, u8 u8RegVal)
{
//	printf("oled_write_reg %02x [%02x] => %02x\r\n", SlaveAddr, u8RegAddr, u8RegVal);
	int i;
	uint8_t SentByteCount = 0;
	uint8_t StatusReg;

	u8 pI2cDataSend[2];
	pI2cDataSend[0] = u8RegAddr;
	pI2cDataSend[1] = u8RegVal;
	SlaveAddr = SlaveAddr>>1;

#if 1
	// Make sure all the Fifo's are cleared and Bus is Not busy.
	do
	{
		StatusReg = Xil_In8(XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR + XIIC_SR_REG_OFFSET);
		StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK |
				XIIC_SR_BUS_BUSY_MASK);
	} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
			XIIC_SR_TX_FIFO_EMPTY_MASK));
#endif


//	SentByteCount = XIic_DynSend((u32) XPAR_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR, SlaveAddr, &pI2cDataSend[0], (unsigned) 2, (u8) XIIC_STOP);
	SentByteCount = (uint8_t)XIic_DynSend((u32) XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR, SlaveAddr, &pI2cDataSend[0], (u8) 2, (u8) XIIC_STOP);
	if(SentByteCount < 1)
	{
		xil_printf("oled_write_reg failed\r\n");
		return SentByteCount;
	}
	for(i = 0; i < 100; i++);

	return XST_SUCCESS;
}

u8 oled_read_reg(u8 SlaveAddr, u8 u8RegAddr)
{
//	printf("oled_read_reg %02x [%02x] ", SlaveAddr, u8RegAddr);
 	u8 u8DataRecv = 0xFF;
	int cnt = 0;
	uint8_t StatusReg;
	uint8_t SentByteCount = 0;

	SlaveAddr = SlaveAddr>>1;

#if 1
	// Make sure all the Fifo's are cleared and Bus is Not busy.
	do
	{
		StatusReg = Xil_In8(XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR + XIIC_SR_REG_OFFSET);
		StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK |
				XIIC_SR_BUS_BUSY_MASK);
	} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
			XIIC_SR_TX_FIFO_EMPTY_MASK));
#endif

	// Position the Read pointer to specific location.
	do
	{
		StatusReg = Xil_In8(XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR + XIIC_SR_REG_OFFSET);
		if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
		{
//			SentByteCount = XIic_DynSend(XPAR_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR, SlaveAddr,
//					(uint8_t *)&u8RegAddr, 1,
//					XIIC_REPEATED_START);
			SentByteCount = (uint8_t)XIic_DynSend(XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR, SlaveAddr,
								(uint8_t *)&u8RegAddr, 1,
								(u8)XIIC_REPEATED_START);
		}
		cnt++;
	}while(SentByteCount != 1 && (cnt < 100));

	// Error writing chip address so return SentByteCount
	if (SentByteCount < 1)
	{
		xil_printf("oled_read_reg failed\r\n");
		return SentByteCount;
	}

	// Receive data
	XIic_DynRecv((u32) XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR, SlaveAddr, &u8DataRecv, (unsigned) 1);

//	printf("<= %02x\r\n", u8DataRecv);
	return u8DataRecv;
}

void oled_write_eeprom(u8 u8RegAddr, u8 u8RegVal)
{
	oled_write_reg(EEPROM_SLAVE_ADDRESS, u8RegAddr, u8RegVal);
}

u8 oled_read_eeprom(u8 u8RegAddr)
{
	return oled_read_reg(EEPROM_SLAVE_ADDRESS, u8RegAddr);
}

void writeLUT_Oled(u8 tbl){
	int i;
	int j;
//	int tmp;
	//	int value;
	u8 tmpVal1;
	u8 tmpVal2;

	oled_write_reg(IIC_SLAVE_ADDRESS, 0x21, 0x00);

	for (i = 0; i < 256; i = i + 4) {
		int tmp;
		tmp = oledLUT_2_2DSVGA[i];

		tmpVal2 = ((tmp>>8)&0x03);	// High Byte 1
		oled_write_reg(IIC_SLAVE_ADDRESS, 0x23, tmpVal2);

		tmpVal1 = (tmp&0x00FF);		// Low Byte 1
		oled_write_reg(IIC_SLAVE_ADDRESS, 0x22, tmpVal1);

		for (j = i+1; (j < i+4) && (j < 256); j++){
			tmp = oledLUT_2_2DSVGA[j];

			tmpVal2 = ((tmp>>8)&0x03);	// High Byte 2
			oled_write_reg(IIC_SLAVE_ADDRESS, 0x23, tmpVal2);

			tmpVal1 = (tmp&0x00FF);		// Low Byte 2
			oled_write_reg(IIC_SLAVE_ADDRESS, 0x22, tmpVal1);
		}
	}

	oled_write_reg(IIC_SLAVE_ADDRESS, 0x24, tbl+8+0x10);
}

int oled_iic_Initialize()
{
	if(XIic_DynInit(XPAR_OLED_OUT_OLED_INTERFACE_AXI_IIC_OLED_BASEADDR) == -1)
	{
		return 0;
	}

	for(u8 i = 0; i < sizeof(oledregsDSVGA); i++)
	{
		oled_write_reg(IIC_SLAVE_ADDRESS, i, oledregsDSVGA[i]);
	}

	// xil_printf("Gamma 2.2 Start\r\n");
	 writeLUT_Oled(7);
	// xil_printf("Gamma 2.2 End\r\n");


	return XST_SUCCESS;
}

int oled_iic_Initialize_2()
{
	// Temp correction
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x16, 23);
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x17, 98);
	return 1;
}


int init_oled_ctrl(){
	/* Khoi dong Oled theo Power On Sequences */
	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 2, 1);
	usleep(10000);
	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 2, 0);
	usleep(10000);
	XGpio_DiscreteWrite(&Gpio_oled_pw_ctrl_1v8_5v, 2, 1);
	usleep(10000);

	oled_iic_Initialize();
	oled_iic_Initialize_2();

	return XST_SUCCESS;
}

void oled_turn_OnOff_display (int isOn) {
	u8 DataRecv = oled_read_reg(IIC_SLAVE_ADDRESS, 0x02);
	if(isOn==1) {
		DataRecv = DataRecv&0xEF;
	}
	else {
		DataRecv = (DataRecv&0xEF) + 0x80;
	}
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x02, DataRecv);
//	u8 temp = oled_read_reg(IIC_SLAVE_ADDRESS, 0x02);
	// printf("0x%02x\r\n", temp);
}

void init_oled()
{
	// print("[INFO] init OLED ... \n\r");
	init_oled_pw_ctrl();

	init_oled_ctrl();

	// Turn on oled
	oled_turn_OnOff_display(1);

}

void oled_setBRT(u8 value)
{
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x07, value);
	printf("[INFO] BRT %d \n\r", value);
}

u8 oled_getBRT()
{
	return oled_read_reg(IIC_SLAVE_ADDRESS, 0x07);
}

void oled_switch()
{
	// flip bit 1
	u32 temp = oled_read_reg(IIC_SLAVE_ADDRESS, 0x02);
	temp ^= 0b10000000;
//	printf("temp = %02x\r\n", (unsigned)temp);
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x02, temp);
}

void oled_pattern()
{
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x1c, 0b00001000);
}

char oled_get_lr()
{
	return oled_read_reg(IIC_SLAVE_ADDRESS, 0x03) - 12;
//	return oled_read_reg(IIC_SLAVE_ADDRESS, 0x04) - 12;
}

void oled_set_lr(int8_t value)
{
	value += 12;
	if (value < 0)
		value = 0;
	if (value > 24)
		value = 24;
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x03, value);
//	oled_write_eeprom(0x13, value);
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x04, 24-value);
//	oled_write_eeprom(0x14, 24-value);

//	uint8_t ReadBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES + 4];
//	SpiFlashRead(ReadBuffer, FLASH_IMAGE_BASEADDR - PAGE_SIZE, PAGE_SIZE, COMMAND_QUAD_READ);
//	printf("LR = 0x%02x, TB  = 0x%02x\r\n", ReadBuffer[0], ReadBuffer[1]);
//
//	uint8_t WriteBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];
//	WriteBuffer[0] = value;
//	WriteBuffer[1] = ReadBuffer[1];
//	SpiFlashWrite(WriteBuffer, FLASH_IMAGE_BASEADDR - PAGE_SIZE, PAGE_SIZE, COMMAND_PAGE_PROGRAM);
}

char oled_get_tb()
{
	return oled_read_reg(IIC_SLAVE_ADDRESS, 0x05) - 12;
//	return oled_read_reg(IIC_SLAVE_ADDRESS, 0x06) - 12;
}

void oled_set_tb(int8_t value)
{
	value += 12;
	if (value < 0)
		value = 0;
	if (value > 24)
		value = 24;
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x05, value);
//	oled_write_eeprom(0x15, value);
	oled_write_reg(IIC_SLAVE_ADDRESS, 0x06, 24-value);
//	oled_write_eeprom(0x16, 24-value);

//	uint8_t ReadBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES + 4];
//	SpiFlashRead(ReadBuffer, FLASH_IMAGE_BASEADDR - PAGE_SIZE, PAGE_SIZE, COMMAND_QUAD_READ);
//	printf("LR = 0x%02x, TB  = 0x%02x\r\n", ReadBuffer[0], ReadBuffer[1]);
//
//	uint8_t WriteBuffer[PAGE_SIZE + READ_WRITE_EXTRA_BYTES];
//	WriteBuffer[0] = ReadBuffer[0];
//	WriteBuffer[1] = value;
//	SpiFlashWrite(WriteBuffer, FLASH_IMAGE_BASEADDR - PAGE_SIZE, PAGE_SIZE, COMMAND_PAGE_PROGRAM);
}
