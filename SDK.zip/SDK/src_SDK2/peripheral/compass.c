#include "compass.h"
#include <math.h>
#include <stdlib.h>
#include <stdint.h>
#include <stddef.h>
#include "../lib/iic.h"

int compass_iic_init()
{
	if(XIic_DynInit(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR) == -1)
	{
		printf("[INFO] Fail IIC axis sensor\r\n");
		return XST_FAILURE;
	}
	printf("[INFO] Success IIC axis sensor\r\n");
	usleep(50000);
	return XST_SUCCESS;
}

int compass_sensor_config(void)
{
	unsigned char buf;
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL1,BM1422AGMV_CNTL1_VAL);
	buf = (BM1422AGMV_CNTL1_VAL & BM1422AGMV_CNTL1_OUT_BIT);
	if (buf == BM1422AGMV_CNTL1_OUT_BIT)
		printf("[INFO] BM1422AGMV_14BIT_SENS\r\n");
	else
		printf("[INFO] BM1422AGMV_12BIT_SENS\r\n");

	usleep(50000);

	buf = (BM1422AGMV_CNTL4_VAL >> 8) & 0xFF;
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL4_L,buf);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL4_H,buf);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL2, BM1422AGMV_CNTL2_VAL);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_AVE_A, BM1422AGMV_AVE_A_VAL);
	return 0;
}

int compass_sensor_config_2(void)
{
	unsigned char reg;
	unsigned char buf;

	reg = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_WIA);
	printf("BM1422AGMV_WHO_AMI Register Value = 0x%02X\n", reg);

	if (reg != BM1422AGMV_WIA_VAL) {
		printf("Can't find BM1422AGMV");
		return (0);
	}

	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL1,0xC0);
	buf = (BM1422AGMV_CNTL1_VAL & BM1422AGMV_CNTL1_OUT_BIT);
	if (buf == BM1422AGMV_CNTL1_OUT_BIT) {
		printf("BM1422AGMV_14BIT_SENS\r\n");
	} else {
		printf("BM1422AGMV_12BIT_SENS\r\n");
	}

	usleep(50000);

	buf = (BM1422AGMV_CNTL4_VAL >> 8) & 0xFF;
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL4_L,0x00);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL4_H,0x00);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL2, BM1422AGMV_CNTL2_VAL);
	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_AVE_A, BM1422AGMV_AVE_A_VAL);

	return 0;
}

float calculateAngle(float y, float x) {
    float angle;

    if (x < 0 ) {
        angle = 90 + atan(y/ x) * (180.0 / M_PI); // Chuyển đổi từ radians sang degrees
    } else if (x > 0) {
        angle = 270 + atan(y/ x) * (180.0 / M_PI); // Chuyển đổi từ radians sang degrees
    } else {
        // Trường hợp x == 0
        if (y > 0) {
            angle = 90;
        } else if (y < 0) {
            angle = 270;
        } else {
            angle = 0;
        }
    }

    return angle;
}

int compass_get_val() //compass_get_val
{
	unsigned char reg[6];
	signed short mag[3];
	float data[3] = {0};
	float B;
	int num = 5;
    for(int i = 0; i < num; i++)
    {
    	iic_WriteReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E,BM1422AGMV_CNTL3, BM1422AGMV_CNTL3_VAL);
		usleep(100);

		reg[0] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAX_L);

		reg[1] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAX_H);

		reg[2] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAY_L);

		reg[3] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAY_H);

		reg[4] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAZ_L);

		reg[5] = iic_ReadReg(XPAR_GPIO_CTRL_IIC_COMPASS_BASEADDR,BM1422AGMV_DEVICE_ADDRESS_0E ,BM1422AGMV_DATAZ_H);

		mag[0] = ((signed short)reg[1] << 8) | (reg[0]);
		mag[1] = ((signed short)reg[3] << 8) | (reg[2]);
		mag[2] = ((signed short)reg[5] << 8) | (reg[4]);

		mag[0] = ((signed short)reg[1] << 8) | (reg[0]);
		mag[1] = ((signed short)reg[3] << 8) | (reg[2]);
		mag[2] = ((signed short)reg[5] << 8) | (reg[4]);

		data[0] += (float)mag[0] / 24 + 42 ; //huong bac chinh x
		data[1] += (float)mag[1] / 24 + 94 ; //huong dong chinh y
		data[2] += (float)mag[2] / 24;

		usleep(200);
    }
//    printf("[DEBUG] time: %f %f \n\r", data[1]/num , data[0]/num);

	B = calculateAngle(data[1]/num, data[0]/num);
	return (int)B;
}


