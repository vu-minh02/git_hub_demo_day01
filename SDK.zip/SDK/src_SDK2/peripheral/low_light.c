#include "low_light.h"

bool low_light_pwr = true;

void init_lowlight_ctrl()
{
	low_light_pwr = true;
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_LOW_LIGHT_PWR, 0b11);

}

void lowlight_ctrl_pwr(bool value)
{
	low_light_pwr = value;
	if(low_light_pwr == true)
		Xil_Out32(PARAM_CTRL_ADDR + PARAM_LOW_LIGHT_PWR, 0b11);
	else
		Xil_Out32(PARAM_CTRL_ADDR + PARAM_LOW_LIGHT_PWR, 0b00);
}
