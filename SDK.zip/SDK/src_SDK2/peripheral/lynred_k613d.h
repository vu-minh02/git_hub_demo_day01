/*
 * lynred_k613d.h
 *
 *  Created on: May 10, 2024
 *      Author: huongdh7-tank
 */

#ifndef SRC_LYNRED_K613D_H_
#define SRC_LYNRED_K613D_H_

#include "../common.h"
#include "xspi.h"

int lynredK613d_init_ctrl();

int initSPI_proxyboard();
void setting_proxyboard(u8 opcore, u16 param);
int sendCmd_proxyboard(u8 cmd_byte0, u8 cmd_byte1);

void lynredK613d_set_Tint(int value);
void lynredK613d_set_GFID(int value);
void lynredK613d_set_GSK(int value);
void lynredK613d_set_GMS(int value);
void lynredK613d_set_trigger_mode(int value);


#endif /* SRC_LYNRED_K613D_H_ */
