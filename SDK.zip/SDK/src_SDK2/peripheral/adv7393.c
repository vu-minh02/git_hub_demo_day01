/*
 * adv.c
 *
 *  Created on: Jun 3, 2023
 *      Author: datnt81
 */

#include "adv7393.h"

#include <stdio.h>
#include <unistd.h>

#include "xgpio.h"
#include "../lib/iic.h"
#include "xparameters.h"

XGpio gpio_adv_reset;

int adv7393_init()
{
	// Khoi tao gpio RESET: bit 0 adv_reset (active low)
	int Status = XGpio_Initialize(&gpio_adv_reset, XPAR_ANALOG_OUT_GPIO_ANALOGOUT_RST_DEVICE_ID);
	if (Status != 0) {
		return Status;
	}
	XGpio_SetDataDirection(&gpio_adv_reset, 1, 0);
	XGpio_SetDataDirection(&gpio_adv_reset, 2, 0);

	/* Khoi dong ADV theo Power On Sequences */
	XGpio_DiscreteWrite(&gpio_adv_reset, 1, 0);// clear bit 0 va 1
	usleep(100000);
	XGpio_DiscreteWrite(&gpio_adv_reset, 1, 1);// bat nguon adv7393, tat reset
	usleep(100000);
	XGpio_DiscreteWrite(&gpio_adv_reset, 1, 3);// bat reset
	usleep(100000);
//	XGpio_DiscreteWrite(&gpio_adv_reset, 1, 0);// tăt het
//	usleep(100000);

//	XGpio_DiscreteWrite(&gpio_adv_reset, 2, 0x0); //0xFFFF: mode ipcore hls, 0x0000: mode ipcore verilog

	// Khoi tao ADV IIC
	u32 iic_adv7393_addr = XPAR_ANALOG_OUT_IIC_ANALOGOUT_BASEADDR;
	iic_Init(iic_adv7393_addr);

	u8 adv7393_addr = 0x2A; //0x2A

	// Table 94 - Page 97
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x17, 0x02);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x00, 0x1c);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x01, 0x00);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x80, 0x11);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x82, 0xc3);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x87, 0x80);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x88, 0x10);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8a, 0x0c);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8c, 0xcb);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8d, 0x8a);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8e, 0x09);
//	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8f, 0x2a);

	//Test pattern
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x17, 0x02);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x00, 0x10);// 0x10 enable DAC1
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x01, 0x00);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x80, 0x11);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x82, 0xcb); //0xc3 0xcb
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x84, 0x40);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8c, 0xcb);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8d, 0x8a);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8e, 0x09);
	iic_WriteReg(iic_adv7393_addr, adv7393_addr, 0x8f, 0x2a);

	return 0;
}

void adv7393_term()
{
	XGpio_DiscreteWrite(&gpio_adv_reset, 1, 0);// clear bit 0 and bit 2
}
