#ifndef ADV7393_H_
#define ADV7393_H_

#include <stdio.h>
#include "xgpio.h"

extern XGpio gpio_adv_reset;

int adv7393_init();
void adv7393_term();

#endif
