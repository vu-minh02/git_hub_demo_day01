#include "VCNL4040.h"
#include <unistd.h>
#include <math.h>


int VCNL4040_iic_Initialize()
{
	if(XIic_DynInit(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR) == -1)
		{
			return 0;
			printf("fail IIC VCNL4040 \r\n");
		}
	printf("Success IIC VCNL4040 \r\n");
	return XST_SUCCESS;
}


int VCNL4040_write_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr, uint8_t u8RegVal_L,uint8_t u8RegVal_H)
{
	int i;
		uint8_t SentByteCount = 0;
		uint8_t StatusReg;

		uint8_t pI2cDataSend[3];
		pI2cDataSend[0] = u8RegAddr;
		pI2cDataSend[1] = u8RegVal_L;
		pI2cDataSend[2] = u8RegVal_H;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif


		SentByteCount = (uint8_t)XIic_DynSend((uint32_t) BaseAddr, SlaveAddr, &pI2cDataSend[0], (uint8_t) 3, (uint8_t) XIIC_STOP);
		if(SentByteCount < 1)
		{
			return SentByteCount;
		}
		for(i = 0; i < 100; i++);

		printf("Success write light sensor\r\n");

		return XST_SUCCESS;
}



uint16_t VCNL4040_read_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr)
{
	uint8_t u8DataRecv[2] = {0, 0};
		int cnt = 0;
		uint8_t StatusReg;
		uint8_t SentByteCount = 0;

	//	SlaveAddr = SlaveAddr>>1;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif

		// Position the Read pointer to specific location.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
			{
				SentByteCount = (uint8_t)XIic_DynSend(BaseAddr, SlaveAddr,
									(uint8_t *)&u8RegAddr, 1,
									(uint8_t)XIIC_REPEATED_START);
			}
			cnt++;
		}while(SentByteCount != 1 && (cnt < 100));

		// Error writing chip address so return SentByteCount
		if (SentByteCount < 1)
		{
			printf("fail \n\r");
			return SentByteCount;
		}
		// Receive data
		XIic_DynRecv((uint32_t) BaseAddr, SlaveAddr, u8DataRecv, (unsigned) 2);
		return (u8DataRecv[1] << 8) | u8DataRecv[0];
}

uint8_t lowbit_read_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr)
{
	uint8_t u8DataRecv = 0xFF;
		int cnt = 0;
		uint8_t StatusReg;
		uint8_t SentByteCount = 0;

	//	SlaveAddr = SlaveAddr>>1;

	#if 1
		// Make sure all the Fifo's are cleared and Bus is Not busy.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
					XIIC_SR_TX_FIFO_EMPTY_MASK |
					XIIC_SR_BUS_BUSY_MASK);
		} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK));
	#endif

		// Position the Read pointer to specific location.
		do
		{
			StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
			if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
			{
				SentByteCount = (uint8_t)XIic_DynSend(BaseAddr, SlaveAddr,
									(uint8_t *)&u8RegAddr, 1,
									(uint8_t)XIIC_REPEATED_START);
			}
			cnt++;
		}while(SentByteCount != 1 && (cnt < 100));

		// Error writing chip address so return SentByteCount
		if (SentByteCount < 1)
		{
			return SentByteCount;
		}

		// Receive data
		XIic_DynRecv((uint32_t) BaseAddr, SlaveAddr, &u8DataRecv, (unsigned) 1);

		return u8DataRecv;
}

int32_t VCNL4040(void)
{
	unsigned short reg;

	reg = VCNL4040_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,VCNL4040_I2CADDR_DEFAULT,0x0C);
	//printf("VCNL4040 default value = 0x%04X\n", reg);

	VCNL4040_write_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,VCNL4040_I2CADDR_DEFAULT,0x03,0x00,0x00);
	reg = VCNL4040_read_reg(XPAR_GPIO_CTRL_IIC_CTRL_BASEADDR,VCNL4040_I2CADDR_DEFAULT,0x08);
	printf("VCNL4040 default value = 0x%04X\n", reg);
//	VCNL4040_write_reg(XPAR_LIGHT_SENSOR_AXI_IIC_LIGHT_SENSOR_BASEADDR,VCNL4040_I2CADDR_DEFAULT,0x00,0x00,0x00);
//	reg = VCNL4040_read_reg(XPAR_LIGHT_SENSOR_AXI_IIC_LIGHT_SENSOR_BASEADDR,VCNL4040_I2CADDR_DEFAULT,0x09);
//	printf("VCNL4040 default value = 0x%04X\n", reg);


    return(1);
}
