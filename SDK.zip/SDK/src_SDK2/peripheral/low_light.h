#ifndef SRC_LOWLIGHT_H_
#define SRC_LOWLIGHT_H_
#include "../common.h"



void init_lowlight_ctrl();
void lowlight_ctrl_pwr(bool value);



#endif
