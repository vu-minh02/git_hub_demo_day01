#include "lynred_k613d.h"

XSpi  SpiInstanceProxy;
XGpio gpio_proxy_ctrl;

int lynredK613d_init_ctrl()
{
	//khoi tao nguon
	int Status = XGpio_Initialize(&gpio_proxy_ctrl, XPAR_IR_INFIRAY_GPIO_PROXY_CTRL_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XGpio_SetDataDirection(&gpio_proxy_ctrl, 1, 0);
	XGpio_SetDataDirection(&gpio_proxy_ctrl, 2, 0);
	XGpio_DiscreteWrite(&gpio_proxy_ctrl, 1, 1);
	usleep(100000);
	XGpio_DiscreteWrite(&gpio_proxy_ctrl, 2, 1);

	usleep(200000);

	//khoi tao spi dieu khien
	Status = initSPI_proxyboard();
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	usleep(50000);

	/* table 1
	 * GFID: 2792
	 * GSK: 1460
	 * GMS: 51
	*/

	/* table 12
	 * GFID: 3536
	 * GSK: 820
	 * GMS: 35
	*/

	//cau hinh mac dinh
//	lynredK613d_set_Tint(627);
//	lynredK613d_set_GFID(3536);
//	lynredK613d_set_GSK(800);

	//cam bien goc knd
//	lynredK613d_set_Tint(627);
//	lynredK613d_set_GFID(3228);
//	lynredK613d_set_GSK(1070);
//	lynredK613d_set_GMS(51);

	//cam bien cua ktx
	lynredK613d_set_Tint(627);
	lynredK613d_set_GFID(3228);
	lynredK613d_set_GSK(1180);
	lynredK613d_set_GMS(19);

	lynredK613d_set_trigger_mode(3);

	printf("[DEBUG] lynredK613d init ctrl XST_SUCCESS \n\r");
	return XST_SUCCESS;
}


int initSPI_proxyboard()
{
	int Status;
	XSpi_Config *ConfigPtr;	/* Pointer to Configuration data */
	ConfigPtr = XSpi_LookupConfig(XPAR_IR_INFIRAY_SPI_CTRL_PROXY_DEVICE_ID);
	if (ConfigPtr == NULL) {
		return XST_DEVICE_NOT_FOUND;
	}

	Status = XSpi_CfgInitialize(&SpiInstanceProxy, ConfigPtr, ConfigPtr->BaseAddress);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XSpi_SetOptions(&SpiInstanceProxy, XSP_MASTER_OPTION
			| XSP_CLK_ACTIVE_LOW_OPTION
			| XSP_CLK_PHASE_1_OPTION);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XSpi_Start(&SpiInstanceProxy);
	XSpi_IntrGlobalDisable(&SpiInstanceProxy);
	return XST_SUCCESS;
}


/*
 * Proxy CMD list
 * --------------------------------------------------
 * Index			cmd				param
 * --------------------------------------------------
 * 0				NOP
 * 1				0x01				tint:		1 to 627
 * 2				0x02				GSK: 		356 to 3888
 * 3				0x03				GFID:		384 to 3536
 * 4				0x04				CKDIV:		DONT USE
 * 5				0x05				GMS:		XXXX0,Gain3,gain2,gain1,00,UpRow,UpCol
 * 6				0x06				Yfirst:		0 to 359, default:0
 * 7				0x07				Ylast:		119 to 479, default:479
 * 8				0x08				Xfirst:		0 to 479, default:0
 * 9				0x09				Xlast:		159 to 639, default:639
 * */
void setting_proxyboard(u8 opcore, u16 param)
{
	u16 cmd = 0;
	u8 byteL, byteH;
	cmd = (opcore<<12) | param ;
	byteL = (cmd & 0x00ff);//param
	byteH = (u8)((cmd & 0xff00)>>8);//opcode
//	printf("byteL: 0x%02X  byteH: 0x%02X \n\r", byteL, byteH);
	if(sendCmd_proxyboard(byteL, byteH) == XST_FAILURE)
		return;
}

int sendCmd_proxyboard(u8 cmd_byte0, u8 cmd_byte1)
{
	int Status;

	u8  WriteBuffer[2]={cmd_byte0, cmd_byte1};
	Status = XSpi_SetSlaveSelect(&SpiInstanceProxy, 0x01);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	XSpi_Transfer(&SpiInstanceProxy, WriteBuffer, NULL, sizeof(WriteBuffer));
	Status = XSpi_SetSlaveSelect(&SpiInstanceProxy, 0x00);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
//	sleep(1);
	return XST_SUCCESS;
}

static int check_range_value(int value, int min, int max)
{
	if(value < min)
		value = min;
	if(value > max)
		value = max;
	return value;
}

void lynredK613d_set_Tint(int value)
{
	setting_proxyboard(0x1, check_range_value(value, 0, 4095));
	usleep(50000);
}

void lynredK613d_set_GFID(int value)
{
	setting_proxyboard(0x2, check_range_value(value, 384, 3536));
	usleep(50000);
}

void lynredK613d_set_GSK(int value)
{
	setting_proxyboard(0x3, check_range_value(value, 356, 3888));
	usleep(50000);
}

void lynredK613d_set_GMS(int value)
{
	setting_proxyboard(0x5, value); //GMS
	usleep(50000);
}

void lynredK613d_set_trigger_mode(int value)
{
	//When Trigger = 00 – DO NOT USE
	//When Trigger = 01 –FREE RUNNING MODE
	//When Trigger = 10 –RUN UNTIL TRIG PIN SET TO ‘1’ (To be validated)
	//When Trigger = 11 – FRAME PER FRAME
	setting_proxyboard(0xE, 0x193);
	usleep(50000);
	setting_proxyboard(0xF, value);
	usleep(50000);
}
