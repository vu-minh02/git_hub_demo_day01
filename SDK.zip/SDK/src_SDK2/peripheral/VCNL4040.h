#ifndef VCNL4040_H
#define VCNL4040_H


#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include "xparameters.h"
#include "xiic.h"


#define VCNL4040_I2CADDR_DEFAULT           (0x60)                    ///< VCNL4040 default i2c address

// All addresses are for 16bit registers;
// duplicates are for high or low bytes that aren't used together
#define VCNL4040_ALS_CONFIG                (0x00)                    ///< Ambient light sensor configuration register
#define VCNL4040_ALS_THDH                  (0x01)                    ///< Ambient light high threshold register
#define VCNL4040_ALS_THDL                  (0x02)                    ///< Ambient light low threshold register
#define VCNL4040_PS_CONF1_L                (0x03)                    ///< Proximity sensor configuration 1/2 register
#define VCNL4040_PS_MS_H                   (0x04)                    ///< Proximity sensor configuration 1/2 register
#define VCNL4040_PS_THDL                   (0x06)                    ///< Proximity sensor low threshold register
#define VCNL4040_PS_THDH                   (0x07)                    ///< Proximity sensor high threshold register
#define VCNL4040_PS_DATA                   (0x08)                    ///< Proximity sensor data register
#define VCNL4040_ALS_DATA                  (0x09)                    ///< Ambient light sensor data register
#define VCNL4040_WHITE_DATA                (0x0A)                    ///< White light sensor data register
#define VCNL4040_INT_FLAG                  (0x0B)                   ///< Interrupt status register
#define VCNL4040_DEVICE_ID                 (0x0C)                    ///< Device ID




int VCNL4040_iic_Initialize() ;
int32_t VCNL4040(void)        ;

#endif
