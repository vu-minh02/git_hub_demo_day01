#ifndef LIGHT_SENSOR_H_
#define LIGHT_SENSOR_H_

#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include "xparameters.h"
#include "xiic.h"
#include <stdbool.h>




#define SAM_M8Q_DEFAULT_I2C_ADDRESS 0x42

#define DATA_STREAM_REGISTER 0xFF

#define AVAILABLE_BYTES_MSB 0xFD
#define AVAILABLE_BYTES_LSB 0xFE


#define NAV_CLASS 0x01
#define RXM_CLASS 0x02
#define INF_CLASS 0x04
#define ACK_CLASS 0x05
#define CFG_CLASS 0x06
#define UPD_CLASS 0x09
#define MON_CLASS 0x0A
#define AID_CLASS 0x0B
#define TIM_CLASS 0x0D
#define ESF_CLASS 0x10
#define MGA_CLASS 0x13
#define LOG_CLASS 0x21
#define SEC_CLASS 0x27
#define HNR_CLASS 0x28

#define SYNC_CHAR_1 0xB5
#define SYNC_CHAR_2 0x62

#define CFG_PRT  0x00
#define ACK_ACK 0x01

#define CFG_MSG 0x01
#define CFG_RATE 0x08

#define NAV_PVT 0x07
#define MAX_MESSAGE_LENGTH 256












#define LTR_329_I2C_ADDR						(0x29)

#define LTR_329_REG_CONTR_ADDR					(0x80)
#define LTR_329_REG_MEAS_RATE_ADDR				(0x85)
#define LTR_329_REG_PART_ID_ADDR				(0x86)
#define LTR_329_REG_MANUFACTURER_ID_ADDR		(0x87)
#define LTR_329_REG_DATA_CH1_0_ADDR				(0x88)
#define LTR_329_REG_DATA_CH1_1_ADDR				(0x89)
#define LTR_329_REG_DATA_CH0_0_ADDR				(0x8A)
#define LTR_329_REG_DATA_CH0_1_ADDR				(0x8B)
#define LTR_329_REG_STATUS_ADDR					(0x8C)

#define LTR_329_GAIN_1X							(0b000)
#define LTR_329_GAIN_2X							(0b001)
#define LTR_329_GAIN_4X							(0b010)
#define LTR_329_GAIN_8X							(0b011)
#define LTR_329_GAIN_48X						(0b110)
#define LTR_329_GAIN_96X						(0b111)

#define LTR_329_STANDBY_MODE					(0b10)
#define LTR_329_ACTIVE_MODE						(0b1)

#define LTR_329_INTEGRATION_TIME_50MS			(0b001)
#define LTR_329_INTEGRATION_TIME_100MS			(0b000)
#define LTR_329_INTEGRATION_TIME_150MS			(0b100)
#define LTR_329_INTEGRATION_TIME_200MS			(0b010)
#define LTR_329_INTEGRATION_TIME_250MS			(0b101)
#define LTR_329_INTEGRATION_TIME_300MS			(0b110)
#define LTR_329_INTEGRATION_TIME_350MS			(0b111)
#define LTR_329_INTEGRATION_TIME_400MS			(0b011)

#define LTR_329_MEASUREMENT_RATE_50MS			(0b000)
#define LTR_329_MEASUREMENT_RATE_100MS			(0b001)
#define LTR_329_MEASUREMENT_RATE_200MS			(0b010)
#define LTR_329_MEASUREMENT_RATE_500MS			(0b011)
#define LTR_329_MEASUREMENT_RATE_1000MS			(0b100)
#define LTR_329_MEASUREMENT_RATE_2000MS			(0b101)

#define LTR_329_DATA_STATUS_OLD					(0b000)
#define LTR_329_DATA_STATUS_NEW					(0b001)

#define LTR_329_DATA_VALID						(0b000)
#define LTR_329_DATA_INVALID					(0b001)



#define SAM_M8Q_DEFAULT_I2C_ADDRESS 0x42

#define DATA_STREAM_REGISTER 0xFF

#define AVAILABLE_BYTES_MSB 0xFD
#define AVAILABLE_BYTES_LSB 0xFE


#define NAV_CLASS 0x01
#define RXM_CLASS 0x02
#define INF_CLASS 0x04
#define ACK_CLASS 0x05
#define CFG_CLASS 0x06
#define UPD_CLASS 0x09
#define MON_CLASS 0x0A
#define AID_CLASS 0x0B
#define TIM_CLASS 0x0D
#define ESF_CLASS 0x10
#define MGA_CLASS 0x13
#define LOG_CLASS 0x21
#define SEC_CLASS 0x27
#define HNR_CLASS 0x28

#define SYNC_CHAR_1 0xB5
#define SYNC_CHAR_2 0x62

#define CFG_PRT  0x00
#define ACK_ACK 0x01

#define CFG_MSG 0x01
#define CFG_RATE 0x08
int light_sensor_iic_Initialize() ;
int32_t light_sensor(void)        ;


#define NAV_PVT 0x07
#define MAX_MESSAGE_LENGTH 256



int GPS_random_write_reg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t *DataSend, unsigned numBytes);
void GPS_test_get_value_v1(int *kinh_do, int *vi_do, int *check_out);
int GPS_test_init_v1(int *check_out);// gui cau hinh nhan du lieu GPS
int WaitForAck(uint32_t BaseAddr, uint8_t SlaveAddr);


#endif
