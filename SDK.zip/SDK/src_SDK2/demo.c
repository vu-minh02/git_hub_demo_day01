#include "demo.h"
#include "peripheral/low_light.h"
#include "peripheral/compass.h"
#include "peripheral/GPS.h"
#include "graphic/menu_knd.h"
#include "graphic/menu_lib.h"



int contrast_gain[MAX_BAR_LEVEL] = {30, 40, 50, 65, 80};
int contrast_gamma[MAX_BAR_LEVEL] = {35, 45, 55, 75, 95};
int contrast_level = 2;
int contrast_mode = 0;

int edge_gain[MAX_BAR_LEVEL] = {3, 6, 9, 12, 15};
int edge_level = 3;
int edge_mode = 0;

int dde_alpha[MAX_BAR_LEVEL] = {50, 90, 130, 175, 225};
int dde_beta[MAX_BAR_LEVEL] = {300, 300, 300, 300, 300};
int dde_lamda[MAX_BAR_LEVEL] = {50, 90, 130, 175, 225};
int dde_level = 2;

level_bar_t level_bar = {22, OLED_HEIGHT - 55, 10, 15, 0};

int agc_level_val[MAX_BAR_LEVEL] = {55, 65, 75, 85, 95};
int agc_level = 2;

int polarity_offset = 170; //{110, 128, 150, 175, 200};


int longitude = 0;
int latitude = 0;
int check_out = 0;
GPS_t GPS_long_lat ={0,0};

processing_mode_t processing_mode = MODE_AGC;
video_mode_t video_mode = MODE_FUSION;
polarity_mode_t polarity_mode = MODE_IRONBOW;

bitmap_t bitmap_fusion;
bitmap_t bitmap_thermal;
bitmap_t bitmap_battery;
bitmap_t bitmap_OL;
bitmap_t bitmap_HL;
bitmap_t bitmap_AGC;
bitmap_t bitmap_DDE;
bitmap_t bitmap_Minus;
bitmap_t num_value_0;
bitmap_t bitmap_CAMBIEN;
bitmap_t bitmap_ANHNHIET;
bitmap_t bitmap_HETHONG;
bitmap_t bitmap_THOAT;
bitmap_t bitmap_LABAN;
bitmap_t bitmap_GPS;
bitmap_t bitmap_OLED;
bitmap_t bitmap_HIEUCHUAN;
bitmap_t bitmap_THONGTIN;
bitmap_t bitmap_DATLAI;
bitmap_t bitmap_BAT;
bitmap_t bitmap_TAT;
bitmap_t bitmap_EXITSYMBOL;
bitmap_t bitmap_RESETSYMBOL;
bitmap_t bitmap_RIGHTSYMBOL;
bitmap_t bitmap_PERCENT;
bitmap_t bitmap_ZEROPERCENT;
bitmap_t bitmap_HINHANH;
bitmap_t bitmap_GSK;
bitmap_t bitmap_GSID;
bitmap_t bitmap_NHIETMAU;
bitmap_t bitmap_DOSANG;
bitmap_t bitmap_TUONGPHAN;
bitmap_t bitmap_NHIET;
bitmap_t bitmap_ASY;
bitmap_t bitmap_LENS;
bitmap_t bitmap_PHIENBAN;

//==========================================
MenuPage_t* *CurrentMenu = NULL;
MenuPage_t* MainMenu =NULL;


int CountButtonHold =0 ;
int CountButtonR =0 ;
int CountButtonM =0 ;
int CountButtonMLabel =0;
//==========================================


//==========================================

compass_ruler_t compass_ruler = {(OLED_WIDTH - 480)/2, 12, 480, BUFFER_COMPASS_BASEADDR, 0};

//=============================================
static void set_agc_param(int agc_paramK);
static void set_polarity_mode(int polarity_mode, int polarity_offset);
static void set_dde_param(int dde_alpha_val, int dde_beta_val, int dde_lamda_val);
static void set_edgeEnhan_param(int contrast_mode_val, int contrast_gain_val, int contrast_gamma_val, int edge_mode_val, int edge_gain_val);
static void init_bitmap_param();

//=============================================
void task_button_init()
{
	init_lowlight_ctrl();

	graphic_init(BUFFER_TEMPLATE_BASEADDR_1, OLED_WIDTH, OLED_HEIGHT);
	graphic_draw_level_bar(&level_bar, 5); //khoi tao level bar
	graphic_draw_level_bar(&level_bar, agc_level+1); //khoi tao level bar

	//========================
	set_edgeEnhan_param(0, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[edge_level]);

	set_dde_param(dde_alpha[dde_level], dde_beta[dde_level], dde_lamda[dde_level]);

	set_agc_param(agc_level_val[agc_level]);

	set_polarity_mode(polarity_mode, polarity_offset);

	//========================
	init_bitmap_param();

	graphic_draw_bitmap(&bitmap_battery, -1, -1, 255);
	graphic_draw_bitmap(&bitmap_fusion, -1, -1, 255);
	graphic_draw_bitmap(&bitmap_AGC, -1, -1, 255);

	//========================
	graphic_init_compass(&compass_ruler);

//	initMenu();

	//========================

	graphic_init_GPS(0,0,255);


	//========================

}
static int EnterCount = 0;
static int UpDownCount = 0;
static int SpaceCount = 0;
static int MenuLevelIndex = 0;
static int init_count = 0;
static int Menu_running =0;
uint8_t CombinedMapOut[252];
// Biến toàn cục, khai báo ngoài hàm TaskDemoMenu
MenuPage_t *mainMenu = NULL;
MenuPage_t *ReplaceMenu = NULL;

MenuPage_t *subMenu1 = NULL;
MenuPage_t *subMenu2 = NULL;
MenuPage_t *subMenu3 = NULL;
MenuPage_t *subMenu4 = NULL;
MenuPage_t *subMenu5 = NULL;
MenuPage_t *subMenu6 = NULL;
MenuPage_t *subMenu7 = NULL;
MenuPage_t *subMenu8 = NULL;
MenuPage_t *subMenu9 = NULL;
MenuPage_t *subMenu10 = NULL;
static int isMainMenuInitialized = 0;

void TaskDemoMenu_init() {
    // Kiểm tra nếu mainMenu chưa được cấp phát bộ nhớ
    if (!isMainMenuInitialized) {
        // Cấp phát bộ nhớ cho mainMenu nếu chưa có
        mainMenu = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu1 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu2 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu3 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu4 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu5 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu6 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu7 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu8 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu9 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        subMenu10 = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        ReplaceMenu = (MenuPage_t*)malloc(sizeof(MenuPage_t));
        if (mainMenu == NULL) {
            printf("Memory allocation failed for mainMenu.\n");
            return;  // Dừng hàm nếu không cấp phát được bộ nhớ
        }
    	//===========================================================================
        // Khởi tạo mainMenu chỉ một lần
        mainMenu = createMenuPage(200, 100, 250, 50, 0, 5, 0, 0);
        printf("[INFO] mainMenu initialized.\n");
        ReplaceMenu = createMenuPage(200, 100, 250, 50, 0, 5, 0, 0);
        subMenu1 = createMenuPage(250, 100, 250, 60, 1, 3, 1, 0);
        subMenu1->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
        memset(&subMenu5->MenuItems->ItemInfo, 0, sizeof(ItemInfoStruct));
        subMenu1->MenuItems->ItemsType = ITEM_SUBMENU;

        subMenu2 = createMenuPage(250, 100, 250, 60, 0, 2, 1, 1);
        subMenu2->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
        subMenu2->MenuItems->ItemsType = ITEM_SUBMENU;


        subMenu3 = createMenuPage(250, 100, 250, 60, 0, 4, 1, 3);
        subMenu3->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
        subMenu3->MenuItems->ItemsType = ITEM_SUBMENU;

        subMenu4 = createMenuPage(250, 100, 250, 60, 0, 5, 1, 1);
        subMenu4->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
        subMenu4->MenuItems->ItemsType = ITEM_SUBMENU;

         subMenu5 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu5->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu5->MenuItems->ItemsType = ITEM_VALUE;

         subMenu6 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu6->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu6->MenuItems->ItemsType = ITEM_VALUE;

         subMenu7 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu7->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu7->MenuItems->ItemsType = ITEM_SWITCH;

         subMenu8 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu8->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu8->MenuItems->ItemsType = ITEM_SWITCH;

         subMenu9 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu9->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu9->MenuItems->ItemsType = ITEM_VALUE;

         subMenu10 = createMenuPage(250, 200, 250, 60, 0, 3, 1, 1);
         subMenu10->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
         subMenu10->MenuItems->ItemsType = ITEM_VALUE;


    	//===========================================================================
        // Liên kết các menu con vào menu cha
        mainMenu->MenuChildPage = (MenuPage_t**)malloc(4 * sizeof(MenuPage_t*));
        mainMenu->MenuChildPage[0] = subMenu1;
        mainMenu->MenuChildPage[1] = subMenu2;
        mainMenu->MenuChildPage[2] = subMenu3;
        mainMenu->MenuChildPage[3] = subMenu4;
//        mainMenu->MenuChildPage[4] = subMenu5;

        subMenu1->MenuParentPage = mainMenu;
        subMenu2->MenuParentPage = mainMenu;
        subMenu3->MenuParentPage = mainMenu;
        subMenu4->MenuParentPage = mainMenu;
//        subMenu5->MenuParentPage = mainMenu;


        subMenu1->MenuChildPage = (MenuPage_t**)malloc(2* sizeof(MenuPage_t*));
        subMenu1->MenuChildPage[0] = subMenu5;
        subMenu1->MenuChildPage[1] = subMenu6;
        // Liên kết menucon 1 với menu con
        subMenu5->MenuParentPage = subMenu1;

        //Liên kết menusub6 với menusub5
        subMenu6->MenuParentPage = subMenu1;



        subMenu2->MenuChildPage = (MenuPage_t**)malloc(1* sizeof(MenuPage_t*));
        subMenu2->MenuChildPage[0] = subMenu7;
        subMenu7->MenuParentPage = subMenu2;

        subMenu3->MenuChildPage = (MenuPage_t**)malloc(3* sizeof(MenuPage_t*));
        subMenu3->MenuChildPage[0] = subMenu8;
        subMenu3->MenuChildPage[1] = subMenu9;
        subMenu3->MenuChildPage[2] = subMenu10;
        subMenu8->MenuParentPage = subMenu3;
        subMenu9->MenuParentPage = subMenu3;
        subMenu10->MenuParentPage = subMenu3;
    	//===========================================================================
        mainMenu->bitmaps = (bitmap_t**)malloc(5 * sizeof(bitmap_t*));
        mainMenu->bitmaps[0] = &bitmap_CAMBIEN;
        mainMenu->bitmaps[1] = &bitmap_HETHONG;
        mainMenu->bitmaps[2] = &bitmap_HINHANH;
        mainMenu->bitmaps[3] = &bitmap_THONGTIN;
        mainMenu->bitmaps[4] = &bitmap_THOAT;

        mainMenu->MenuItems = (MenuItemStruct *)malloc(sizeof(MenuItemStruct));
        mainMenu->MenuItems->ItemInfo.offset_x = 200;
        mainMenu->MenuItems->ItemInfo.offset_y = 8;
        mainMenu->MenuItems->ItemInfo.x = 50;
        mainMenu->MenuItems->ItemInfo.y = 30;

        mainMenu->MenuItems->ItemInfo.bitmaps[0] = bitmap_RIGHTSYMBOL;
        mainMenu->MenuItems->ItemInfo.bitmaps[1] = bitmap_RIGHTSYMBOL;
        mainMenu->MenuItems->ItemInfo.bitmaps[2] = bitmap_RIGHTSYMBOL;
        mainMenu->MenuItems->ItemInfo.bitmaps[3] = bitmap_RIGHTSYMBOL;
        mainMenu->MenuItems->ItemInfo.bitmaps[4] = bitmap_EXITSYMBOL;


    	//===========================================================================
        // mode switch
        subMenu1->bitmaps = (bitmap_t**)malloc(3 * sizeof(bitmap_t*));

        subMenu1->MenuItems->ItemInfo.offset_x = 200;
        subMenu1->MenuItems->ItemInfo.offset_y = 8;
        subMenu1->MenuItems->ItemInfo.x = 50;
        subMenu1->MenuItems->ItemInfo.y = 30;

        subMenu1->bitmaps[0] = &bitmap_GSK;
        subMenu1->bitmaps[1] = &bitmap_GSID;
        subMenu1->bitmaps[2] = &bitmap_THOAT;

        subMenu1->MenuItems->ItemInfo.bitmaps[0] = num_value_0;
        subMenu1->MenuItems->ItemInfo.bitmaps[1] = num_value_0;
        subMenu1->MenuItems->ItemInfo.bitmaps[2] = bitmap_EXITSYMBOL;


        subMenu1->MenuItems->ItemInfo.InfoType[0] = 1;
        subMenu1->MenuItems->ItemInfo.InfoType[1] = 1;

    	//===========================================================================
        subMenu2->bitmaps = (bitmap_t**)malloc(2 * sizeof(bitmap_t*));
        subMenu2->MenuItems->ItemInfo.offset_x = 200;
        subMenu2->MenuItems->ItemInfo.offset_y = 8;
        subMenu2->MenuItems->ItemInfo.x = 50;
        subMenu2->MenuItems->ItemInfo.y = 30;

        subMenu2->bitmaps[0] = &bitmap_GSK;
        subMenu2->bitmaps[1] = &bitmap_THOAT;

        subMenu2->MenuItems->ItemInfo.bitmaps[0] = bitmap_RIGHTSYMBOL;
        subMenu2->MenuItems->ItemInfo.bitmaps[1] = bitmap_EXITSYMBOL;
    	//===========================================================================
        subMenu3->bitmaps = (bitmap_t**)malloc(4 * sizeof(bitmap_t*));
        subMenu3->MenuItems->ItemInfo.offset_x = 200;
        subMenu3->MenuItems->ItemInfo.offset_y = 8;
        subMenu3->MenuItems->ItemInfo.x = 50;
        subMenu3->MenuItems->ItemInfo.y = 30;

        subMenu3->bitmaps[0] = &bitmap_NHIETMAU;
        subMenu3->bitmaps[1] = &bitmap_DOSANG;
        subMenu3->bitmaps[2] = &bitmap_TUONGPHAN;
        subMenu3->bitmaps[3] = &bitmap_THOAT;


        subMenu3->MenuItems->ItemInfo.bitmaps[0] = bitmap_RIGHTSYMBOL;
        subMenu3->MenuItems->ItemInfo.bitmaps[1] = bitmap_ZEROPERCENT;
        subMenu3->MenuItems->ItemInfo.bitmaps[2] = bitmap_RIGHTSYMBOL;
        subMenu3->MenuItems->ItemInfo.bitmaps[3] = bitmap_EXITSYMBOL;

        subMenu3->MenuItems->ItemInfo.InfoType[0] = 0;
        subMenu3->MenuItems->ItemInfo.InfoType[1] = -1;
        subMenu3->MenuItems->ItemInfo.InfoType[2] = -1;
    	//===========================================================================
        subMenu4->bitmaps = (bitmap_t**)malloc(5 * sizeof(bitmap_t*));
        subMenu4->MenuItems->ItemInfo.offset_x = 200;
        subMenu4->MenuItems->ItemInfo.offset_y = 8;
        subMenu4->MenuItems->ItemInfo.x = 50;
        subMenu4->MenuItems->ItemInfo.y = 30;

        subMenu4->bitmaps[0] = &bitmap_NHIET;
        subMenu4->bitmaps[1] = &bitmap_ASY;
        subMenu4->bitmaps[2] = &bitmap_LENS;
        subMenu4->bitmaps[3] = &bitmap_PHIENBAN;
        subMenu4->bitmaps[4] = &bitmap_THOAT;

        subMenu4->MenuItems->ItemInfo.bitmaps[0] = bitmap_RIGHTSYMBOL;
        subMenu4->MenuItems->ItemInfo.bitmaps[1] = bitmap_RIGHTSYMBOL;
        subMenu4->MenuItems->ItemInfo.bitmaps[2] = bitmap_RIGHTSYMBOL;
        subMenu4->MenuItems->ItemInfo.bitmaps[3] = bitmap_RIGHTSYMBOL;
        subMenu4->MenuItems->ItemInfo.bitmaps[4] = bitmap_EXITSYMBOL;

    	//===========================================================================
        subMenu5->MenuItems->ItemValue.offset_x = 200;  // Set offset_x
        subMenu5->MenuItems->ItemValue.offset_y = 8;    // Set offset_y
        subMenu5->MenuItems->ItemValue.x = 65;          // Set x position
        subMenu5->MenuItems->ItemValue.y = 35;          // Set y position
        subMenu5->MenuItems->ItemValue.value = 0;      // Set value
        subMenu5->MenuItems->ItemValue.value_min = 0;   // Set minimum value
        subMenu5->MenuItems->ItemValue.value_max = 100; // Set maximum value
        subMenu5->MenuItems->ItemValue.value_step = 1;  // Set step size

        subMenu6->MenuItems->ItemValue.offset_x = 200;  // Set offset_x
        subMenu6->MenuItems->ItemValue.offset_y = 8;    // Set offset_y
        subMenu6->MenuItems->ItemValue.x = 65;          // Set x position
        subMenu6->MenuItems->ItemValue.y = 35;          // Set y position
        subMenu6->MenuItems->ItemValue.value = 0;      // Set value
        subMenu6->MenuItems->ItemValue.value_min = 0;   // Set minimum value
        subMenu6->MenuItems->ItemValue.value_max = 100; // Set maximum value
        subMenu6->MenuItems->ItemValue.value_step = 1;  // Set step size
    	//===========================================================================
        subMenu7->MenuItems->ItemSwitch.bitmaps = (bitmap_t**)malloc(2 * sizeof(bitmap_t*));
        subMenu7->MenuItems->ItemSwitch.offset_x = 190;
        subMenu7->MenuItems->ItemSwitch.offset_y = 8;
        subMenu7->MenuItems->ItemSwitch.x = 65;
        subMenu7->MenuItems->ItemSwitch.y = 35;

        subMenu7->MenuItems->ItemSwitch.value = 2;
        subMenu7->MenuItems->ItemSwitch.CurrentValues = 0;
        subMenu7->MenuItems->ItemSwitch.bitmaps[0] = &bitmap_BAT;
        subMenu7->MenuItems->ItemSwitch.bitmaps[1] = &bitmap_TAT;
    	//===========================================================================
        subMenu8->MenuItems->ItemSwitch.bitmaps = (bitmap_t**)malloc(2 * sizeof(bitmap_t*));
        subMenu8->MenuItems->ItemSwitch.offset_x = 190;
        subMenu8->MenuItems->ItemSwitch.offset_y = 8;
        subMenu8->MenuItems->ItemSwitch.x = 65;
        subMenu8->MenuItems->ItemSwitch.y = 35;

        subMenu8->MenuItems->ItemSwitch.value = 2;
        subMenu8->MenuItems->ItemSwitch.CurrentValues = 0;
        subMenu8->MenuItems->ItemSwitch.bitmaps[0] = &bitmap_BAT;
        subMenu8->MenuItems->ItemSwitch.bitmaps[1] = &bitmap_TAT;


        subMenu9->MenuItems->ItemValue.offset_x = 200;  // Set offset_x
        subMenu9->MenuItems->ItemValue.offset_y = 8;    // Set offset_y
        subMenu9->MenuItems->ItemValue.x = 65;          // Set x position
        subMenu9->MenuItems->ItemValue.y = 35;          // Set y position
        subMenu9->MenuItems->ItemValue.value = 0;      // Set value
        subMenu9->MenuItems->ItemValue.value_min = 0;   // Set minimum value
        subMenu9->MenuItems->ItemValue.value_max = 100; // Set maximum value
        subMenu9->MenuItems->ItemValue.value_step = 1;  // Set step size

        subMenu10->MenuItems->ItemValue.offset_x = 200;  // Set offset_x
        subMenu10->MenuItems->ItemValue.offset_y = 8;    // Set offset_y
        subMenu10->MenuItems->ItemValue.x = 65;          // Set x position
        subMenu10->MenuItems->ItemValue.y = 35;          // Set y position
        subMenu10->MenuItems->ItemValue.value = 0;      // Set value
        subMenu10->MenuItems->ItemValue.value_min = 0;   // Set minimum value
        subMenu10->MenuItems->ItemValue.value_max = 100; // Set maximum value
        subMenu10->MenuItems->ItemValue.value_step = 1;  // Set step size

        // Đánh dấu là mainMenu đã được cấp phát
        isMainMenuInitialized = 1;
    }
}

void TaskDemoMenu_ver1() {
    // Kiểm tra nút bấm và xử lý logic
	while(Menu_running == 0){
    check_button_hold();
    button_data_t button_val = UNKNOWN;
    int result = circ_bbuf_pop(&button_buffer, &button_val);
                if (SpaceCount == 1) {
                    // Hiển thị menu chính
                	ReplaceMenu =mainMenu;
                    DisplayMenu(ReplaceMenu, 255);
                    // Cập nhật các trang con nếu cần
                     UpdateChoosePageRows(ReplaceMenu, 0, 255);
                    printf("[DEBUG] button: M hold \n\r");
//                } else {
//                    printf("[DEBUG] button: M hold \n\r");
//                    EnterCount = 0;
//                    DisplayMenu(ReplaceMenu, 0);
//                    Menu_running = 1;
                }
    SpaceCount =0;
    if (result == 0) {
        switch ((int)button_val) {
        case HOLD_BUTTON_M:
          {
             printf("[DEBUG] button: M hold \n\r");
             EnterCount = 0;
             DisplayMenu(ReplaceMenu, 0);
             Menu_running = 1;
            break;
         }



           case PRESS_BUTTON_M:
             {
                printf("[DEBUG] button: M press \n\r");
                UpdateMenuLabel(ReplaceMenu, 1, &EnterCount, 255);
                UpdateMenuPageV2(ReplaceMenu, &ReplaceMenu, &MenuLevelIndex );
                if(MenuLevelIndex<0){
                    EnterCount = 0;
                    SpaceCount =0;
                    MenuLevelIndex +=1;
                }
               break;
            }

			 case PRESS_BUTTON_L:
			 {
			   if(SpaceCount ==0){
		          if(EnterCount == 0){
		            UpDownCount = 1;
		            UpdateChoosePageRows(ReplaceMenu, UpDownCount, 255);
		          }
		          else{
		            UpDownCount = 1;
		            SwitchLabelMenu(ReplaceMenu,UpDownCount, 255);
		            ControlValueLabelMenu(ReplaceMenu, UpDownCount, 255) ;
		            PrintNumber(ReplaceMenu, ReplaceMenu->MenuChildPage[ReplaceMenu->ParentRowsIndex]->MenuItems->ItemValue.value, CombinedMapOut,  255);
		          }
			   }
				 break;
			 }


			 case PRESS_BUTTON_R:
			 {
			    if(SpaceCount ==0){
		          if(EnterCount == 0){
		            UpDownCount = -1;
		            UpdateChoosePageRows(ReplaceMenu, UpDownCount, 255);
		          }
		          else{
		            UpDownCount = -1;
		            SwitchLabelMenu(ReplaceMenu,UpDownCount, 255);
		            ControlValueLabelMenu(ReplaceMenu, UpDownCount, 255) ;
		            PrintNumber(ReplaceMenu, ReplaceMenu->MenuChildPage[ReplaceMenu->ParentRowsIndex]->MenuItems->ItemValue.value, CombinedMapOut, 255);

		          }
			    }

				 break;
			 }


        }
    }
	}
}


void TaskDemoMenu() {
    // Kiểm tra nút bấm và xử lý logic
    check_button_hold();
    button_data_t button_val = UNKNOWN;
    int result = circ_bbuf_pop(&button_buffer, &button_val);
    if (result == 0) {
        switch ((int)button_val) {
            case HOLD_BUTTON_M:
                SpaceCount = (SpaceCount + 1) % 2;
                if (SpaceCount == 1) {
                    // Hiển thị menu chính
                	ReplaceMenu =mainMenu;
                    DisplayMenu(ReplaceMenu, 255);
                    // Cập nhật các trang con nếu cần
                     UpdateChoosePageRows(ReplaceMenu, 0, 255);
                    printf("[DEBUG] button: M hold \n\r");
                } else {
                    printf("[DEBUG] button: M hold \n\r");
                    EnterCount = 0;
                    DisplayMenu(ReplaceMenu, 0);
                }
                break;

            case PRESS_BUTTON_M:
            {
                printf("[DEBUG] button: M press \n\r");
                UpdateMenuLabel(ReplaceMenu, 1, &EnterCount, 255);
                UpdateMenuPageV2(ReplaceMenu, &ReplaceMenu, &MenuLevelIndex );
                if(MenuLevelIndex<0){
                    EnterCount = 0;
                    SpaceCount =0;
                    MenuLevelIndex +=1;
                }
               break;
            }

			 case PRESS_BUTTON_L:
			 {
			   if(SpaceCount ==1){
		          if(EnterCount == 0){
		            UpDownCount = 1;
		            UpdateChoosePageRows(ReplaceMenu, UpDownCount, 255);
		          }
		          else{
		            UpDownCount = 1;
		            SwitchLabelMenu(ReplaceMenu,UpDownCount, 255);
		            ControlValueLabelMenu(ReplaceMenu, UpDownCount, 255) ;
		            PrintNumber(ReplaceMenu, ReplaceMenu->MenuChildPage[ReplaceMenu->ParentRowsIndex]->MenuItems->ItemValue.value, CombinedMapOut,  255);
		          }
			   }
				 break;
			 }


			 case PRESS_BUTTON_R:
			 {
			    if(SpaceCount ==1){
		          if(EnterCount == 0){
		            UpDownCount = -1;
		            UpdateChoosePageRows(ReplaceMenu, UpDownCount, 255);
		          }
		          else{
		            UpDownCount = -1;
		            SwitchLabelMenu(ReplaceMenu,UpDownCount, 255);
		            ControlValueLabelMenu(ReplaceMenu, UpDownCount, 255) ;
		            PrintNumber(ReplaceMenu, ReplaceMenu->MenuChildPage[ReplaceMenu->ParentRowsIndex]->MenuItems->ItemValue.value, CombinedMapOut, 255);

		          }
			    }

				 break;
			 }


        }
    }
}















u32 start_time_compass = 0;
u32 start_time_GPS = 0;
int compass_val = 0;
void task_button_handler()
{
	//===========================================================================
	if(check_timeout_ms(start_time_compass, 15)){
		int compass_val = compass_get_val();
//		printf("[DEBUG] time: %ld \n\r", (get_time_value() - start_time_compass)/(XPAR_CPU_CORE_CLOCK_FREQ_HZ/1000));
//		printf("[DEBUG] compass_cur: %d \n\r", compass_cur);
		if(abs(compass_val - compass_ruler.value_cur) > 2)
		{
//		start_time_compass = get_time_value();
		graphic_update_compass_val(&compass_ruler, (compass_val++)%360, 255);
//		printf("[DEBUG] time: %ld \n\r", (get_time_value() - start_time_compass)/(XPAR_CPU_CORE_CLOCK_FREQ_HZ/1000));
		}
		start_time_compass = get_time_value();
	}



	if(check_timeout_ms(start_time_GPS, 2000)){
		start_time_GPS = get_time_value();
		GPS_test_get_value_v1(&longitude, &latitude, &check_out);
//        printf("\n%d \n\r", longitude);
//        printf("%d \n\r", latitude);
//		start_time_GPS = get_time_value();
		draw_check(check_out,255);
		graphic_update_GPS_val(&GPS_long_lat, longitude, latitude, 255); //20
//
		printf("%d\n\r",(int)(get_time_value() - start_time_GPS) / (XPAR_CPU_CORE_CLOCK_FREQ_HZ/1000));
		start_time_GPS = get_time_value();
	}

	//===========================================================================
	//check button hold;
	check_button_hold();

	//===========================================================================
	//check button
	button_data_t button_val = UNKNOWN;
	int result = circ_bbuf_pop(&button_buffer, &button_val);

	if(result == 0)
	{
		switch((int)button_val){
			//===================================
			case PRESS_BUTTON_L:
			{
				printf("[DEBUG] button: L \n\r");
				switch((int)processing_mode){
					case MODE_AGC:
					{
						set_edgeEnhan_param(0, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[contrast_level]);
						set_agc_param(agc_level_val[2]);
						graphic_draw_level_bar(&level_bar, dde_level+1); //cap nhat bar level
						graphic_draw_bitmap(&bitmap_AGC, -1, -1, 0); //xoa chu cu
						graphic_draw_bitmap(&bitmap_DDE, -1, -1, 255); //cap nhat chu
						alg_switch(MODE_DDE);
						processing_mode = MODE_DDE;
						printf("[DEBUG] MODE_DDE\n\r");
						break;
					}

					case MODE_DDE:
					{
						set_edgeEnhan_param(1, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[contrast_level]);
						set_agc_param(agc_level_val[2]);
						graphic_draw_level_bar(&level_bar, contrast_level+1); //cap nhat bar level
						graphic_draw_bitmap(&bitmap_DDE, -1, -1, 0); //xoa chu cu
						graphic_draw_bitmap(&bitmap_HL, -1, -1, 255); //cap nhat chu
						alg_switch(MODE_AGC);
						processing_mode = MODE_HL;
						printf("[DEBUG] MODE_HL\n\r");
						break;
					}

					case MODE_HL:
					{
						set_edgeEnhan_param(1, contrast_gain[edge_level], contrast_gamma[edge_level], 1, edge_gain[edge_level]);
						set_agc_param(agc_level_val[2]);
						graphic_draw_level_bar(&level_bar, edge_level+1); //cap nhat bar level
						graphic_draw_bitmap(&bitmap_HL, -1, -1, 0); //xoa chu cu
						graphic_draw_bitmap(&bitmap_OL, -1, -1, 255); //cap nhat chu
						alg_switch(MODE_AGC);
						processing_mode = MODE_OL;
						printf("[DEBUG] MODE_OL\n\r");
						break;
					}

					case MODE_OL:
					{
						set_edgeEnhan_param(0, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[contrast_level]);
						set_agc_param(agc_level_val[agc_level]);
						graphic_draw_level_bar(&level_bar, agc_level+1); //cap nhat bar level
						graphic_draw_bitmap(&bitmap_OL, -1, -1, 0); //xoa chu cu
						graphic_draw_bitmap(&bitmap_AGC, -1, -1, 255); //cap nhat chu
						alg_switch(MODE_AGC);
						processing_mode = MODE_AGC;
						printf("[DEBUG] MODE_AGC\n\r");
						break;
					}
				}

				break;
			}
			//===================================
			case PRESS_BUTTON_M:
			{
				printf("[DEBUG] button: M \n\r");
				cal_FFC_v2();
				break;
			}
			//===================================
			case PRESS_BUTTON_R:
			{
				printf("[DEBUG] button: R \n\r");
				switch((int)video_mode){
					case MODE_THERMAL:
					{
						lowlight_ctrl_pwr(true); //bat nguon low light
						video_mode = MODE_FUSION;
						graphic_draw_bitmap(&bitmap_thermal, -1, -1, 0);
						graphic_draw_bitmap(&bitmap_fusion, -1, -1, 255);
						break;
					}
					case MODE_FUSION:
					{
						oled_switch(); //tat oled
						video_mode = MODE_LOWLIGHT;
						graphic_draw_bitmap(&bitmap_fusion, -1, -1, 0);
						break;
					}
					case MODE_LOWLIGHT:
					{
						lowlight_ctrl_pwr(false); //tat nguon low light
						oled_switch(); //bat oled
						video_mode = MODE_THERMAL;
						graphic_draw_bitmap(&bitmap_thermal, -1, -1, 255);
						break;
					}
				}
				break;
			}
			//===================================
			case PRESS_BUTTON_RR:
			{
				printf("[DEBUG] button: RR \n\r");
				switch((int)processing_mode){
					case MODE_AGC:
					{
						agc_level++;
						if(agc_level >= MAX_BAR_LEVEL) agc_level = (MAX_BAR_LEVEL-1);
						set_agc_param(agc_level_val[agc_level]);
						graphic_draw_level_bar(&level_bar, agc_level+1); //cap nhat bar level
						break;
					}

					case MODE_DDE:
					{
						dde_level++;
						if(dde_level >= MAX_BAR_LEVEL) dde_level = (MAX_BAR_LEVEL-1);
						set_dde_param(dde_alpha[dde_level], dde_beta[dde_level], dde_lamda[dde_level]);
						graphic_draw_level_bar(&level_bar, dde_level+1); //cap nhat bar level
						break;
					}

					case MODE_HL:
					{
						contrast_level++;
						if(contrast_level >= MAX_BAR_LEVEL) contrast_level = (MAX_BAR_LEVEL-1);
						set_edgeEnhan_param(1, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[contrast_level]);
						graphic_draw_level_bar(&level_bar, contrast_level+1); //cap nhat bar level
						break;
					}

					case MODE_OL:
					{
						edge_level++;
						if(edge_level >= MAX_BAR_LEVEL) edge_level = (MAX_BAR_LEVEL-1);
						set_edgeEnhan_param(1, contrast_gain[edge_level], contrast_gamma[edge_level], 1, edge_gain[edge_level]);
						graphic_draw_level_bar(&level_bar, edge_level+1); //cap nhat bar level
						break;
					}
				}

				break;
			}
			//===================================
			case PRESS_BUTTON_RL:
			{
				printf("[DEBUG] button: RL \n\r");
				switch((int)processing_mode){
					case MODE_AGC:
					{
						agc_level--;
						if(agc_level < 0) agc_level = 0;
						set_agc_param(agc_level_val[agc_level]);
						graphic_draw_level_bar(&level_bar, agc_level+1); //cap nhat bar level
						break;
					}

					case MODE_DDE:
					{
						dde_level--;
						if(dde_level < 0) dde_level = 0;
						set_dde_param(dde_alpha[dde_level], dde_beta[dde_level], dde_lamda[dde_level]);
						graphic_draw_level_bar(&level_bar, dde_level+1); //cap nhat bar level
						break;
					}

					case MODE_HL:
					{
						contrast_level--;
						if(contrast_level < 0) contrast_level = 0;
						set_edgeEnhan_param(1, contrast_gain[contrast_level], contrast_gamma[contrast_level], 0, edge_gain[contrast_level]);
						graphic_draw_level_bar(&level_bar, contrast_level+1); //cap nhat bar level
						break;
					}

					case MODE_OL:
					{
						edge_level--;
						if(edge_level < 0) edge_level = 0;
						set_edgeEnhan_param(1, contrast_gain[edge_level], contrast_gamma[edge_level], 1, edge_gain[edge_level]);
						graphic_draw_level_bar(&level_bar, edge_level+1); //cap nhat bar level
						break;
					}
				}
				break;
			}
			//===================================
			case HOLD_BUTTON_L:
			{
				printf("[DEBUG] button: L hold \n\r");
				break;
			}
			//===================================
			case HOLD_BUTTON_R:
			{
				printf("[DEBUG] button: R hold \n\r");
				if(polarity_mode == MODE_IRONBOW)
				{
					polarity_mode = MODE_WHITEHOT;
					set_polarity_mode(polarity_mode, polarity_offset);
				}
				else
				{
					polarity_mode = MODE_IRONBOW;
					set_polarity_mode(polarity_mode, polarity_offset);
				}

				break;
			}
			//===================================
			case HOLD_BUTTON_M:
			{
				printf("[DEBUG] button: M hold \n\r");
				SpaceCount =1;
				TaskDemoMenu_ver1();
				Menu_running =0;
				break;
			}
		}
	}
}











static void set_edgeEnhan_param(int contrast_mode_val, int contrast_gain_val, int contrast_gamma_val, int edge_mode_val, int edge_gain_val)
{
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_CONTRAST_MODE, contrast_mode_val);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_CONTRAST_GAIN, contrast_gain_val);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_CONTRAST_GAMMA, contrast_gamma_val);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_EDGE_GAIN, edge_mode_val*edge_gain_val);

}

static void set_dde_param(int dde_alpha_val, int dde_beta_val, int dde_lamda_val)
{
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_DDE_ALPHA, dde_alpha_val);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_DDE_BETA, dde_beta_val);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_DDE_LAMDA, dde_lamda_val);
}

static void set_agc_param(int agc_paramK)
{
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_AGC_K, agc_paramK);
}

static void set_polarity_mode(int polarity_mode, int polarity_offset)
{
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_POLARITY_MODE, polarity_mode);
	Xil_Out32(PARAM_CTRL_ADDR + PARAM_OFFSET_POLARITY, polarity_offset); //{110, 128, 150, 175, 200};
}

static void init_bitmap_param()
{
	num_value_0.cols = BITMAP_NUMBER_WIDTH;
	num_value_0.rows = BITMAP_NUMBER_HEIGHT;
	num_value_0.x = 0;
	num_value_0.y = 0;
	num_value_0.num = 42;
	num_value_0.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER *0];

	bitmap_fusion.x = 700;
	bitmap_fusion.y = 555;
	bitmap_fusion.cols = 89;
	bitmap_fusion.rows = 38;
	bitmap_fusion.num = sizeof(bitmap_tron);
	bitmap_fusion.map = bitmap_tron;

	bitmap_thermal.x = 687;
	bitmap_thermal.y = 555;
	bitmap_thermal.cols = 98;
	bitmap_thermal.rows = 38;
	bitmap_thermal.num = sizeof(bitmap_nhiet);
	bitmap_thermal.map = bitmap_nhiet;

	bitmap_OL.x = 20;
	bitmap_OL.y = 555;
	bitmap_OL.cols = 77;
	bitmap_OL.rows = 38;
	bitmap_OL.num = sizeof(bitmap_vien);
	bitmap_OL.map = bitmap_vien;

	bitmap_HL.x = 20;
	bitmap_HL.y = 555;
	bitmap_HL.cols = 124;
	bitmap_HL.rows = 38;
	bitmap_HL.num = sizeof(bitmap_noibat);
	bitmap_HL.map = bitmap_noibat;

	bitmap_AGC.x = 20;
	bitmap_AGC.y = 555;
	bitmap_AGC.cols = 132;
	bitmap_AGC.rows = 38;
	bitmap_AGC.num = sizeof(bitmap_thuong);
	bitmap_AGC.map = bitmap_thuong;

	bitmap_DDE.x = 20;
	bitmap_DDE.y = 555;
	bitmap_DDE.cols = 132;
	bitmap_DDE.rows = 38;
	bitmap_DDE.num = sizeof(bitmap_chitiet);
	bitmap_DDE.map = bitmap_chitiet;

	bitmap_battery.x = 740;
	bitmap_battery.y = 20;
	bitmap_battery.cols = 40;
	bitmap_battery.rows = 20;
	bitmap_battery.num = sizeof(bitmap_pin);
	bitmap_battery.map = bitmap_pin;

	bitmap_Minus.x = 740;
	bitmap_Minus.y = 20;
	bitmap_Minus.cols = 16;
	bitmap_Minus.rows = 21;
	bitmap_Minus.num = sizeof(bitmap_compass_cursor);
	bitmap_Minus.map = bitmap_compass_cursor;

	bitmap_CAMBIEN.x = 740;
	bitmap_CAMBIEN.y = 20;
	bitmap_CAMBIEN.cols = 101;
	bitmap_CAMBIEN.rows = 32;
	bitmap_CAMBIEN.num = sizeof(CAMBIEN);
	bitmap_CAMBIEN.map = CAMBIEN;

	bitmap_ANHNHIET.x = 740;
	bitmap_ANHNHIET.y = 20;
	bitmap_ANHNHIET.cols = 114;
	bitmap_ANHNHIET.rows = 32;
	bitmap_ANHNHIET.num = sizeof(ANH_NHIET);
	bitmap_ANHNHIET.map = ANH_NHIET;

    bitmap_HETHONG.x = 740;
	bitmap_HETHONG.y = 20;
	bitmap_HETHONG.cols = 108;
	bitmap_HETHONG.rows = 32;
	bitmap_HETHONG.num = sizeof(HE_THONG);
	bitmap_HETHONG.map = HE_THONG;

    bitmap_THOAT.x = 740;
	bitmap_THOAT.y = 20;
	bitmap_THOAT.cols = 76;
	bitmap_THOAT.rows = 32;
	bitmap_THOAT.num = sizeof(THOAT);
	bitmap_THOAT.map = THOAT;

    bitmap_LABAN.x = 740;
	bitmap_LABAN.y = 20;
	bitmap_LABAN.cols = 79;
	bitmap_LABAN.rows = 32;
	bitmap_LABAN.num = sizeof(LA_BAN);
	bitmap_LABAN.map = LA_BAN;

    bitmap_GPS.x = 740;
	bitmap_GPS.y = 20;
	bitmap_GPS.cols = 39;
	bitmap_GPS.rows = 32;
	bitmap_GPS.num = sizeof(GPS);
	bitmap_GPS.map = GPS;

    bitmap_OLED.x = 740;
	bitmap_OLED.y = 20;
	bitmap_OLED.cols = 53;
	bitmap_OLED.rows = 32;
	bitmap_OLED.num = sizeof(OLED);
	bitmap_OLED.map = OLED;

    bitmap_HIEUCHUAN.x = 740;
	bitmap_HIEUCHUAN.y = 20;
	bitmap_HIEUCHUAN.cols = 131;
	bitmap_HIEUCHUAN.rows = 32;
	bitmap_HIEUCHUAN.num = sizeof(HIEU_CHUAN);
	bitmap_HIEUCHUAN.map = HIEU_CHUAN;

    bitmap_THONGTIN.x = 740;
	bitmap_THONGTIN.y = 20;
	bitmap_THONGTIN.cols = 117;
	bitmap_THONGTIN.rows = 32;
	bitmap_THONGTIN.num = sizeof(THONG_TIN);
	bitmap_THONGTIN.map = THONG_TIN;

    bitmap_DATLAI.x = 740;
	bitmap_DATLAI.y = 20;
	bitmap_DATLAI.cols = 88;
	bitmap_DATLAI.rows = 32;
	bitmap_DATLAI.num = sizeof(DAT_LAI);
	bitmap_DATLAI.map = DAT_LAI;

    bitmap_BAT.x = 740;
	bitmap_BAT.y = 20;
	bitmap_BAT.cols = 44;
	bitmap_BAT.rows = 32;
	bitmap_BAT.num = sizeof(BAT);
	bitmap_BAT.map = BAT;

    bitmap_TAT.x = 740;
	bitmap_TAT.y = 20;
	bitmap_TAT.cols = 45;
	bitmap_TAT.rows = 32;
	bitmap_TAT.num = sizeof(TAT);
	bitmap_TAT.map = TAT;

    bitmap_EXITSYMBOL.x = 740;
	bitmap_EXITSYMBOL.y = 20;
	bitmap_EXITSYMBOL.cols = 30;
	bitmap_EXITSYMBOL.rows = 30;
	bitmap_EXITSYMBOL.num = sizeof(EXIT_SYMBOL);
	bitmap_EXITSYMBOL.map = EXIT_SYMBOL;

    bitmap_RESETSYMBOL.x = 740;
	bitmap_RESETSYMBOL.y = 20;
	bitmap_RESETSYMBOL.cols = 30;
	bitmap_RESETSYMBOL.rows = 30;
	bitmap_RESETSYMBOL.num = sizeof(RESET_SYMBOL);
	bitmap_RESETSYMBOL.map = RESET_SYMBOL;

    bitmap_RIGHTSYMBOL.x = 740;
	bitmap_RIGHTSYMBOL.y = 20;
	bitmap_RIGHTSYMBOL.cols = 24;
	bitmap_RIGHTSYMBOL.rows = 30;
	bitmap_RIGHTSYMBOL.num = sizeof(RIGHT_SYMBOL);
	bitmap_RIGHTSYMBOL.map = RIGHT_SYMBOL;

    bitmap_PERCENT.x = 740;
	bitmap_PERCENT.y = 20;
	bitmap_PERCENT.cols = 19;
	bitmap_PERCENT.rows = 32;
	bitmap_PERCENT.num = sizeof(PERCENT_SYMBOL);
	bitmap_PERCENT.map = PERCENT_SYMBOL;

    bitmap_ZEROPERCENT.x = 740;
	bitmap_ZEROPERCENT.y = 20;
	bitmap_ZEROPERCENT.cols = 33;
	bitmap_ZEROPERCENT.rows = 32;
	bitmap_ZEROPERCENT.num = sizeof(ZERO_PERCENT_SYMBOL);
	bitmap_ZEROPERCENT.map = ZERO_PERCENT_SYMBOL;

    bitmap_HINHANH.x = 740;
	bitmap_HINHANH.y = 20;
	bitmap_HINHANH.cols = 105;
	bitmap_HINHANH.rows = 32;
	bitmap_HINHANH.num = sizeof(HINH_ANH);
	bitmap_HINHANH.map = HINH_ANH;

    bitmap_GSK.x = 740;
    bitmap_GSK.y = 20;
    bitmap_GSK.cols = 41;
    bitmap_GSK.rows = 32;
    bitmap_GSK.num = sizeof(GSK);
    bitmap_GSK.map = GSK;

    bitmap_GSID.x = 740;
    bitmap_GSID.y = 20;
    bitmap_GSID.cols = 48;
    bitmap_GSID.rows = 32;
    bitmap_GSID.num = sizeof(GSID);
    bitmap_GSID.map = GSID;

    bitmap_NHIETMAU.x = 740;
    bitmap_NHIETMAU.y = 20;
    bitmap_NHIETMAU.cols = 119;
    bitmap_NHIETMAU.rows = 32;
    bitmap_NHIETMAU.num = sizeof(NHIET_MAU);
    bitmap_NHIETMAU.map = NHIET_MAU;

    bitmap_DOSANG.x = 740;
    bitmap_DOSANG.y = 20;
    bitmap_DOSANG.cols = 99;
    bitmap_DOSANG.rows = 32;
    bitmap_DOSANG.num = sizeof(DO_SANG);
    bitmap_DOSANG.map = DO_SANG;

    bitmap_TUONGPHAN.x = 740;
    bitmap_TUONGPHAN.y = 20;
    bitmap_TUONGPHAN.cols = 146;
    bitmap_TUONGPHAN.rows = 32;
    bitmap_TUONGPHAN.num = sizeof(TUONG_PHAN);
    bitmap_TUONGPHAN.map = TUONG_PHAN;

    bitmap_NHIET.x = 740;
    bitmap_NHIET.y = 20;
    bitmap_NHIET.cols = 61;
    bitmap_NHIET.rows = 32;
    bitmap_NHIET.num = sizeof(NHIET);
    bitmap_NHIET.map = NHIET;

    bitmap_ASY.x = 740;
    bitmap_ASY.y = 20;
    bitmap_ASY.cols = 43;
    bitmap_ASY.rows = 32;
    bitmap_ASY.num = sizeof(ASY);
    bitmap_ASY.map = ASY;

    bitmap_LENS.x = 740;
    bitmap_LENS.y = 20;
    bitmap_LENS.cols = 49;
    bitmap_LENS.rows = 32;
    bitmap_LENS.num = sizeof(LENS);
    bitmap_LENS.map = LENS;

    bitmap_PHIENBAN.x = 740;
    bitmap_PHIENBAN.y = 20;
    bitmap_PHIENBAN.cols = 110;
    bitmap_PHIENBAN.rows = 32;
    bitmap_PHIENBAN.num = sizeof(PHIEN_BAN);
    bitmap_PHIENBAN.map = PHIEN_BAN;

}









