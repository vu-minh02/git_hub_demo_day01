#ifndef SRC_IIC_H_
#define SRC_IIC_H_

#include <stdint.h>

int iic_Init(uint32_t BaseAddr);
int iic_WriteReg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr, uint8_t u8RegVal);
uint8_t iic_ReadReg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr);

#endif /* SRC_IIC_H_ */
