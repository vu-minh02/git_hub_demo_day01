#include "iic.h"
#include "xiic.h"
#include <stdio.h>

#include <stdint.h>

int iic_Init(uint32_t BaseAddr)
{
	/* Initialize the GPIO driver */
	int Status = XIic_DynInit(BaseAddr);
	return Status;
}

int iic_WriteReg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr, uint8_t u8RegVal)
{
	static uint8_t fix = 0;
	int i;
	uint8_t SentByteCount = 0;
	uint8_t StatusReg;

	uint8_t pI2cDataSend[2];
	pI2cDataSend[0] = u8RegAddr;
	pI2cDataSend[1] = u8RegVal;
	if(fix == 0){
		printf("[INFO] Fix iic 1\r\n");
		fix = 1;
	}

#if 1
	// Make sure all the Fifo's are cleared and Bus is Not busy.
	do
	{
		StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
		StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK |
				XIIC_SR_BUS_BUSY_MASK);
	} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
			XIIC_SR_TX_FIFO_EMPTY_MASK));
#endif

	if(fix == 1){
		printf("[INFO] Fix iic 2\r\n");
		fix = 2;
	}

	SentByteCount = (uint8_t)XIic_DynSend((uint32_t) BaseAddr, SlaveAddr, &pI2cDataSend[0], (uint8_t) 2, (uint8_t) XIIC_STOP);
	if(SentByteCount < 1)
	{
		return SentByteCount;
	}
	for(i = 0; i < 100; i++);

	return XST_SUCCESS;
}

uint8_t iic_ReadReg(uint32_t BaseAddr, uint8_t SlaveAddr, uint8_t u8RegAddr)
{
	uint8_t u8DataRecv = 0xFF;
	int cnt = 0;
	uint8_t StatusReg;
	uint8_t SentByteCount = 0;

//	SlaveAddr = SlaveAddr>>1;

#if 1
	// Make sure all the Fifo's are cleared and Bus is Not busy.
	do
	{
		StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
		StatusReg = StatusReg & (XIIC_SR_RX_FIFO_EMPTY_MASK |
				XIIC_SR_TX_FIFO_EMPTY_MASK |
				XIIC_SR_BUS_BUSY_MASK);
	} while (StatusReg != (XIIC_SR_RX_FIFO_EMPTY_MASK |
			XIIC_SR_TX_FIFO_EMPTY_MASK));
#endif

	// Position the Read pointer to specific location.
	do
	{
		StatusReg = Xil_In8(BaseAddr + XIIC_SR_REG_OFFSET);
		if(!(StatusReg & XIIC_SR_BUS_BUSY_MASK))
		{
			SentByteCount = (uint8_t)XIic_DynSend(BaseAddr, SlaveAddr,
								(uint8_t *)&u8RegAddr, 1,
								(uint8_t)XIIC_REPEATED_START);
		}
		cnt++;
	}while(SentByteCount != 1 && (cnt < 100));

	// Error writing chip address so return SentByteCount
	if (SentByteCount < 1)
	{
		return SentByteCount;
	}

	// Receive data
	XIic_DynRecv((uint32_t) BaseAddr, SlaveAddr, &u8DataRecv, (unsigned) 1);

	return u8DataRecv;
}
