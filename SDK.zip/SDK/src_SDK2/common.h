/*
 * common.h
 *
 *  Created on: May 5, 2024
 *      Author: huongdh7
 */

#ifndef SRC_COMMON_H_
#define SRC_COMMON_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include "platform.h"
#include "xil_printf.h"
#include "xparameters.h"
#include "xgpio.h"
#include "microblaze_sleep.h"
#include "xiic.h"
#include "xil_cache.h"
#include "string.h"
#include "xuartlite.h"
#include "xtmrctr.h"
#include "xppk_zoom.h"
#include "xip_param_ctrl.h"
//==============================================================================
#define MAX_WIDTH_OUT			2100
#define MAX_HEIGHT_OUT			1700

#define OLED_WIDTH				800
#define OLED_HEIGHT				600

#define IR_WIDTH				640
#define IR_HEIGHT				480

#define PREPROCESSING_WIDTH		640
#define PREPROCESSING_HEIGHT	480

#define ANALOG_WIDTH			720
#define ANALOG_HEIGHT			576

//==============================================================================

#define BUFFER_START_BASEADDR					XPAR_CPU_MIG_7SERIES_0_BASEADDR		+	0x01000000
#define BUFFER_OLED_OUT_BASEADDR_1				BUFFER_START_BASEADDR				+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT
#define BUFFER_OLED_OUT_BASEADDR_2				BUFFER_OLED_OUT_BASEADDR_1			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_OLED_OUT_BASEADDR_3				BUFFER_OLED_OUT_BASEADDR_2			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_OLED_OUT_BASEADDR_4				BUFFER_OLED_OUT_BASEADDR_3			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3

#define BUFFER_IR_IN_BASEADDR_1					BUFFER_OLED_OUT_BASEADDR_4			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_IR_IN_BASEADDR_2					BUFFER_IR_IN_BASEADDR_1				+	IR_WIDTH*IR_HEIGHT*2
#define BUFFER_IR_IN_BASEADDR_3					BUFFER_IR_IN_BASEADDR_2				+	IR_WIDTH*IR_HEIGHT*2

#define BUFFER_IN_BASEADDR_1					BUFFER_IR_IN_BASEADDR_3				+	IR_WIDTH*IR_HEIGHT*2
#define BUFFER_IN_BASEADDR_2					BUFFER_IN_BASEADDR_1				+	IR_WIDTH*IR_HEIGHT*2
#define BUFFER_IN_BASEADDR_3					BUFFER_IN_BASEADDR_2				+	IR_WIDTH*IR_HEIGHT*2
#define BUFFER_IN_BASEADDR_4					BUFFER_IN_BASEADDR_3				+	IR_WIDTH*IR_HEIGHT*2

#define BUFFER_ANALOG_OUT_BASEADDR_1			BUFFER_IN_BASEADDR_4				+	IR_WIDTH*IR_HEIGHT*2
#define BUFFER_ANALOG_OUT_BASEADDR_2			BUFFER_ANALOG_OUT_BASEADDR_1		+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_ANALOG_OUT_BASEADDR_3			BUFFER_ANALOG_OUT_BASEADDR_2		+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3

#define BUFFER_ANALOG_BASEADDR_1				BUFFER_ANALOG_OUT_BASEADDR_3		+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_ANALOG_BASEADDR_2				BUFFER_ANALOG_BASEADDR_1			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_ANALOG_BASEADDR_3				BUFFER_ANALOG_BASEADDR_2			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_ANALOG_BASEADDR_4				BUFFER_ANALOG_BASEADDR_3			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3

#define BUFFER_TEMPLATE_BASEADDR_1				BUFFER_ANALOG_BASEADDR_4			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3

#define BUFFER_ODDEVEN_BASEADDR_1				BUFFER_TEMPLATE_BASEADDR_1			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3

#define BUFFER_GAIN_BASEADDR					BUFFER_ODDEVEN_BASEADDR_1			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*3
#define BUFFER_OFFSET_BASEADDR					BUFFER_GAIN_BASEADDR				+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*2
#define BUFFER_IMFLATFIELD_BASEADDR				BUFFER_OFFSET_BASEADDR				+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*2

#define BUFFER_COMPASS_BASEADDR					BUFFER_IMFLATFIELD_BASEADDR			+	MAX_WIDTH_OUT*MAX_HEIGHT_OUT*2

//==============================================================================
#define CONTROL_GAIN		0
#define CONTROL_THRESHOLD	1
#define CONTROL_BRIGHTNESS	2

#define DISPLAY_INFARED		0
#define DISPLAY_OUTLINE		1

//==============================================================================
#define PARAM_CTRL_ADDR 				XPAR_IR_PREPROCESSING_PARAM_CTRL_IP_PARAM_CTRL_0_S_AXI_CONTROL_BUS_BASEADDR
#define PARAM_OFFSET_CONTRAST_MODE  	XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_0_DATA
#define PARAM_OFFSET_CONTRAST_GAIN  	XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_1_DATA
#define PARAM_OFFSET_CONTRAST_GAMMA  	XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_2_DATA
#define PARAM_OFFSET_EDGE_GAIN  		XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_3_DATA
#define PARAM_OFFSET_POLARITY_MODE 		XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_4_DATA
#define PARAM_OFFSET_POLARITY 			XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_5_DATA
#define PARAM_DDE_ALPHA 				XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_6_DATA
#define PARAM_DDE_BETA 					XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_7_DATA
#define PARAM_DDE_LAMDA 				XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_8_DATA
#define PARAM_AGC_K 					XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_9_DATA
#define PARAM_LOW_LIGHT_PWR 			XIP_PARAM_CTRL_CONTROL_BUS_ADDR_PARAM_10_DATA
//==============================================================================
void init_axi_vdma_ir_in(int writeOn, int readOn);

void init_axi_vdma_in(int writeOn, int readOn);

void init_axi_vdma_oled_out(int writeOn, int readOn);

void init_axi_vdma_analogout_zoom(int writeOn, int readOn);

void init_axi_vdma_oledout_zoom(int writeOn, int readOn, int in_cols, int in_rows, int offset_cols, int offset_rows);

void init_axi_vdma_analog_zoom(int writeOn, int readOn);

void init_axi_vdma_analog_test(u32 addr, int writeOn, int readOn);

void init_axi_vdma_template(int writeOn, int readOn);

void init_axi_vdma_oddeven(int writeOn, int readOn);

void init_axi_vdma_nuc2p(int writeOn, int readOn);

void init_axi_vdma_imff(int writeOn, int readOn);

void s2mm_oddeven_init();

void switch_in(int channel);

void switch_out(int channel);

void alg_switch(int mode);

void switch_imageEnhan(int channel);

void cal_FFC_v2();

void init_zoom800x600(int cols, int rows);

void init_axi_vdma_osd(int writeOn, int readOn);

void init_param_ctrl();

#endif /* SRC_COMMON_H_ */
