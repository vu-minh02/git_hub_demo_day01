/******************************************************************************
*
* Copyright (C) 2009 - 2014 Xilinx, Inc.  All rights reserved.
*
* Permission is hereby granted, free of charge, to any person obtaining a copy
* of this software and associated documentation files (the "Software"), to deal
* in the Software without restriction, including without limitation the rights
* to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
* copies of the Software, and to permit persons to whom the Software is
* furnished to do so, subject to the following conditions:
*
* The above copyright notice and this permission notice shall be included in
* all copies or substantial portions of the Software.
*
* Use of the Software is limited solely to applications:
* (a) running on a Xilinx device, or
* (b) that interact with a Xilinx device through a bus or interconnect.
*
* THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
* IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
* FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL
* XILINX  BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY,
* WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF
* OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE
* SOFTWARE.
*
* Except as contained in this notice, the name of the Xilinx shall not be used
* in advertising or otherwise to promote the sale, use or other dealings in
* this Software without prior written authorization from Xilinx.
*
******************************************************************************/

/*
 * helloworld.c: simple test application
 *
 * This application configures UART 16550 to baud rate 9600.
 * PS7 UART (Zynq) is not initialized by this application, since
 * bootrom/bsp configures it to baud rate 115200
 *
 * ------------------------------------------------
 * | UART TYPE   BAUD RATE                        |
 * ------------------------------------------------
 *   uartns550   9600
 *   uartlite    Configurable only in HW design
 *   ps7_uart    115200 (configured by bootrom/bsp)
 */

#include <stdio.h>
#include "platform.h"
#include "xil_printf.h"
#include "sleep.h"
#include "common.h"
#include "peripheral/oled.h"
#include "peripheral/adv7393.h"
#include "lib/iic.h"
#include "peripheral/lynred_k613d.h"
#include "button.h"
#include "demo.h"
#include "peripheral/spi_flash.h"
#include "peripheral/compass.h"
#include "peripheral/GPS.h"
#include "peripheral/VCNL4040.h"
#include "graphic/menu_knd.h"
#include "graphic/menu_lib.h"

u32 start_time_fps = 0;


int main()
{

    init_platform();
    printf("Hello huongdh7\n\r");
    int Status = 0;
    //============================================================
    compass_iic_init();
    compass_sensor_config(); //co tinh trang khi khoi tao bi treo o ham nay

    //============================================================
   //============================================================

//# if 1

	printf("[INFO] init vdma\r\n");
	init_axi_vdma_in(1, 1);
	init_axi_vdma_osd(1, 1);
	init_axi_vdma_oledout_zoom(1, 1, 800, 600, 0, 0);
	init_axi_vdma_nuc2p(0, 1);
	init_axi_vdma_imff(1, 1);
	init_axi_vdma_analog_test(XPAR_ANALOG_OUT_VDMA_ANALOG_ODD_BASEADDR, 1, 1);
	init_axi_vdma_analog_test(XPAR_ANALOG_OUT_VDMA_ANALOG_EVEN_BASEADDR, 1, 1);

    //============================================================
//# if 0
	printf("[INFO] init alg_switch\r\n");
	int mode_processing = 0;
	alg_switch(mode_processing);

	//============================================================
	printf("[INFO] init proxy lynred\r\n");
	lynredK613d_init_ctrl();

	//============================================================
	printf("[INFO] init oled\r\n");
	init_oled();
	usleep(100000);

	//============================================================
	printf("[INFO] init adv7393\r\n");
	adv7393_init();
//	iic_ReadReg(XPAR_ANALOG_OUT_IIC_ANALOGOUT_BASEADDR, 0x2A, 0x80); //dang co loi khong doc duoc iic

	//============================================================
	printf("[INFO] init zoom 800x600\r\n");
	init_zoom800x600(IR_WIDTH, IR_HEIGHT);

	//============================================================
	printf("[INFO] init param ctrl\r\n");
	init_param_ctrl();

	printf("[INFO] init timer\r\n");
	init_timer();

	printf("[INFO] init gpio_button\r\n");
	init_button();

	printf("[INFO] init task button\r\n");
	task_button_init();

	//============================================================
	// Khoi tao gpio read FPS
    XGpio gpio_frame_counter;
	Status = XGpio_Initialize(&gpio_frame_counter, XPAR_IR_PREPROCESSING_READ_FPS_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return 0;
	}
	XGpio_SetDataDirection(&gpio_frame_counter, 1, 1);
	XGpio_SetDataDirection(&gpio_frame_counter, 2, 1);

	//============================================================
    printf("[INFO] init spi_flash\r\n");
    Status = init_spi_flash();
	if (Status != XST_SUCCESS) {
		printf("[INFO] init spi_flash XST_FAILURE\r\n");
	}

	//============================================================
	printf("[INFO] init setupInterrupt\r\n");
	Status = setupInterrupt();
	if (Status != XST_SUCCESS) {
		printf("[INFO] init setupInterrupt XST_FAILURE \n\r");
	}
	//============================================================
# if 0
	printf("[INFO] read nuc2p\r\n");
    read_nuc();
#endif
	//============================================================
    int check_out_main =0;
    light_sensor_iic_Initialize();
    GPS_test_init_v1(&check_out_main);
	//============================================================
//    VCNL4040_iic_Initialize();
//    VCNL4040();

	//============================================================
    TaskDemoMenu_init();
    printf("[INFO] LOOP BEGIN\r\n");
    while(1)
    {
    	//===========================================================================
    	//check fps 30s
    	if(check_timeout_ms(start_time_fps, 30000)){
    		start_time_fps = get_time_value();
    		int a = XGpio_DiscreteRead(&gpio_frame_counter, 1) & 0xFF;
    		int b = XGpio_DiscreteRead(&gpio_frame_counter, 1) >> 16;
    		int c = XGpio_DiscreteRead(&gpio_frame_counter, 2);
    		printf("[DEBUG] FPS_in: %d  FPS_txl: %d  FPS_oled: %d \n\r", a, b, c);
    	}

    	//===========================================================================

    	task_button_handler();
//    	TaskDemoMenu();

    	//===========================================================================
    }
    cleanup_platform();
    return 0;
}

