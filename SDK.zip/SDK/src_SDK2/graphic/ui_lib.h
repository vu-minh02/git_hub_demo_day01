/*
 * common.h
 *
 *  Created on: 11/2024
 *      Author: huongdh7
 */

#ifndef SRC_UI_LIB_H_
#define SRC_UI_LIB_H_

#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <stdint.h>
#include <stdbool.h>
#include "string.h"

//=============================================
extern uint8_t bitmap_pin[225];
extern uint8_t bitmap_vien[366];
extern uint8_t bitmap_tron[423];
extern uint8_t bitmap_thuong[627];
extern uint8_t bitmap_noibat[589];
extern uint8_t bitmap_nhiet[466];
extern uint8_t bitmap_chitiet[627];
extern uint8_t bitmap_kinhdo[252];
extern uint8_t bitmap_vido[252];
extern uint8_t bitmap_dautru[42];
extern uint8_t bitmap_daucham[32];

//=============================================
extern uint8_t bitmap_number[420];
extern uint8_t bitmap_space[42];

#define BITMAP_NUMBER_WIDTH			16
#define BITMAP_NUMBER_HEIGHT		21
#define BITMAP_NUMBYTE_OF_1NUMBER	42
//=============================================
extern uint8_t CAMBIEN[404];
extern uint8_t ANH_NHIET[468];
extern uint8_t HE_THONG[449];
extern uint8_t THOAT[341];
extern uint8_t LA_BAN[316];
extern uint8_t GPS[156];
extern uint8_t DAT_LAI[352];
extern uint8_t OLED[254];
extern uint8_t HIEU_CHUAN[525];
extern uint8_t THONG_TIN[468];
extern uint8_t BAT[254];
extern uint8_t TAT[253];
extern uint8_t EXIT_SYMBOL[113];
extern uint8_t RESET_SYMBOL[113];
extern uint8_t RIGHT_SYMBOL[90];
extern uint8_t ZERO_PERCENT_SYMBOL[132];
extern uint8_t PERCENT_SYMBOL[76];
extern uint8_t HINH_ANH[420];
extern uint8_t GSK[164];
extern uint8_t GSID[192];
extern uint8_t LENS[196];
extern uint8_t ASY[172];
extern uint8_t NHIET_MAU[476];
extern uint8_t NHIET[244];
extern uint8_t PHIEN_BAN[440];
extern uint8_t TUONG_PHAN[584];
extern uint8_t DO_SANG[396];


//=============================================
extern uint8_t bitmap_compass[4320];
extern uint8_t bitmap_compass_cursor[9];

#define COMPASS_RULER_WIDTH_TICK		48
#define COMPASS_RULER_DEGREE_PER_TICK	15
#define COMPASS_RULER_WIDTH 			(COMPASS_RULER_WIDTH_TICK*24)
#define COMPASS_RULER_HEIGHT			30
#define COMPASS_RULER_OFFSET 			7.5

#define COMPASS_CURSOR_WIDTH		12
#define COMPASS_CURSOR_HEIGHT		6

//=============================================
typedef struct bitmap
{
	int x;
	int y;
    uint16_t cols;
    uint16_t rows;

    int num;
    uint8_t *map;
} bitmap_t;



typedef struct
{
	uint16_t x;
	uint16_t y;
    uint16_t cols;
    uint16_t rows;
    uint16_t border;
} rectangle_t;

typedef struct
{
	uint16_t x;
	uint16_t y;
    uint16_t cols;
    uint16_t rows;
    uint16_t level_cur;
} level_bar_t;

typedef struct
{
	uint16_t x;
	uint16_t y;
    uint16_t window_cols;
    uint32_t buffer_addr;
    int value_cur;
} compass_ruler_t;


typedef struct
{
	int cur_kinh_do;
	int cur_vi_do;
}  GPS_t;

void graphic_init(uint32_t buffer_addr, int width, int height);
void graphic_draw_bitmap(bitmap_t *bitmap, int x, int y, uint8_t color);
void graphic_draw_retangle(rectangle_t *rectangle, int x, int y, uint8_t color);
void graphic_draw_level_bar(level_bar_t *level_bar, int level);
void graphic_init_compass(compass_ruler_t *compass_ruler);
void graphic_draw_compass_ruler(compass_ruler_t *compass_ruler, int value);
void graphic_draw_compass_val(compass_ruler_t *compass_ruler, int value, uint8_t color);
void graphic_update_compass_val(compass_ruler_t *compass_ruler, int value, uint8_t color);
void graphic_draw_longitude_val(int value, uint8_t color);
void graphic_draw_latitude_val(int value, uint8_t color) ;
void graphic_update_GPS_val( GPS_t *GPS_log_lat,int kinh_do,int vi_do, uint8_t color);
void graphic_init_GPS(int longitude, int latitude,  uint8_t color);
void draw_check(int value, uint8_t color);

// update interface
void GraphicDrawChooseBitmap(bitmap_t *bitmap, int x, int y, uint8_t color);
void GraphicFullFillRetangle(rectangle_t *rectangle, int x, int y, uint8_t color);
#endif
