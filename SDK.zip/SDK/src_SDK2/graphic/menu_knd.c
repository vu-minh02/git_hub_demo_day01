#include "menu_lib.h"
#include "menu_knd.h"


#if 0
// Hàm khởi tạo menu với tham số mặc định
MenuPage_t* createMenuPage(int x, int y, int Hsize, int VsizeRows, int PageIndex, int PageRows,
                           int ParentPageIndex, int ParentRowsIndex) {
    MenuPage_t* newMenuPage = (MenuPage_t*)malloc(sizeof(MenuPage_t));
    if (newMenuPage == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    newMenuPage->x = x;
    newMenuPage->y = y;
    newMenuPage->Hsize = Hsize;
    newMenuPage->VsizeRows = VsizeRows;
    newMenuPage->PageIndex = PageIndex;
    newMenuPage->PageRows = PageRows;
    newMenuPage->ParentPageIndex = ParentPageIndex;
    newMenuPage->ParentRowsIndex = ParentRowsIndex;
    newMenuPage->MenuChildPage = NULL;
    newMenuPage->MenuParentPage = NULL;
    newMenuPage->bitmaps = NULL; // Đây có thể được khởi tạo sau

    return newMenuPage;
}


// Hàm hiển thị menu
void DisplayMenu(MenuPage_t *MenuPage, int x, int y, uint8_t color) {
    // Vẽ khung menu
    if (x > 0) MenuPage->x = x;
    if (y > 0) MenuPage->y = y;

    int WindowWidth = MenuPage->Hsize;
    int WindowHeight = MenuPage->PageRows *(MenuPage->VsizeRows) ; // Dùng một số cụ thể cho chiều cao của mỗi hàng

    rectangle_t MenuBorder = {MenuPage->x, MenuPage->y, WindowWidth + 4, WindowHeight + 4, 2};
    graphic_draw_retangle(&MenuBorder, -1, -1, color);

    // Vẽ các bitmap trong menu
    for (int i = 0; i < MenuPage->PageRows; i++) {
        if (MenuPage->bitmaps[i] != NULL) {
            graphic_draw_bitmap(MenuPage->bitmaps[i], MenuPage->x, (MenuPage->y) + i * MenuPage->VsizeRows, color);
        }
    }

    // Ve cac label trong menu
    uint8_t OffSetX =0 ;
    OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;

    for (int i = 0; i < MenuPage-> PageRows; i++) {
            if (MenuPage->MenuItems->ItemInfo.bitmaps[i] != NULL) {
                graphic_draw_bitmap(MenuPage->MenuItems->ItemInfo.bitmaps[i], (MenuPage->x) + OffSetX, (MenuPage->y) + i * MenuPage->VsizeRows, color);
            }
        }
}

void UpdateChoosePageRows(MenuPage_t *MenuPage, int RowsIndex, uint8_t color) {
    // Bỏ chọn hàng đang trước
	rectangle_t rectangle ;
	rectangle.cols = MenuPage->Hsize;
	rectangle.rows = MenuPage->VsizeRows;
	uint8_t OffSetX =0 ;
	if(RowsIndex >= 0){
      if (MenuPage->bitmaps[RowsIndex - 1] != NULL) {
          OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
          graphic_draw_bitmap(MenuPage->bitmaps[RowsIndex - 1], MenuPage->x, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
          graphic_draw_bitmap(MenuPage->MenuItems->ItemInfo.bitmaps[RowsIndex - 1], (MenuPage->x) + OffSetX, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
      }
	}
    else{
    	OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
    	graphic_draw_bitmap(MenuPage->bitmaps[MenuPage->PageRows - 1], MenuPage->x, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
    	graphic_draw_bitmap(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->PageRows - 1], (MenuPage->x) + OffSetX, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
    }

      // Chọn hàng hiện tại
      if (MenuPage->bitmaps[RowsIndex] != NULL) {
    	  GraphicFullFillRetangle(&rectangle, MenuPage->x, (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
          GraphicDrawChooseBitmap(MenuPage->bitmaps[RowsIndex], MenuPage->x, (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
          GraphicDrawChooseBitmap(MenuPage->MenuItems->ItemInfo.bitmaps[RowsIndex - 1], (MenuPage->x) + OffSetX, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
      }

}


#if 0
// Cập nhật lựa chọn hàng trong menu
void UpdateChoosePageRows(MenuPage_t *MenuPage, int RowsIndex, uint8_t color) {
    // Bỏ chọn hàng đang trước
    if (MenuPage->bitmaps[RowsIndex - 1] != NULL) {
        graphic_draw_bitmap(MenuPage->bitmaps[RowsIndex - 1], MenuPage->x, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows, color);
    }

    // Chọn hàng hiện tại
    if (MenuPage->bitmaps[RowsIndex] != NULL) {
        GraphicDrawChooseBitmap(MenuPage->bitmaps[RowsIndex], MenuPage->x, (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
    }
}


// Cập nhật trang menu (thay đổi giữa trang con và trang cha)
void UpdateMenuPage(MenuPage_t *MenuPage, MenuPage_t **MenuReplacePage, int MenuLevelIndex, int RowsIndex) {
    // Kiểm tra nếu MenuPage có cấp độ thấp hơn MenuLevelIndex, thay đổi sang trang con
    if (MenuPage->PageIndex < MenuLevelIndex) {
        if (MenuPage->MenuChildPage != NULL && RowsIndex >= 0) {
            // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL
            if (MenuPage->MenuChildPage[RowsIndex] != NULL) {
                *MenuReplacePage = MenuPage->MenuChildPage[RowsIndex];  // Cập nhật trang thay thế là trang con
            }
        }
    } else {
        // Nếu MenuPage có cấp độ lớn hơn hoặc bằng MenuLevelIndex, thay đổi sang trang cha
        if (MenuPage->MenuParentPage != NULL && RowsIndex >= 0) {
            *MenuReplacePage = MenuPage->MenuParentPage;  // Cập nhật trang thay thế là trang cha
        }
    }
}
#endif

void UpdateMenuPage(MenuPage_t *MenuPage, MenuPage_t **MenuReplacePage, int MenuLevelIndex, int RowsIndex) {
    // Kiểm tra nếu MenuPage có cấp độ thấp hơn MenuLevelIndex, thay đổi sang trang con
    if (MenuPage->PageIndex < MenuLevelIndex) {
        if (MenuPage->MenuChildPage != NULL && RowsIndex >= 0) {
            // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL và ItemType khác ITEM_SUBMENU
            if (MenuPage->MenuChildPage[RowsIndex] != NULL &&
                MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemsType == ITEM_SUBMENU) {
                *MenuReplacePage = MenuPage->MenuChildPage[RowsIndex];  // Cập nhật trang thay thế là trang con
            }
        }
    } else {
        // Nếu MenuPage tro den EXIT, thay đổi sang trang cha
        if (MenuPage->MenuParentPage != NULL && RowsIndex >= 0) {
            *MenuReplacePage = MenuPage->MenuParentPage;  // Cập nhật trang thay thế là trang cha
        }
        else{
        	 *MenuReplacePage = MenuPage;
        }
    }

}

// ham nay khong dung duoc
void UpdateMenuPageV2(MenuPage_t *MenuPage, int *MenuLevelIndex, int RowsIndex) {
    // Kiểm tra nếu MenuPageRows có cấp độ thấp hơn MenuSiblingIndex, thay đổi sang trang con
    if (MenuPage->PageRows < RowsIndex) {
        if (MenuPage->MenuChildPage != NULL && RowsIndex >= 0) {
            // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL và ItemType la ITEM_SUBMENU
            if (MenuPage->MenuChildPage[RowsIndex] != NULL &&
                MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemsType == ITEM_SUBMENU) {
                MenuPage = MenuPage->MenuChildPage[RowsIndex];  // Cập nhật trang thay thế là trang con
                *MenuLevelIndex += 1;
            }
            else{
            	*MenuLevelIndex -= 1;
            }
        }
    } else {
        // Nếu MenuPage tro den EXIT, thay đổi sang trang cha
        if (MenuPage->MenuParentPage != NULL && RowsIndex >= 0) {
            MenuPage = MenuPage->MenuParentPage;  // Cập nhật trang thay thế là trang cha
        }
    }

}
//==================================================================================================================

void UpdateMenuLabel(MenuPage_t *MenuPage, int MenuLevelIndex,int RowsIndex,int *LabelMode,uint8_t color){
	uint8_t OffSetX =0 ;
	uint8_t OffSetY =0 ;
	OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
	OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
    if (MenuPage->PageRows < RowsIndex) {
        if (MenuPage->MenuChildPage != NULL && RowsIndex >= 0) {
            // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL và ItemType khác ITEM_SUBMENU
            if (MenuPage->MenuChildPage[RowsIndex] != NULL &&
                MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemsType != ITEM_SUBMENU) {
            	*LabelMode += 1;
            	*LabelMode = ((*LabelMode) % 2);
            	  if((*LabelMode) == 1){
                  	rectangle_t LabelBorder = {(MenuPage->x) + OffSetX, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows + OffSetY,  MenuPage->MenuItems->ItemInfo.x,  MenuPage->MenuItems->ItemInfo.y, 2};
                  	graphic_draw_retangle(&LabelBorder, -1, -1, color);
            	  }
            	  else{
            		  rectangle_t LabelBorder = {(MenuPage->x) + OffSetX, (MenuPage->y) + (RowsIndex - 1) * MenuPage->VsizeRows + OffSetY,  MenuPage->MenuItems->ItemInfo.x,  MenuPage->MenuItems->ItemInfo.y, 2};
            		  graphic_draw_retangle(&LabelBorder, -1, -1, 255);
            	  }
            }
        }
    }
}




void SwitchLabelMenu(MenuPage_t *MenuPage,int RowsIndex, uint8_t color){
	    uint8_t Value =  MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.value;
	    uint8_t CurrentValue =  MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.CurrentValues;
	    uint8_t OffsetX = MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.offset_x;
	    // Xoa label hien tai
        graphic_draw_bitmap(MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.bitmaps[CurrentValue] , (MenuPage->x) +  OffsetX , (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, 0);
        //  Update label tiep theo
        if(CurrentValue == Value){
        CurrentValue = 0;
        graphic_draw_bitmap(MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.bitmaps[CurrentValue] , (MenuPage->x) +  OffsetX , (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
        }
        else if(CurrentValue < 0) {
        CurrentValue = Value -1;
        graphic_draw_bitmap(MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.bitmaps[CurrentValue] , (MenuPage->x) +  OffsetX , (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
        }
        else{
        graphic_draw_bitmap(MenuPage->MenuChildPage[RowsIndex]->MenuItems->ItemSwitch.bitmaps[CurrentValue] , (MenuPage->x) +  OffsetX , (MenuPage->y) + RowsIndex * MenuPage->VsizeRows, color);
        }
}
#endif

/**
 * Code for thinning a binary image using Zhang-Suen algorithm.
 */


#define MAX_DIGITS                              6
#define BITMAP_NUMBER_WIDTH                     16
#define BITMAP_NUMBER_HEIGHT                    21
#define BITMAP_NUMBYTE_OF_1NUMBER               42
//===============================================================



//===============================================================================================
void PrintBitmapToTerminal(uint8_t* bitmap_data, int width, int height) {
    // In từng giá trị byte của mảng bitmap_data
    for (int y = 0; y < height; y++) {
        for (int x = 0; x < width; x++) {
            printf("%d ", bitmap_data[y * width + x]);  // In byte tại vị trí (y, x)
        }
        printf("\n");
    }
}


//===============================================================================================


//===============================================================================================
MenuPage_t* createMenuPage(int x, int y, int Hsize, int VsizeRows, int PageIndex, int PageRows,
                           int ParentPageIndex, int ParentRowsIndex) {
    MenuPage_t* newMenuPage = (MenuPage_t*)malloc(sizeof(MenuPage_t));
    if (newMenuPage == NULL) {
        printf("Memory allocation failed.\n");
        return NULL;
    }

    newMenuPage->x = x;
    newMenuPage->y = y;
    newMenuPage->Hsize = Hsize;
    newMenuPage->VsizeRows = VsizeRows;
    newMenuPage->PageIndex = PageIndex;
    newMenuPage->PageRows = PageRows;
    newMenuPage->ParentPageIndex = ParentPageIndex;
    newMenuPage->ParentRowsIndex = ParentRowsIndex;
    newMenuPage->MenuItems =NULL;
    newMenuPage->MenuChildPage = NULL;
    newMenuPage->MenuParentPage = NULL;
    newMenuPage->bitmaps = NULL; // Đây có thể được khởi tạo sau

    return newMenuPage;
}

//===============================================================================================


// Hàm hiển thị menu
void DisplayMenu(MenuPage_t *MenuPage, uint8_t color) {
    int WindowWidth = MenuPage->Hsize;
    int WindowHeight = MenuPage->PageRows * MenuPage->VsizeRows; // Dùng một số cụ thể cho chiều cao của mỗi hàng
    // Vẽ đường viền của menu
    rectangle_t MenuBorder = {MenuPage->x, MenuPage->y, WindowWidth + 4, WindowHeight + 4, 2};
    graphic_draw_retangle(&MenuBorder, -1, -1, color);
    // Vẽ các bitmap trong menu
    for (int i = 0; i < MenuPage->PageRows; i++) {
        if (MenuPage->bitmaps[i] != NULL) {
        	printf("MenuPage.x = %u\n", MenuPage->x);
            // Tính toán vị trí x, y của mỗi bitmap dựa trên chỉ số i
            int bitmap_x = MenuPage->x ;
            int bitmap_y = MenuPage->y + i* (MenuPage->VsizeRows); // Cập nhật theo hàng dọc
            // Tạo một đối tượng bitmap_t với các thông số tính toán
            bitmap_t bitmap_to_draw = {bitmap_x, bitmap_y, MenuPage->bitmaps[i]->cols, MenuPage->bitmaps[i]->rows, 0, MenuPage->bitmaps[i]->map};

            // Vẽ bitmap lên ảnh
            graphic_draw_bitmap(&bitmap_to_draw, -1, -1, color);
        }
     }
     // Màu sắc vẽ bitmap (ví dụ: màu đỏ RGB)
    // Ve cac label trong menu
    uint8_t OffSetX =0 ;
    uint8_t OffSetY =0 ;
    OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
    OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;

    for (int i = 0; i < MenuPage-> PageRows; i++) {
            if (MenuPage->MenuItems->ItemInfo.bitmaps[i].map != NULL) {
            int bitmap_x = MenuPage->x + OffSetX;
            int bitmap_y = MenuPage->y + i* (MenuPage->VsizeRows) +OffSetY; // Cập nhật theo hàng dọc
            // Vẽ bitmap lên ảnh
            DrawDigits(MenuPage->MenuItems->ItemInfo.bitmaps[i].map, MenuPage->MenuItems->ItemInfo.bitmaps[i].num , bitmap_x,  bitmap_y, MenuPage->MenuItems->ItemInfo.InfoType[i], MenuPage->MenuItems->ItemInfo.bitmaps[i].cols, MenuPage->MenuItems->ItemInfo.bitmaps[i].rows, color);
        }
    }
    if(color == 0){
      rectangle_t MenuFirstRows = {MenuPage->x, MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows), MenuPage->Hsize +2, MenuPage->VsizeRows +2, 2};
      GraphicFullFillRetangle(&MenuFirstRows, -1, -1, color);
    }

}
//===============================================================================================
void UpdateChoosePageRows(MenuPage_t *MenuPage, int Step, uint8_t color) {
    // Bỏ chọn hàng đang trước

	uint8_t OffSetX =0 ;
    uint8_t OffSetY =0 ;

    rectangle_t MenuFirstRows = {MenuPage->x +1, MenuPage->y + (MenuPage->ParentRowsIndex )* (MenuPage->VsizeRows) +1, MenuPage->Hsize +2, MenuPage->VsizeRows +2, 2};
    GraphicFullFillRetangle(&MenuFirstRows, -1, -1, 0);
    if (MenuPage->bitmaps[MenuPage->ParentRowsIndex] != NULL) {
          int bitmap_x = MenuPage->x ;
          int bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows );
          bitmap_t bitmap_to_draw = {bitmap_x, bitmap_y, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->cols, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->rows, 0, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->map};
          // Vẽ bitmap lên ảnh
          graphic_draw_bitmap(&bitmap_to_draw, -1, -1, color);


            if(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map != NULL){
                OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
                OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
                bitmap_x = MenuPage->x + OffSetX;
                bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows ) +OffSetY; // Cập nhật theo hàng dọc
                // Vẽ bitmap lên ảnh
                DrawDigits(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].num , bitmap_x,  bitmap_y,MenuPage->MenuItems->ItemInfo.InfoType[MenuPage->ParentRowsIndex], MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows, color);
            }
     }


    if(Step == 1){
       if((MenuPage->ParentRowsIndex)< (MenuPage->PageRows -1) )
          MenuPage->ParentRowsIndex +=1;
       else
          MenuPage->ParentRowsIndex =0;
    }
    else if(Step == -1){
        if((MenuPage->ParentRowsIndex) > 0 )
          MenuPage->ParentRowsIndex -=1;
       else
          MenuPage->ParentRowsIndex = (MenuPage->PageRows -1) ;
    }
    else{
         MenuPage->ParentRowsIndex = 0;
    }

      // Chọn hàng hiện tại
      if (MenuPage->bitmaps[MenuPage->ParentRowsIndex] != NULL) {
    	rectangle_t MenuFirstRows = {MenuPage->x, MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows )+1, MenuPage->Hsize+2, MenuPage->VsizeRows+1, 2};
    	GraphicFullFillRetangle(&MenuFirstRows, -1, -1, color);
          int bitmap_x = MenuPage->x ;
          int bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows );
          bitmap_t bitmap_to_draw = {bitmap_x, bitmap_y, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->cols, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->rows, 0, MenuPage->bitmaps[MenuPage->ParentRowsIndex]->map};
          // Vẽ bitmap lên ảnh
          graphic_draw_bitmap(&bitmap_to_draw, -1, -1, 0);
            if(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map != NULL){
                OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
                OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
                bitmap_x = MenuPage->x + OffSetX;
                bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows )+OffSetY; // Cập nhật theo hàng dọc
                // Vẽ bitmap lên ảnh
                 DrawDigits(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].num , bitmap_x,  bitmap_y, MenuPage->MenuItems->ItemInfo.InfoType[MenuPage->ParentRowsIndex], MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows, 0);
            }
      }

}

//=============================================================================================================================================
void UpdateMenuLabel(MenuPage_t *MenuPage, int MenuLevelIndex,int *LabelMode,uint8_t color){
	int OffSetX =0 ;
	int OffSetY =0 ;
	OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
	OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
//	printf("%d \r\n", MenuPage->ParentRowsIndex);
    if (MenuPage->MenuChildPage != NULL  &&  MenuPage->ParentRowsIndex >= 0 ) {
      if(MenuPage->MenuChildPage[MenuPage->ParentRowsIndex] != NULL ) {
        // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL và ItemType khác ITEM_SUBMENU
        if ((MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_VALUE) || (MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_SWITCH)  ){
            *LabelMode += 1;
            *LabelMode = ((*LabelMode) % 2);
                if((*LabelMode) == 1){
                rectangle_t LabelBorder = {(MenuPage->x) + OffSetX -5, (MenuPage->y) + (MenuPage->ParentRowsIndex) * MenuPage->VsizeRows + OffSetY -5,  MenuPage->MenuItems->ItemInfo.x,  MenuPage->MenuItems->ItemInfo.y, 2};
                graphic_draw_retangle(&LabelBorder, -1, -1, 0);
            	}
            	else{
            	rectangle_t LabelBorder = {(MenuPage->x) + OffSetX -5, (MenuPage->y) + (MenuPage->ParentRowsIndex) * MenuPage->VsizeRows + OffSetY -5,  MenuPage->MenuItems->ItemInfo.x,  MenuPage->MenuItems->ItemInfo.y, 2};
                graphic_draw_retangle(&LabelBorder, -1, -1, color);
            	}
            }
      }
    }
}
//=========================================================================================================================================================
void UpdateMenuPageV2(MenuPage_t *MenuPage, MenuPage_t **MenuReplacePage, int *MenuLevelIndex) {
    // Kiểm tra nếu MenuPageRows có cấp độ thấp hơn MenuSiblingIndex, thay đổi sang trang con
    if (MenuPage->PageRows > (MenuPage->ParentRowsIndex+1)) {
        if (MenuPage->MenuChildPage != NULL && MenuPage->ParentRowsIndex >= 0) {
            // Kiểm tra nếu MenuChildPage[RowsIndex] không phải NULL và ItemType khác ITEM_SUBMENU
            if (MenuPage->MenuChildPage[MenuPage->ParentRowsIndex] != NULL &&
                MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_SUBMENU) {
                //xoa hang dang duoc chon truoc do
    	        rectangle_t MenuFirstRows = {MenuPage->x, MenuPage->y + (MenuPage->ParentRowsIndex)* (MenuPage->VsizeRows), MenuPage->Hsize +2, MenuPage->VsizeRows +2, 2};
    	        GraphicFullFillRetangle(&MenuFirstRows, -1, -1, 0);
                DisplayMenu(MenuPage, 0);
                *MenuReplacePage = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex];  // Cập nhật trang thay thế là trang con
                DisplayMenu(MenuPage->MenuChildPage[MenuPage->ParentRowsIndex], 255);
                UpdateChoosePageRows(MenuPage->MenuChildPage[MenuPage->ParentRowsIndex], 0, 255);
                *MenuLevelIndex +=1;
            }
        }
    } else {
        // Nếu MenuPage tro den EXIT, thay đổi sang trang cha
        if (MenuPage->MenuParentPage != NULL && MenuPage->ParentRowsIndex >= 0) {
            *MenuReplacePage = MenuPage->MenuParentPage;  // Cập nhật trang thay thế là trang cha
            DisplayMenu(MenuPage, 0);
            DisplayMenu(MenuPage->MenuParentPage, 255);
            UpdateChoosePageRows(MenuPage->MenuParentPage, 0, 255);
            *MenuLevelIndex -=1;
        }
        else{
        	*MenuReplacePage = MenuPage;
            DisplayMenu(MenuPage, 0);
            *MenuLevelIndex = -1;
        }
    }


}
//=========================================================================================================================================================

void SwitchLabelMenu(MenuPage_t *MenuPage,int Step, uint8_t color){

    if (MenuPage->MenuChildPage[MenuPage->ParentRowsIndex] != NULL &&
         MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_SWITCH) {
	uint8_t Value =  MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemSwitch.value;
	uint8_t CurrentValue =  MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemSwitch.CurrentValues;
    uint8_t OffSetX ;
    uint8_t OffSetY ;
    // Xoa label hien tai
    OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
    OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
    int bitmap_x = MenuPage->x + OffSetX;
    int bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex )* (MenuPage->VsizeRows) +OffSetY; // Cập nhật theo hàng dọc
    // Tạo một đối tượng bitmap_t với các thông số tính toán
    bitmap_t bitmap_to_draw = {bitmap_x, bitmap_y, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows, 0, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex ].map};

    // // Vẽ bitmap lên ảnh
    graphic_draw_bitmap(&bitmap_to_draw, -1, -1, 255);

    if(Step == 1){
        if((CurrentValue+1)<Value){
            CurrentValue += 1;
        }
        else{
            CurrentValue = 0;
        }
    }
    else if(Step == -1){
        if((CurrentValue-1) < 0){
            CurrentValue = Value -1;
        }
        else{
            CurrentValue -= 1 ;
        }
    }
    // Cập nhật lại giá trị mới của CurrentValue trong cấu trúc MenuPage
    MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemSwitch.CurrentValues = CurrentValue;

    MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex] = *MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemSwitch.bitmaps[CurrentValue];
    // Cập nhật bitmap_to_draw bằng cách gán giá trị cho từng trường
    bitmap_to_draw.x = bitmap_x;
    bitmap_to_draw.y = bitmap_y;
    bitmap_to_draw.cols = MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols;
    bitmap_to_draw.rows = MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows;
    bitmap_to_draw.num = 0; // Cập nhật trường nào đó, nếu cần
    bitmap_to_draw.map = MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map;

    graphic_draw_bitmap(&bitmap_to_draw, -1, -1, 0);
    }
}


//=========================================================================================================================================================
void ControlValueLabelMenu(MenuPage_t *MenuPage, int Step, uint8_t color) {
    // Kiểm tra nếu ItemType là ITEM_VALUE
    if(MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_VALUE) {
        int Value = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value;
        int ValueStep = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value_step;
        int ValueMax = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value_max;
        int ValueMin = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value_min;
        int Float_point = MenuPage->MenuItems->ItemInfo.InfoType[MenuPage->ParentRowsIndex];

        uint8_t OffSetX ;
        uint8_t OffSetY ;
        // Xoa label hien tai
        OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
        OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
        int bitmap_x = MenuPage->x + OffSetX;
        int bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex )* (MenuPage->VsizeRows) +OffSetY;


        DrawDigits(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].num, bitmap_x, bitmap_y,MenuPage->MenuItems->ItemInfo.InfoType[MenuPage->ParentRowsIndex], MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows, color );
        // Cập nhật giá trị Value nếu Step = 1 hoặc Step = -1
        if (Step == 1) {
            if ((Value + ValueStep) < ValueMax) {
                Value += ValueStep;
            } else {
                Value = ValueMax;
            }
        } else if (Step == -1) {
            if ((Value - ValueStep) > ValueMin) {
                Value -= ValueStep;
            } else {
                Value = ValueMin;
            }
        }

        MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value = Value;
        if(Float_point >0){
        MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.value_float = (float)Value/Float_point;
        }

        // Vẽ lại bitmap đã cập nhật
    }
}
//=========================================================================================================================================================



void PrintNumber(MenuPage_t *MenuPage, int Number, uint8_t* CombinedMap, uint8_t color) {
    if (MenuPage->MenuChildPage[MenuPage->ParentRowsIndex] != NULL &&
    MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemsType == ITEM_VALUE) {
    uint8_t OffSetX ;
    uint8_t OffSetY ;
    // Xoa label hien tai
    OffSetX = MenuPage->MenuItems->ItemInfo.offset_x;
    OffSetY = MenuPage->MenuItems->ItemInfo.offset_y;
    int bitmap_x = MenuPage->x + OffSetX;
    int bitmap_y = MenuPage->y + (MenuPage->ParentRowsIndex )* (MenuPage->VsizeRows) +OffSetY; // Cập nhật theo hàng dọc
    int digits[MAX_DIGITS];  // Array to hold digits (supporting up to 6 digits)
    int i = 0;

    // Extract digits from the number
    do {
        digits[i] = Number % 10;
        Number /= 10;
        i++;
    } while (Number > 0);

    // Ensure the number of digits doesn't exceed the maximum supported digits
    if (i > MAX_DIGITS) {
        printf("Number has more than %d", MAX_DIGITS);
        return;
    }

    // Create a combined bitmap array that can store bitmaps for up to 6 digits
    uint8_t combined_map[BITMAP_NUMBYTE_OF_1NUMBER * MAX_DIGITS];  // Fixed size for combined bitmap
    int offset = 0;  // Offset to track the position in the combined array

    // Combine all digit bitmaps into the combined_map array
    for (int j = i - 1; j >= 0; j--) {
        // Copy the current digit's bitmap into the combined_map
        memcpy(combined_map + offset, &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[j]], BITMAP_NUMBYTE_OF_1NUMBER);
        offset += BITMAP_NUMBYTE_OF_1NUMBER;  // Update the offset for the next digit's bitmap
    }

    // Truyền combined_map ra ngoài
    memcpy(MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.combined_map_out, combined_map, BITMAP_NUMBYTE_OF_1NUMBER * i);
    memcpy(CombinedMap, combined_map, BITMAP_NUMBYTE_OF_1NUMBER * i);
    MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map = MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->MenuItems->ItemValue.combined_map_out;
    MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].num =(-i);
    DrawDigits(MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].map, (-i), bitmap_x, bitmap_y, MenuPage->MenuItems->ItemInfo.InfoType[MenuPage->ParentRowsIndex], MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].cols, MenuPage->MenuItems->ItemInfo.bitmaps[MenuPage->ParentRowsIndex].rows, 0);
    }

}
// Hàm tách combined_map thành các bitmap_t


void DrawDigits(uint8_t* combined_map, int num_digits,int bitmap_x, int bitmap_y, int InforType, uint16_t cols,uint16_t rows, uint8_t color) {
    // Print the combined map for debugging
    bitmap_t digit_bitmaps[MAX_DIGITS];
//     MenuPage->MenuChildPage[MenuPage->ParentRowsIndex]->ItemValue.bitmaps->map = combined_map;
    if((num_digits<0)&&(InforType == 0)){
    num_digits = -num_digits;
    uint8_t* CombinedMap = combined_map;  // The map of the first digit
    int total_size = BITMAP_NUMBYTE_OF_1NUMBER * num_digits;  // Calculate the total size of the combined bitmap
    for (int j = 0; j < num_digits; j++) {
        // Initialize each bitmap_t struct for the current digit
        digit_bitmaps[j].cols = BITMAP_NUMBER_WIDTH;
        digit_bitmaps[j].rows = BITMAP_NUMBER_HEIGHT;
        digit_bitmaps[j].x = bitmap_x;  // Set the x-coordinate based on the position
        digit_bitmaps[j].y = bitmap_y;  // Set the y-coordinate for all digits
        digit_bitmaps[j].num = digit_bitmaps[j].rows;
        // Extract the corresponding digit's bitmap from the combined_map
        // IMPORTANT: Make sure the pointer points to the correct location in combined_map
        digit_bitmaps[j].map = combined_map + (BITMAP_NUMBYTE_OF_1NUMBER * j);  // Get the bitmap for the current digit
        graphic_draw_bitmap(&digit_bitmaps[j], -1, -1, color);
        // Update x position for the next digit
        bitmap_x += BITMAP_NUMBER_WIDTH - 2;  // Adjust the gap between digits
    }
    // PrintCombinedMap(combined_map, total_size);  // Print the combined bitmap to the terminal
    }
    else if((num_digits<0)&&(InforType <0)){
    num_digits = -num_digits;
    uint8_t* CombinedMap = combined_map;  // The map of the first digit
    int total_size = BITMAP_NUMBYTE_OF_1NUMBER * num_digits;  // Calculate the total size of the combined bitmap
        for (int j = 0; j < num_digits; j++) {
            // Initialize each bitmap_t struct for the current digit
            digit_bitmaps[j].cols = BITMAP_NUMBER_WIDTH;
            digit_bitmaps[j].rows = BITMAP_NUMBER_HEIGHT;
            digit_bitmaps[j].x = bitmap_x;  // Set the x-coordinate based on the position
            digit_bitmaps[j].y = bitmap_y;  // Set the y-coordinate for all digits
            digit_bitmaps[j].num = digit_bitmaps[j].rows;
            // Extract the corresponding digit's bitmap from the combined_map
            // IMPORTANT: Make sure the pointer points to the correct location in combined_map
            digit_bitmaps[j].map = combined_map + (BITMAP_NUMBYTE_OF_1NUMBER * j);  // Get the bitmap for the current digit
            graphic_draw_bitmap(&digit_bitmaps[j], -1, -1, color);
            // Update x position for the next digit
            bitmap_x += BITMAP_NUMBER_WIDTH - 2;  // Adjust the gap between digits
        }
    bitmap_t bitmap_PERCENT;
        bitmap_PERCENT.x = bitmap_x;
        bitmap_PERCENT.y = bitmap_y -5;
        bitmap_PERCENT.cols = 19;
        bitmap_PERCENT.rows = 32;
        bitmap_PERCENT.num = sizeof(PERCENT_SYMBOL);
        bitmap_PERCENT.map = PERCENT_SYMBOL;
        graphic_draw_bitmap(&bitmap_PERCENT,-1,-1, color);

    // PrintCombinedMap(combined_map, total_size);  // Print the combined bitmap to the terminal
    }
    else if((num_digits<0)&&(InforType >0)){
        num_digits = -num_digits;
            if((num_digits - InforType)>0){
            int Pos_pointer = num_digits - InforType;
            uint8_t* CombinedMap = combined_map;  // The map of the first digit
            int total_size = BITMAP_NUMBYTE_OF_1NUMBER * num_digits;  // Calculate the total size of the combined bitmap
                for (int j = 0; j < num_digits; j++) {
                    if(j == Pos_pointer){
                        bitmap_t bitmap_DAUCHAM;
                            bitmap_DAUCHAM.x = bitmap_x;
                            bitmap_DAUCHAM.y = bitmap_y;
                            bitmap_DAUCHAM.cols = 12;
                            bitmap_DAUCHAM.rows = 21;
                            bitmap_DAUCHAM.num = sizeof(bitmap_daucham);
                            bitmap_DAUCHAM.map = bitmap_daucham;
                            graphic_draw_bitmap(&bitmap_DAUCHAM, -1, -1, color);
                           bitmap_x += 10;
                    }
                    // Initialize each bitmap_t struct for the current digit
                    digit_bitmaps[j].cols = BITMAP_NUMBER_WIDTH;
                    digit_bitmaps[j].rows = BITMAP_NUMBER_HEIGHT;
                    digit_bitmaps[j].x = bitmap_x;  // Set the x-coordinate based on the position
                    digit_bitmaps[j].y = bitmap_y;  // Set the y-coordinate for all digits
                    digit_bitmaps[j].num = digit_bitmaps[j].rows;
                    // Extract the corresponding digit's bitmap from the combined_map
                    // IMPORTANT: Make sure the pointer points to the correct location in combined_map
                    digit_bitmaps[j].map = combined_map + (BITMAP_NUMBYTE_OF_1NUMBER * j);  // Get the bitmap for the current digit
                    graphic_draw_bitmap(&digit_bitmaps[j], -1, -1, color);
                    // Update x position for the next digit
                    bitmap_x += BITMAP_NUMBER_WIDTH - 2;  // Adjust the gap between digits
                }
            }
            else{
                bitmap_t number_zero;
                    number_zero.x = bitmap_x;
                    number_zero.y = bitmap_y;
                    number_zero.cols = BITMAP_NUMBER_WIDTH;
                    number_zero.rows = BITMAP_NUMBER_HEIGHT;
                    number_zero.num = 0;
                    number_zero.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER *0];
                    graphic_draw_bitmap(&number_zero, -1, -1, color);
                    bitmap_x += BITMAP_NUMBER_WIDTH - 2;

                    number_zero.x = bitmap_x;
                    number_zero.y = bitmap_y;
                    number_zero.cols = 12;
                    number_zero.rows = 21;
                    number_zero.num = 0;
                    number_zero.map = bitmap_daucham;
                    graphic_draw_bitmap(&number_zero, -1, -1, color);
                    bitmap_x += 10;
                int Pos_pointer = num_digits - InforType;
                for (int j = 0; j < InforType; j++) {
                    if(Pos_pointer<0){
                    number_zero.x = bitmap_x;
                    number_zero.y = bitmap_y;
                    number_zero.cols = BITMAP_NUMBER_WIDTH;
                    number_zero.rows = BITMAP_NUMBER_HEIGHT;
                    number_zero.num = 0;
                    number_zero.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER *0];
                    graphic_draw_bitmap(&number_zero, -1, -1, color);
                    bitmap_x += BITMAP_NUMBER_WIDTH - 2;
                    Pos_pointer +=1;
                    }
                    else{
                    // Initialize each bitmap_t struct for the current digit
                    digit_bitmaps[j - Pos_pointer].cols = BITMAP_NUMBER_WIDTH;
                    digit_bitmaps[j - Pos_pointer].rows = BITMAP_NUMBER_HEIGHT;
                    digit_bitmaps[j - Pos_pointer].x = bitmap_x;  // Set the x-coordinate based on the position
                    digit_bitmaps[j - Pos_pointer].y = bitmap_y;  // Set the y-coordinate for all digits
                    digit_bitmaps[j - Pos_pointer].num = digit_bitmaps[j].rows;
                    // Extract the corresponding digit's bitmap from the combined_map
                    // IMPORTANT: Make sure the pointer points to the correct location in combined_map
                    digit_bitmaps[j - Pos_pointer].map = combined_map + (BITMAP_NUMBYTE_OF_1NUMBER * (j - Pos_pointer));  // Get the bitmap for the current digit
                    graphic_draw_bitmap(&digit_bitmaps[j - Pos_pointer], -1, -1, color);
                    // Update x position for the next digit
                    bitmap_x += BITMAP_NUMBER_WIDTH - 2;  // Adjust the gap between digits
                    }

                }
            }
        }


    else{
        bitmap_t bitmap_to_draw = {bitmap_x, bitmap_y, cols, rows, 0, combined_map};
        graphic_draw_bitmap(&bitmap_to_draw, -1, -1, color);
    }
}

