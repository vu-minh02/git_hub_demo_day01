#include "menu_lib.h"

#if 0
typedef enum {  MENU_LV0 = 0,
                MENU_LV1,
                MENU_LV2,
                MENU_LV3,
				MENU_LV4,
            } menu_state_t;

typedef enum {  ITEM_EXIT,
                ITEM_INFO,
                ITEM_VALUE,
				ITEM_SWITCH,
                ITEM_SUBMENU,
            } items_type_t;

typedef enum {  BTN_LEFT = 0,
				BTN_RIGHT,
				MENU_OK,
			} menu_btn_t;


//==========================================

typedef struct
{
	menu_state_t state;
	uint8_t ptr[5]; //max 5 level menu
} menu_ptr;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;

    char info_txt[32];
} item_info_t;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;

    uint8_t value;
    uint8_t value_min;
    uint8_t value_max;
    uint8_t value_step;
    char value_txt[32];
} item_value_t;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;

    uint8_t value;
    uint8_t num_value;
    char value_txt[6][32]; //max 6 gia tri thay doi
} item_switch_t;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;

    items_type_t items_type;
    char items_name[32];

    int submenu_num;
    struct menu_page_t *submenu;

    item_value_t item_value;
    item_info_t item_info;
    item_switch_t item_switch;

} menu_item_t;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;
    int item_num;
    menu_item_t *items;

} menu_page_t;

//==========================================
menu_page_t *menu_create(int size){
    menu_page_t *menu = (menu_page_t *)malloc(sizeof(menu_page_t));
    menu->item_num = size;
    menu->items = (menu_item_t *)malloc(size * sizeof(menu_item_t));
    return menu;
}
#endif 0

//==========================================
//int test_menu()
//{
//    printf("Hello, test menu\n\r");
//
//    //====================================================
//    // khoi tao menu
//    menu_page_t *menu_1 = menu_create(4);
//
//    //====================================================
//    // khoi tao menu lv1
//    // lv1-1
//    menu_1->items[0].items_type = ITEM_SUBMENU;
//
//    sprintf(menu_1->items[0].items_name, "1 Submenu");
//    menu_1->items[0].submenu = menu_create(2);
//
//    // lv1-2
//    menu_1->items[1].items_type = ITEM_SWITCH;
//    sprintf(menu_1->items[1].items_name, "2 Switch");
//    menu_1->items[1].item_switch.value = 2;
//    menu_1->items[1].item_switch.num_value = 4;
//    sprintf(menu_1->items[1].item_switch.value_txt[0], "A0");
//    sprintf(menu_1->items[1].item_switch.value_txt[1], "A1");
//    sprintf(menu_1->items[1].item_switch.value_txt[2], "A2");
//    sprintf(menu_1->items[1].item_switch.value_txt[3], "A3");
//
//    // lv1-3
//    menu_1->items[2].items_type = ITEM_INFO;
//    sprintf(menu_1->items[2].items_name, "3 Info");
//    sprintf(menu_1->items[2].item_info.info_txt, "3 Info");
//
//    // lv1-4
//    menu_1->items[3].items_type = ITEM_EXIT;
//    sprintf(menu_1->items[3].items_name, "exit");
//
//    //====================================================
//    // khoi tao menu lv2
//    menu_page_t *menu_2;
//    menu_2 = menu_1->items[0].submenu;
//    // lv1-1-lv2-1
//    menu_2->items[0].items_type = ITEM_VALUE;
//    sprintf(menu_2->items[0].items_name, "1-1 Value");
//    menu_2->items[0].item_value.value = 2;
//    menu_2->items[0].item_value.value_min = 0;
//    menu_2->items[0].item_value.value_max = 4;
//    menu_2->items[0].item_value.value_step = 1;
//
//    // lv1-1-lv2-2
//    menu_2->items[1].items_type = ITEM_EXIT;
//    sprintf(menu_2->items[1].items_name, "Exit");
//
//    return 0;
//}
