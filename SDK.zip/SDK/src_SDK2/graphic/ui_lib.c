#include "ui_lib.h"
#include <wchar.h>
#include <locale.h>
uint32_t tenplate_buffer_addr = 0;
int tenplate_width = 0;
int tenplate_height = 0;

void graphic_init(uint32_t buffer_addr, int width, int height)
{
	tenplate_buffer_addr = buffer_addr;
	tenplate_width = width;
	tenplate_height = height;
}


void GraphicDrawChooseBitmap(bitmap_t *bitmap, int x, int y, uint8_t color)
{
	if(x >= 0) bitmap->x = x;
	if(y >= 0) bitmap->y = y;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);

	for(int i = 0; i < bitmap->rows; i++){
		for(int j = 0; j < bitmap->cols; j++){
			uint8_t a = (bitmap->map[(i*bitmap->cols + j)/8] >> ((i*bitmap->cols + j)%8)) & 0b1;
			if(a == 0)
				temp_ptr[3*((bitmap->y+i)*tenplate_width + (bitmap->x+j)) + 1] = color;
		}
	}
}

void GraphicFullFillRetangle(rectangle_t *rectangle, int x, int y, uint8_t color){
	if(x >= 0) rectangle->x = x;
	if(y >= 0) rectangle->y = y;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);

	//draw top line
	for(int i = 0; i < rectangle->rows ; i++){
		for(int j = 0; j < rectangle->cols; j++){
			temp_ptr[3*((rectangle->y+i)*tenplate_width + (rectangle->x+j)) + 1] = color;
		}
	}
}



void graphic_draw_bitmap(bitmap_t *bitmap, int x, int y, uint8_t color)
{
	if(x >= 0) bitmap->x = x;
	if(y >= 0) bitmap->y = y;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);

	for(int i = 0; i < bitmap->rows; i++){
		for(int j = 0; j < bitmap->cols; j++){
			uint8_t a = (bitmap->map[(i*bitmap->cols + j)/8] >> ((i*bitmap->cols + j)%8)) & 0b1;
			if(a != 0)
				temp_ptr[3*((bitmap->y+i)*tenplate_width + (bitmap->x+j)) + 1] = color;
		}
	}
}

void graphic_draw_retangle(rectangle_t *rectangle, int x, int y, uint8_t color)
{
	if(x >= 0) rectangle->x = x;
	if(y >= 0) rectangle->y = y;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);

	//draw top line
	for(int i = 0; i < rectangle->border; i++){
		for(int j = 0; j < rectangle->cols; j++){
			temp_ptr[3*((rectangle->y+i)*tenplate_width + (rectangle->x+j)) + 1] = color;
		}
	}

	//draw bottom line
	for(int i = 0; i < rectangle->border; i++){
		for(int j = 0; j < rectangle->cols; j++){
			temp_ptr[3*((rectangle->rows +rectangle->y+i)*tenplate_width + (rectangle->x+j)) + 1] = color;
		}
	}

	//draw left line
	for(int i = 0; i < rectangle->rows; i++){
		for(int j = 0; j < rectangle->border; j++){
			temp_ptr[3*((rectangle->y+i)*tenplate_width + (rectangle->x+j)) + 1] = color;
		}
	}

	//draw right line
	for(int i = 0; i < rectangle->rows; i++){
		for(int j = 0; j < rectangle->border; j++){
			temp_ptr[3*((rectangle->y+i)*tenplate_width + (rectangle->cols+rectangle->x+j)) + 1] = color;
		}
	}
}

void graphic_draw_level_bar(level_bar_t *level_bar, int level)
{
	int bar_width = level_bar->cols;
	int bar_height = level_bar->rows;

	if(level > 5)
		return;

	if(level_bar->level_cur == level)
		return;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);

	if(level_bar->level_cur < level){
		int a = (level_bar->y - bar_height*level);
		int b = (level_bar->y - bar_height*level_bar->level_cur);
		int c = (level_bar->x + bar_width);

		for(int i = a; i < b; i++){
			for(int j = level_bar->x; j < c; j++){
				temp_ptr[3*(i*tenplate_width + j) + 1] = 210; //G
			}
		}
	}

	if(level_bar->level_cur > level){
		int a = (level_bar->y - bar_height*level_bar->level_cur);
		int b = (level_bar->y - bar_height*level);
		int c = (level_bar->x + bar_width);

		for(int i = a; i < b; i++){
			for(int j = level_bar->x; j < c; j++){
				temp_ptr[3*(i*tenplate_width + j) + 1] = 100;
			}
		}
	}

	level_bar->level_cur = level;
}


void graphic_init_compass(compass_ruler_t *compass_ruler)
{
	int bitmap_width = COMPASS_RULER_WIDTH;
	int bitmap_height = COMPASS_RULER_HEIGHT;
	int window_width = compass_ruler->window_cols;
	int window_height = COMPASS_RULER_HEIGHT;
	int x = compass_ruler->x;
	int y = compass_ruler->y;

	memset((uint8_t *)(compass_ruler->buffer_addr), 0, bitmap_width*bitmap_height);
	uint8_t *compass_map_ptr = (uint8_t*)(compass_ruler->buffer_addr);

	for(int i = 0; i < bitmap_height; i++){
		for(int j = 0; j < bitmap_width; j++){
			int id = i*bitmap_width + j;
			uint8_t a = (bitmap_compass[id/8] >> (id%8)) & 0b1;
			if(a != 0)
				compass_map_ptr[id] = 255;
		}
	}

	//border for compass ruler
	rectangle_t compass_border = {x-2, y-2, window_width+4, window_height+4, 1};
	graphic_draw_retangle(&compass_border, -1, -1, 255);

	//compass cursor center
	bitmap_t compass_cursor;
	compass_cursor.cols = COMPASS_CURSOR_WIDTH;
	compass_cursor.rows = COMPASS_CURSOR_HEIGHT;
	compass_cursor.x = x + window_width/2 - COMPASS_CURSOR_WIDTH/2;
	compass_cursor.y = y + window_height + 3;
	compass_cursor.num = sizeof(bitmap_compass_cursor);
	compass_cursor.map = bitmap_compass_cursor;
	graphic_draw_bitmap(&compass_cursor, -1, -1, 255);

	//border for compass ruler value
	rectangle_t compass_cursor_val = {x + window_width/2 - 50/2, compass_cursor.y + compass_cursor.rows + 1, 50, 25, 1};
	graphic_draw_retangle(&compass_cursor_val, -1, -1, 255);

	graphic_draw_compass_ruler(compass_ruler, 0);
	graphic_draw_compass_val(compass_ruler, 0, 255);
}

void graphic_draw_compass_ruler(compass_ruler_t *compass_ruler, int value)
{
	int bitmap_width = COMPASS_RULER_WIDTH;
	int window_width = compass_ruler->window_cols;
	int window_height = COMPASS_RULER_HEIGHT;
	int x = compass_ruler->x;
	int y = compass_ruler->y;

	float offset = value - (float)(window_width)/2/COMPASS_RULER_WIDTH_TICK*COMPASS_RULER_DEGREE_PER_TICK + COMPASS_RULER_OFFSET;

	if(offset < 0) offset = offset + 360;

	offset = offset * COMPASS_RULER_WIDTH_TICK / COMPASS_RULER_DEGREE_PER_TICK;

	uint8_t *temp_ptr = (uint8_t*)(tenplate_buffer_addr);
	uint8_t *compass_map_ptr = (uint8_t*)(compass_ruler->buffer_addr);

	for(int i = 0; i < window_height; i++){
		int a = 3*(y+i)*tenplate_width;
		int b = i*bitmap_width;
		for(int j = 0; j < window_width; j++){
			int c = j + (int)offset;
			if(c > bitmap_width) c = c - bitmap_width;
			temp_ptr[a + 3*(x+j) + 1] = compass_map_ptr[b + c];
		}
	}
}

void graphic_draw_compass_val(compass_ruler_t *compass_ruler, int value, uint8_t color)
{

	int x = compass_ruler->x + compass_ruler->window_cols/2 - BITMAP_NUMBER_WIDTH - BITMAP_NUMBER_WIDTH/2 + 3;
	int y = compass_ruler->y + COMPASS_RULER_HEIGHT + COMPASS_CURSOR_WIDTH;

	if(value < 100) x = x-BITMAP_NUMBER_WIDTH/2;

	if(value < 10) x = x-BITMAP_NUMBER_WIDTH/2 + 2;

	int value_1 = value/100;
	int value_2 = value/10 - value_1*10;
	int value_3 = value - (value/10)*10;

	bitmap_t num_value_1;
	num_value_1.cols = BITMAP_NUMBER_WIDTH;
	num_value_1.rows = BITMAP_NUMBER_HEIGHT;
	num_value_1.x = x;
	num_value_1.y = y;
	num_value_1.num = num_value_1.rows;
	if(value >= 100)
		num_value_1.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * value_1];
	else
		num_value_1.map = bitmap_space;
	graphic_draw_bitmap(&num_value_1, -1, -1, color);

	bitmap_t num_value_2;
	num_value_2.cols = BITMAP_NUMBER_WIDTH;
	num_value_2.rows = BITMAP_NUMBER_HEIGHT;
	num_value_2.x = num_value_1.x + num_value_1.cols-2;
	num_value_2.y = y;
	num_value_2.num = num_value_2.rows;
	if(value >= 10)
		num_value_2.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * value_2];
	else
		num_value_2.map = bitmap_space;
	graphic_draw_bitmap(&num_value_2, -1, -1, color);

	bitmap_t num_value_3;
	num_value_3.cols = BITMAP_NUMBER_WIDTH;
	num_value_3.rows = BITMAP_NUMBER_HEIGHT;
	num_value_3.x = num_value_2.x + num_value_2.cols-2;
	num_value_3.y = y;
	num_value_3.num = num_value_3.rows;
	num_value_3.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * value_3];
	graphic_draw_bitmap(&num_value_3, -1, -1, color);
}

void graphic_update_compass_val(compass_ruler_t *compass_ruler, int value, uint8_t color)
{
	if(compass_ruler->value_cur == value)
		return;

	graphic_draw_compass_val(compass_ruler, compass_ruler->value_cur, 0); //delete old value
	graphic_draw_compass_val(compass_ruler, value, color);
	graphic_draw_compass_ruler(compass_ruler, value);
	compass_ruler->value_cur = value; //update new value
}


void graphic_init_GPS(int longitude, int latitude,  uint8_t color)
{
	bitmap_t bitmap_kd;
	bitmap_t bitmap_vd;

    uint16_t toa_do_x = 300;
    uint16_t toa_do_y = 500;



	bitmap_kd.x = toa_do_x;
	bitmap_kd.y = toa_do_y;
	bitmap_kd.cols = 53;
	bitmap_kd.rows = 38;
	bitmap_kd.num = sizeof(bitmap_kinhdo);
	bitmap_kd.map = bitmap_kinhdo;

	bitmap_vd.x = toa_do_x;
	bitmap_vd.y = toa_do_y+38;
	bitmap_vd.cols = 53;
	bitmap_vd.rows = 38;
	bitmap_vd.num = sizeof(bitmap_vido);
	bitmap_vd.map = bitmap_vido;

	graphic_draw_bitmap(&bitmap_kd, -1, -1, 255);
	graphic_draw_bitmap(&bitmap_vd, -1, -1, 255);
	rectangle_t longitude_val = {toa_do_x+53 , toa_do_y , 188, 38, 1};
    graphic_draw_retangle(&longitude_val, -1, -1, 255);

    rectangle_t latitude_val = {toa_do_x+53 , toa_do_y + 38 , 188, 38,1};
    graphic_draw_retangle(&latitude_val, -1, -1, 255);
    graphic_draw_longitude_val(longitude, color);
    graphic_draw_latitude_val(latitude, color) ;


	bitmap_t dau_cham;
	dau_cham.x = 369 + 14*3;
	dau_cham.y = 510;
	dau_cham.cols = 12;
	dau_cham.rows = BITMAP_NUMBER_HEIGHT;
	dau_cham.num = sizeof(bitmap_daucham);
	dau_cham.map = bitmap_daucham;
	graphic_draw_bitmap(&dau_cham, -1, -1, color);



	dau_cham.x = 369 + 14*3;
	dau_cham.y = 548;
	dau_cham.cols = 12;
	dau_cham.rows = BITMAP_NUMBER_HEIGHT;
	dau_cham.num = sizeof(bitmap_daucham);
	dau_cham.map = bitmap_daucham;
	graphic_draw_bitmap(&dau_cham, -1, -1, color);


}

void graphic_draw_longitude_val(int value, uint8_t color)
{
	int x = 369 ;
	int y = 510 ;

	 int digits[10];
     int value1 =value;

	   for (int i = 9; i >= 0; i--) {
	        digits[i] = value1 % 10;
	        if(value1>=10)
	   	           value1 /= 10;
	   	        else
	   	        	value1 = 0;
	    }

	bitmap_t num_value_1;
	num_value_1.cols = BITMAP_NUMBER_WIDTH;
	num_value_1.rows = BITMAP_NUMBER_HEIGHT;
	num_value_1.x = x;
	num_value_1.y = y;
	num_value_1.num = num_value_1.rows;
	num_value_1.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[0]];
	graphic_draw_bitmap(&num_value_1, -1, -1, color);



	bitmap_t num_value_2;
	num_value_2.cols = BITMAP_NUMBER_WIDTH;
	num_value_2.rows = BITMAP_NUMBER_HEIGHT;
	num_value_2.x = num_value_1.x + num_value_1.cols-2;
	num_value_2.y = y;
	num_value_2.num = num_value_2.rows;
	num_value_2.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[1]];
	graphic_draw_bitmap(&num_value_2, -1, -1, color);

	bitmap_t num_value_3;
	num_value_3.cols = BITMAP_NUMBER_WIDTH;
	num_value_3.rows = BITMAP_NUMBER_HEIGHT;
	num_value_3.x = num_value_2.x + num_value_2.cols-2;
	num_value_3.y = y;
	num_value_3.num = num_value_3.rows;
	num_value_3.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[2]];
	graphic_draw_bitmap(&num_value_3, -1, -1, color);


//	bitmap_t dau_cham;
//	dau_cham.x = num_value_3.x + num_value_3.cols-2;
//	dau_cham.y = y;
//	dau_cham.cols = 12;
//	dau_cham.rows = BITMAP_NUMBER_HEIGHT;
//	dau_cham.num = sizeof(bitmap_daucham);
//	dau_cham.map = bitmap_daucham;
//	graphic_draw_bitmap(&dau_cham, -1, -1, color);

	bitmap_t num_value_4;
	num_value_4.cols = BITMAP_NUMBER_WIDTH;
	num_value_4.rows = BITMAP_NUMBER_HEIGHT;
	num_value_4.x = num_value_3.x + num_value_3.cols-2 + 12 ;
	num_value_4.y = y;
	num_value_4.num = num_value_4.rows;
	num_value_4.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[3]];
	graphic_draw_bitmap(&num_value_4, -1, -1, color);



	bitmap_t num_value_5;
	num_value_5.cols = BITMAP_NUMBER_WIDTH;
	num_value_5.rows = BITMAP_NUMBER_HEIGHT;
	num_value_5.x = num_value_4.x + num_value_4.cols-2 ;
	num_value_5.y = y;
	num_value_5.num = num_value_5.rows;
	num_value_5.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[4]];
	graphic_draw_bitmap(&num_value_5, -1, -1, color);

	bitmap_t num_value_6;
	num_value_6.cols = BITMAP_NUMBER_WIDTH;
	num_value_6.rows = BITMAP_NUMBER_HEIGHT;
	num_value_6.x = num_value_5.x + num_value_5.cols-2 ;
	num_value_6.y = y;
	num_value_6.num = num_value_6.rows;
	num_value_6.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[5]];
	graphic_draw_bitmap(&num_value_6, -1, -1, color);


	bitmap_t num_value_7;
	num_value_7.cols = BITMAP_NUMBER_WIDTH;
	num_value_7.rows = BITMAP_NUMBER_HEIGHT;
	num_value_7.x = num_value_6.x + num_value_6.cols-2 ;
	num_value_7.y = y;
	num_value_7.num = num_value_7.rows;
	num_value_7.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[6]];
	graphic_draw_bitmap(&num_value_7, -1, -1, color);

	bitmap_t num_value_8;
	num_value_8.cols = BITMAP_NUMBER_WIDTH;
	num_value_8.rows = BITMAP_NUMBER_HEIGHT;
	num_value_8.x = num_value_7.x + num_value_7.cols-2 ;
	num_value_8.y = y;
	num_value_8.num = num_value_8.rows;
	num_value_8.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[7]];
	graphic_draw_bitmap(&num_value_8, -1, -1, color);


	bitmap_t num_value_9;
	num_value_9.cols = BITMAP_NUMBER_WIDTH;
	num_value_9.rows = BITMAP_NUMBER_HEIGHT;
	num_value_9.x = num_value_8.x + num_value_8.cols-2 ;
	num_value_9.y = y;
	num_value_9.num = num_value_9.rows;
	num_value_9.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[8]];
	graphic_draw_bitmap(&num_value_9, -1, -1, color);

	bitmap_t num_value_10;
	num_value_10.cols = BITMAP_NUMBER_WIDTH;
	num_value_10.rows = BITMAP_NUMBER_HEIGHT;
	num_value_10.x = num_value_9.x + num_value_9.cols-2 ;
	num_value_10.y = y;
	num_value_10.num = num_value_10.rows;
	num_value_10.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[9]];
    graphic_draw_bitmap(&num_value_10, -1, -1, color);

}



void graphic_draw_latitude_val(int value, uint8_t color)
{
	int x = 369 ;
	int y = 548 ;


	int digits[10];
    int value1 =abs(value);

	   for (int i = 9; i >= 0; i--) {
	        digits[i] = value1 % 10;
	        if(value1>=10)
	   	           value1 /= 10;
	   	        else
	   	        	value1 = 0;
	    }
		bitmap_t dau_tru;
		dau_tru.x = x;
		dau_tru.y = y;
		dau_tru.cols = BITMAP_NUMBER_WIDTH;
		dau_tru.rows = BITMAP_NUMBER_HEIGHT;
		dau_tru.num = sizeof(bitmap_dautru);
		if(value<0)
			dau_tru.map = bitmap_dautru;
		else
    	    dau_tru.map = bitmap_space;
    	graphic_draw_bitmap(&dau_tru, -1, -1, color);

	bitmap_t num_value_2;
	num_value_2.cols = BITMAP_NUMBER_WIDTH;
	num_value_2.rows = BITMAP_NUMBER_HEIGHT;
	num_value_2.x = dau_tru.x + dau_tru.cols-2;
	num_value_2.y = y;
	num_value_2.num = num_value_2.rows;
	num_value_2.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[1]];
	graphic_draw_bitmap(&num_value_2, -1, -1, color);


	bitmap_t num_value_3;
	num_value_3.cols = BITMAP_NUMBER_WIDTH;
	num_value_3.rows = BITMAP_NUMBER_HEIGHT;
	num_value_3.x = num_value_2.x + num_value_2.cols-2;
	num_value_3.y = y;
	num_value_3.num = num_value_3.rows;
	num_value_3.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[2]];
	graphic_draw_bitmap(&num_value_3, -1, -1, color);


//	bitmap_t dau_cham;
//	dau_cham.x = num_value_3.x + num_value_3.cols-2;
//	dau_cham.y = y;
//	dau_cham.cols = 12;
//	dau_cham.rows = BITMAP_NUMBER_HEIGHT;
//	dau_cham.num = sizeof(bitmap_daucham);
//	dau_cham.map = bitmap_daucham;
//	graphic_draw_bitmap(&dau_cham, -1, -1, color);

	bitmap_t num_value_4;
	num_value_4.cols = BITMAP_NUMBER_WIDTH;
	num_value_4.rows = BITMAP_NUMBER_HEIGHT;
	num_value_4.x = num_value_3.x + num_value_3.cols-2 + 12 ;
	num_value_4.y = y;
	num_value_4.num = num_value_4.rows;
	num_value_4.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[3]];
	graphic_draw_bitmap(&num_value_4, -1, -1, color);



	bitmap_t num_value_5;
	num_value_5.cols = BITMAP_NUMBER_WIDTH;
	num_value_5.rows = BITMAP_NUMBER_HEIGHT;
	num_value_5.x = num_value_4.x + num_value_4.cols-2 ;
	num_value_5.y = y;
	num_value_5.num = num_value_5.rows;
	num_value_5.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[4]];
	graphic_draw_bitmap(&num_value_5, -1, -1, color);

	bitmap_t num_value_6;
	num_value_6.cols = BITMAP_NUMBER_WIDTH;
	num_value_6.rows = BITMAP_NUMBER_HEIGHT;
	num_value_6.x = num_value_5.x + num_value_5.cols-2 ;
	num_value_6.y = y;
	num_value_6.num = num_value_6.rows;
	num_value_6.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[5]];
	graphic_draw_bitmap(&num_value_6, -1, -1, color);


	bitmap_t num_value_7;
	num_value_7.cols = BITMAP_NUMBER_WIDTH;
	num_value_7.rows = BITMAP_NUMBER_HEIGHT;
	num_value_7.x = num_value_6.x + num_value_6.cols-2 ;
	num_value_7.y = y;
	num_value_7.num = num_value_7.rows;
	num_value_7.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[6]];
	graphic_draw_bitmap(&num_value_7, -1, -1, color);

	bitmap_t num_value_8;
	num_value_8.cols = BITMAP_NUMBER_WIDTH;
	num_value_8.rows = BITMAP_NUMBER_HEIGHT;
	num_value_8.x = num_value_7.x + num_value_7.cols-2 ;
	num_value_8.y = y;
	num_value_8.num = num_value_8.rows;
	num_value_8.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[7]];
	graphic_draw_bitmap(&num_value_8, -1, -1, color);


	bitmap_t num_value_9;
	num_value_9.cols = BITMAP_NUMBER_WIDTH;
	num_value_9.rows = BITMAP_NUMBER_HEIGHT;
	num_value_9.x = num_value_8.x + num_value_8.cols-2 ;
	num_value_9.y = y;
	num_value_9.num = num_value_9.rows;
	num_value_9.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[8]];
	graphic_draw_bitmap(&num_value_9, -1, -1, color);

	bitmap_t num_value_10;
	num_value_10.cols = BITMAP_NUMBER_WIDTH;
	num_value_10.rows = BITMAP_NUMBER_HEIGHT;
	num_value_10.x = num_value_9.x + num_value_9.cols-2 ;
	num_value_10.y = y;
	num_value_10.num = num_value_10.rows;
	num_value_10.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * digits[9]];
   graphic_draw_bitmap(&num_value_10, -1, -1, color);

}

void draw_check(int value, uint8_t color){
	if(value == 0){
	bitmap_t num_value_2;
	num_value_2.cols = BITMAP_NUMBER_WIDTH;
	num_value_2.rows = BITMAP_NUMBER_HEIGHT;
	num_value_2.x = 200;
	num_value_2.y = 400;
	num_value_2.num = num_value_2.rows;
	num_value_2.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * 0];
	graphic_draw_bitmap(&num_value_2, -1, -1, color);
	}
	else{
		bitmap_t num_value_3;
		num_value_3.cols = BITMAP_NUMBER_WIDTH;
		num_value_3.rows = BITMAP_NUMBER_HEIGHT;
		num_value_3.x = 200;
		num_value_3.y = 400;
		num_value_3.num = num_value_3.rows;
		num_value_3.map = &bitmap_number[BITMAP_NUMBYTE_OF_1NUMBER * 1];
		graphic_draw_bitmap(&num_value_3, -1, -1, color);
	}
}


void graphic_update_GPS_val( GPS_t *GPS_log_lat,int kinh_do,int vi_do, uint8_t color)
{
	if((GPS_log_lat -> cur_kinh_do == kinh_do)&&(GPS_log_lat -> cur_vi_do == vi_do))
		return;

	graphic_draw_longitude_val(GPS_log_lat -> cur_kinh_do,0);
	graphic_draw_latitude_val(GPS_log_lat -> cur_vi_do,0);


	graphic_draw_longitude_val(kinh_do,color);
	graphic_draw_latitude_val(vi_do,color);
	GPS_log_lat -> cur_kinh_do = kinh_do;
	GPS_log_lat -> cur_vi_do = vi_do;
}

