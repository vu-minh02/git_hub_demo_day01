#ifndef SRC_MENU_KND_H_
#define SRC_MENU_KND_H_

#include "ui_lib.h"
#include "menu_lib.h"
// Mảng con trỏ đến các bitmap


#if 0
//back up kieu menu_page_t
typedef struct MenuPageStruct {
	uint16_t x;                            // Toa do x
	uint16_t y;                            // Toa do y
	uint16_t Hsize;                        // Kich thuoc chieu ngang
	uint16_t VsizeRows;                    // Kich thuoc chieu doc cua mot hang
	uint16_t PageIndex;                    // So level menu hien tai
	uint16_t PageRows;                     // Tong so hang trong menu
	uint16_t ParentPageIndex;              // So level cua menu cha
	uint16_t ParentRowsIndex;              // So hang xuat hien trong menu cha
    struct MenuPage_t **MenuChildPage;     // Tro den menu con (con trỏ duy nhất, không phải mảng)
    struct MenuPage_t *MenuParentPage;     // Tro den menu cha
    bitmap_t **bitmaps;                    // Mảng con trỏ đến các bitmap (dùng để lưu trữ các hình ảnh của menu)
} MenuPageStruct;
#endif







void DisplayMenu(MenuPage_t *MenuPage, uint8_t color) ;
void UpdateChoosePageRows(MenuPage_t *MenuPage,int RowsIndex ,uint8_t color);
void UpdateMenuPage(MenuPage_t *MenuPage, MenuPage_t **MenuReplacePage, int MenuLevelIndex, int RowsIndex);
void UpdateMenuPageV2(MenuPage_t *MenuPage, MenuPage_t **MenuReplacePage, int *MenuLevelIndex) ;
MenuPage_t* createMenuPage(int x, int y, int Hsize, int VsizeRows, int PageIndex, int PageRows,
                           int ParentPageIndex, int ParentRowsIndex);
void initMenuPage(MenuPage_t* newMenuPage, int x, int y, int Hsize, int VsizeRows,
                  int PageIndex, int PageRows, int ParentPageIndex, int ParentRowsIndex);
void SwitchLabelMenu(MenuPage_t *MenuPage,int RowsIndex, uint8_t color);
void UpdateMenuLabel(MenuPage_t *MenuPage, int MenuLevelIndex,int *LabelMode,uint8_t color);
void ControlValueLabelMenu(MenuPage_t *MenuPage, int Step, uint8_t color);
void PrintNumber(MenuPage_t *MenuPage, int Number, uint8_t* CombinedMap, uint8_t color);
void DrawDigits(uint8_t* combined_map, int num_digits,int bitmap_x, int bitmap_y, int InforType, uint16_t cols,uint16_t rows, uint8_t color) ;

#endif
