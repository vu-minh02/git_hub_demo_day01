#ifndef SRC_MENU_LIB_H_
#define SRC_MENU_LIB_H_
#include "ui_lib.h"

typedef enum {  ITEM_EXIT,
                ITEM_INFO,
                ITEM_VALUE,
				ITEM_SWITCH,
                ITEM_SUBMENU,
				ITEM_MAINMENU,
            } ItemsTypeStruct;

typedef struct
{
	int x;                        // Do dai cua label
	int y;                        // Do rong cua label
	int offset_x;                 // Dieu chinh vi tri voi moc trong menu
	int offset_y;                 // Dieu chinh vi tri voi moc trong menu
//    float value_float;
	uint8_t value;                 // so luong gia tri switch
	uint8_t CurrentValues;         // Chi so gia tri hien tai
	bitmap_t **bitmaps;
} ItemSwitchStruct;

typedef struct
{
	int x;                        // Do dai cua label
	int y;                        // Do rong cua label
	int offset_x;                 // Dieu chinh vi tri voi moc trong menu
	int offset_y;                 // Dieu chinh vi tri voi moc trong menu
    int InfoType[6];
    bitmap_t bitmaps[6];
} ItemInfoStruct;

typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;
    float value_float;
    int value;
    int value_min;
    int value_max;
    int value_step;
    uint8_t combined_map_out[252];
} ItemValueStruct;


typedef struct
{
    int x;
    int y;
    int offset_x;
    int offset_y;
    int submenu_num;

    ItemsTypeStruct  ItemsType;                  // Loai menu
    ItemValueStruct  ItemValue;
    ItemInfoStruct   ItemInfo;
    ItemSwitchStruct ItemSwitch;

} MenuItemStruct;

typedef struct MenuPage_t {
	uint16_t x;                            // Toa do x
	uint16_t y;                            // Toa do y
	uint16_t Hsize;                        // Kich thuoc chieu ngang
	uint16_t VsizeRows;                    // Kich thuoc chieu doc cua mot hang
	uint16_t PageIndex;                    // So level menu hien tai
	uint16_t PageRows;                     // Tong so hang trong menu
	uint16_t ParentPageIndex;              // So level cua menu cha
	uint16_t ParentRowsIndex;              // So hang xuat hien trong menu cha
	MenuItemStruct *MenuItems;             // Item tren hang cua menu
    struct MenuPage_t **MenuChildPage;     // Tro den menu con (con trỏ duy nhất, không phải mảng)
    struct MenuPage_t *MenuParentPage;     // Tro den menu cha
    bitmap_t **bitmaps;                    // Mảng con trỏ đến các bitmap tieu de (dùng để lưu trữ các hình ảnh của menu)
} MenuPage_t;


#endif
