#include "button.h"
#include "peripheral/spi_flash.h"
#include "xintc.h"
#include "xintc_l.h"

//========================================================
#define BUTTON_INTERRUPT_MASK 		XGPIO_IR_CH1_MASK  /* Channel 1 Interrupt Mask */
#define GPIO_INTERRUPT_ID			XPAR_CPU_MICROBLAZE_0_AXI_INTC_GPIO_CTRL_GPIO_BUTTON_IP2INTC_IRPT_INTR

//========================================================
XGpio gpio_button;
XTmrCtr TmrCtr_0;
static volatile uint16_t button_pre = 0;
XIntc InterruptController;

button_t button_L = {BUTTON_IDLE, 0, 1500};
button_t button_R = {BUTTON_IDLE, 0, 1500};
button_t button_M = {BUTTON_IDLE, 0, 1500};

//========================================================
static void buttonInterruptHandler(void *InstancePtr);
static int new_button_decode(uint16_t button_cur);

/************************** Button Buffer ******************************/
circ_bbuf_t button_buffer;

int circ_bbuf_push(circ_bbuf_t *c, button_data_t data)
{
    int next;

    next = c->head + 1;  // next is where head will point to after this write.
    if (next >= c->maxlen)
        next = 0;

    if (next == c->tail)  // if the head + 1 == tail, circular buffer is full
        return -1;

    c->buffer[c->head] = data;  // Load data and then move
    c->head = next;             // head to next data offset.
    return 0;  // return success to indicate successful push.
}

int circ_bbuf_pop(circ_bbuf_t *c, button_data_t *data)
{
    int next;

    if (c->head == c->tail)  // if the head == tail, we don't have any data
        return -1;

    next = c->tail + 1;  // next is where tail will point to after this read.
    if(next >= c->maxlen)
        next = 0;

    *data = c->buffer[c->tail];  // Read data and then move
    c->tail = next;              // tail to next offset.
    return 0;  // return success to indicate successful push.
}
/********************************************************/

void init_button()
{
	int Status = XGpio_Initialize(&gpio_button, XPAR_GPIO_CTRL_GPIO_BUTTON_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		printf("[INFO] init gpio_button XST_FAILURE");
	}
	XGpio_SetDataDirection(&gpio_button, 1, 1);
	button_pre = ~(XGpio_DiscreteRead(&gpio_button, 1));
	new_button_decode(button_pre);


	//khoi tao ngat cho button

	//khoi tao  button buffer
    static uint8_t buffer[64];
	memset(buffer, 0, sizeof(buffer));
	button_buffer.buffer = buffer;
	button_buffer.head = 0;
	button_buffer.tail = 0;
	button_buffer.maxlen = 64;
}

int setupInterrupt()
{
	int Status;

	Status = XIntc_Initialize(&InterruptController, XPAR_CPU_MICROBLAZE_0_AXI_INTC_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/*
	 * Perform a self-test to ensure that the hardware was built correctly.
	 */
	Status = XIntc_SelfTest(&InterruptController);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XIntc_Connect(&InterruptController, GPIO_INTERRUPT_ID, (Xil_ExceptionHandler)buttonInterruptHandler, &gpio_button);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XIntc_Connect(&InterruptController, SPI_INTR_ID, (XInterruptHandler)XSpi_InterruptHandler, (void *)&Spi);
	if(Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	Status = XIntc_Connect(&InterruptController, XPAR_TMRCTR_0_DEVICE_ID,
				(XInterruptHandler)XTmrCtr_InterruptHandler,
				(void *)&TmrCtr_0);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	/* Enable the interrupt vector at the interrupt controller */
	XIntc_Enable(&InterruptController, GPIO_INTERRUPT_ID);
	XIntc_Enable(&InterruptController, SPI_INTR_ID);
	XIntc_Enable(&InterruptController, XPAR_TMRCTR_0_DEVICE_ID);
	/*
	 * Start the interrupt controller such that interrupts are recognized
	 * and handled by the processor
	 */
	Status = XIntc_Start(&InterruptController, XIN_REAL_MODE);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}
	/*
	 * Enable the GPIO channel interrupts so that push button can be
	 * detected and enable interrupts for the GPIO device
	 */
	XGpio_InterruptEnable(&gpio_button, BUTTON_INTERRUPT_MASK);
	XGpio_InterruptGlobalEnable(&gpio_button);
	/*
	 * Initialize the exception table.
	 */
	Xil_ExceptionInit();

	/*
	 * Register the interrupt controller handler with the exception table.
	 */
	Xil_ExceptionRegisterHandler(XIL_EXCEPTION_ID_INT,
					(Xil_ExceptionHandler)
					XIntc_InterruptHandler,
					&InterruptController);

	/*
	 * Enable non-critical exceptions.
	 */
	Xil_ExceptionEnable();

	return XST_SUCCESS;
}

static void buttonInterruptHandler(void *InstancePtr)
{
	XGpio *GpioPtr = (XGpio *)InstancePtr;
	XGpio_InterruptDisable(GpioPtr, BUTTON_INTERRUPT_MASK); //Disable the interrupt

	//==============================
	u16 temp = ~(XGpio_DiscreteRead(&gpio_button, 1));

	new_button_decode(temp);

	//==============================
	(void)XGpio_InterruptClear(GpioPtr, BUTTON_INTERRUPT_MASK);
	XGpio_InterruptEnable(GpioPtr, BUTTON_INTERRUPT_MASK);
}

void timerInterruptHandler(void *CallBackRef, u8 TmrCtrNumber)
{
	if (XTmrCtr_IsExpired(&TmrCtr_0, TMRCTR_CHANNEL_0)) {
		printf("[DEBUG] timer TMRCTR_CHANNEL_0\n\r");
	}

	if (XTmrCtr_IsExpired(&TmrCtr_0, TMRCTR_CHANNEL_1)) {
		printf("[DEBUG] timer TMRCTR_CHANNEL_1\n\r");
	}
}

int init_timer()
{
	int Status;
	Status = XTmrCtr_Initialize(&TmrCtr_0, XPAR_TMRCTR_0_DEVICE_ID);
	if (Status != XST_SUCCESS) {
		return XST_FAILURE;
	}

	XTmrCtr_SetHandler(&TmrCtr_0, timerInterruptHandler, &TmrCtr_0);

	XTmrCtr_SetOptions(&TmrCtr_0, TMRCTR_CHANNEL_0, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);

	// setup TMRCTR_CHANNEL_0
	u32	ResetValue = MAX_COUNT - TIMER_LONG_PRESS_BUTTON;
	XTmrCtr_SetResetValue(&TmrCtr_0, TMRCTR_CHANNEL_0, ResetValue);

	// setup TMRCTR_CHANNEL_1
	XTmrCtr_SetOptions(&TmrCtr_0, TMRCTR_CHANNEL_1, XTC_INT_MODE_OPTION | XTC_AUTO_RELOAD_OPTION);
	XTmrCtr_SetResetValue(&TmrCtr_0, TMRCTR_CHANNEL_1, 0);
	XTmrCtr_Start(&TmrCtr_0, TMRCTR_CHANNEL_1);

	return XST_SUCCESS;
}

bool check_timeout_ms(u32 start_time, int timeout)
{
	u32 curr_time = XTmrCtr_GetValue(&TmrCtr_0, TMRCTR_CHANNEL_1);

	if(((curr_time - start_time) / (XPAR_CPU_CORE_CLOCK_FREQ_HZ/1000)) > timeout)
		return true;
	else
		return false;
}

u32 get_time_value()
{
	return XTmrCtr_GetValue(&TmrCtr_0, TMRCTR_CHANNEL_1);
}

static int new_button_decode(uint16_t button_cur)
{
	//==============================
	if( (((button_pre >> 2) & 0b11) == 0b01 && ((button_cur >> 2) & 0b11) == 0b11) ||
		(((button_pre >> 2) & 0b11) == 0b10 && ((button_cur >> 2) & 0b11) == 0b00) )
	{
		circ_bbuf_push(&button_buffer, PRESS_BUTTON_RL);
	}

	//==============================
	if( (((button_pre >> 2) & 0b11) == 0b10 && ((button_cur >> 2) & 0b11) == 0b11) ||
		(((button_pre >> 2) & 0b11) == 0b01 && ((button_cur >> 2) & 0b11) == 0b00) )
	{
		circ_bbuf_push(&button_buffer, PRESS_BUTTON_RR);
	}

#if 0
	//==============================
	if((button_pre & BUTTON_L) == BUTTON_L && (button_cur & BUTTON_L) == 0){
		circ_bbuf_push(&button_buffer, PRESS_BUTTON_L);
	}

	//==============================
	if((button_pre & BUTTON_R) == BUTTON_R && (button_cur & BUTTON_R) == 0){
		circ_bbuf_push(&button_buffer, PRESS_BUTTON_R);
	}

	//==============================
	if((button_pre & BUTTON_M) == BUTTON_M && (button_cur & BUTTON_M) == 0){
		circ_bbuf_push(&button_buffer, PRESS_BUTTON_M);
	}
#else
	//==============================
	if(button_L.state == BUTTON_IDLE)
	{
		if((button_cur & BUTTON_L) == BUTTON_L)
		{
			button_L.state  = BUTTON_PRESS;
			button_L.start_time_press = get_time_value();
		}
	}
	else if(button_L.state == BUTTON_PRESS)
	{
		if((button_cur & BUTTON_L) == 0){
			button_L.state = BUTTON_IDLE;
			circ_bbuf_push(&button_buffer, PRESS_BUTTON_L);
		}
	}
	else if(button_L.state == BUTTON_HOLD)
	{
		if((button_cur & BUTTON_L) == 0)
			button_L.state = BUTTON_IDLE;
	}

	//==============================
	if(button_R.state == BUTTON_IDLE)
	{
		if((button_cur & BUTTON_R) == BUTTON_R)
		{
			button_R.state  = BUTTON_PRESS;
			button_R.start_time_press = get_time_value();
		}
	}
	else if(button_R.state == BUTTON_PRESS)
	{
		if((button_cur & BUTTON_R) == 0){
			button_R.state = BUTTON_IDLE;
			circ_bbuf_push(&button_buffer, PRESS_BUTTON_R);
		}
	}
	else if(button_R.state == BUTTON_HOLD)
	{
		if((button_cur & BUTTON_R) == 0)
			button_R.state = BUTTON_IDLE;
	}

	//==============================
	if(button_M.state == BUTTON_IDLE)
	{
		if((button_cur & BUTTON_M) == BUTTON_M)
		{
			button_M.state  = BUTTON_PRESS;
			button_M.start_time_press = get_time_value();
		}
	}
	else if(button_M.state == BUTTON_PRESS)
	{
		if((button_cur & BUTTON_M) == 0){
			button_M.state = BUTTON_IDLE;
			circ_bbuf_push(&button_buffer, PRESS_BUTTON_M);
		}
	}
	else if(button_M.state == BUTTON_HOLD)
	{
		if((button_cur & BUTTON_M) == 0)
			button_M.state = BUTTON_IDLE;
	}
#endif

	//==============================
	button_pre = button_cur;
	return 0;
}

void check_button_hold()
{

	if(button_L.state == BUTTON_PRESS)
	{
		if(check_timeout_ms(button_L.start_time_press, button_L.time_hold)){
			button_L.state = BUTTON_HOLD;
			circ_bbuf_push(&button_buffer, HOLD_BUTTON_L);
		}
	}

	if(button_R.state == BUTTON_PRESS)
	{
		if(check_timeout_ms(button_R.start_time_press, button_R.time_hold)){
			button_R.state = BUTTON_HOLD;
			circ_bbuf_push(&button_buffer, HOLD_BUTTON_R);
		}
	}

	if(button_M.state == BUTTON_PRESS)
	{
		if(check_timeout_ms(button_M.start_time_press, button_M.time_hold)){
			button_M.state = BUTTON_HOLD;
			circ_bbuf_push(&button_buffer, HOLD_BUTTON_M);
		}
	}
}




