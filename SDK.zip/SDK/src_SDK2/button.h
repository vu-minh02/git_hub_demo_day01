#ifndef SRC_BUTTON_H_
#define SRC_BUTTON_H_

#include "common.h"

#define TMRCTR_CHANNEL_0			0
#define TMRCTR_CHANNEL_1			1

#define MAX_COUNT					0xFFFFFFFF
#define TIMER_LONG_PRESS_BUTTON		2*XPAR_CPU_CORE_CLOCK_FREQ_HZ //set timer button hold

extern XGpio gpio_button;
extern XTmrCtr TmrCtr_0;

typedef enum {	PRESS_BUTTON_L, HOLD_BUTTON_L,
				PRESS_BUTTON_R, HOLD_BUTTON_R,
				PRESS_BUTTON_M, HOLD_BUTTON_M,
				PRESS_BUTTON_RL,
				PRESS_BUTTON_RR,
				UNKNOWN
			 } button_data_t;

typedef enum {	BUTTON_L		= 0b00001,
				BUTTON_R		= 0b00010,
				BUTTON_M		= 0b10000,
				BUTTON_RL		= 0b00100,
				BUTTON_RR		= 0b01000,
			 } button_mask_t;

typedef enum {	BUTTON_IDLE,
				BUTTON_PRESS,
				BUTTON_HOLD,
				BUTTON_UNKNOWN
		 	 } button_stt_t;

typedef struct {
	button_stt_t state;
	u32 start_time_press;
	u32 time_hold;
} button_t;


void init_button();
int setupInterrupt();
int init_timer();
bool check_timeout_ms(u32 start_time, int timeout);
u32 get_time_value();
void check_button_hold();
/************************** Button Buffer ******************************/

typedef struct {
    uint8_t * buffer;
    int head;
    int tail;
    int maxlen;
} circ_bbuf_t;

extern circ_bbuf_t button_buffer;

int circ_bbuf_push(circ_bbuf_t *c, button_data_t data);

int circ_bbuf_pop(circ_bbuf_t *c, button_data_t *data);

#endif /* SRC_BUTTON_H_ */
